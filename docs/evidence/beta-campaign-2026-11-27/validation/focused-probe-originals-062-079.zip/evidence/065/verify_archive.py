#!/usr/bin/env python3
"""Worker 065: read-only archive preservation audit; never executes probe content."""
import collections
import hashlib
import io
import json
import pathlib
import re
import stat
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
REPO = ROOT / "APP1"
REL = pathlib.PurePosixPath("docs/evidence/beta-campaign-2026-11-27/validation")
MANIFEST = "focused-probe-archive.json"
ASSIGNED = "624c2c9"
ARCHIVAL = "0b6c78f"

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result

def parse(data):
    return json.loads(data, object_pairs_hook=strict_object)

def unsafe(name):
    return (not name or "\\" in name or "\x00" in name or
            name.startswith("/") or re.match(r"^[A-Za-z]:", name) is not None or
            any(part in ("", ".", "..") for part in name.split("/")))

def compiled_kind(data):
    if data[:4] == b"\x7fELF": return "ELF"
    if data[:2] == b"MZ": return "PE"
    if data[:8] == b"!<arch>\n": return "ar"
    if data[:4] in (b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                    b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                    b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca"):
        return "Mach-O"
    return None

def cache_name(name):
    parts = pathlib.PurePosixPath(name).parts
    return (any(p.lower() in ("cache", "module-cache", "modulecache", "__pycache__", ".build")
                for p in parts) or
            pathlib.PurePosixPath(name).suffix.lower() in
            (".pcm", ".o", ".a", ".so", ".dylib", ".dll", ".exe", ".pyc",
             ".swiftmodule", ".swiftdoc", ".swiftsourceinfo"))

raw_manifest = (REPO / REL / MANIFEST).read_bytes()
manifest = parse(raw_manifest)
archive_path = REL / manifest["archive"]
archive_data = (REPO / archive_path).read_bytes()
errors = []
def check(condition, label):
    if not condition: errors.append(label)

audit = {
    "worker": "/root/a065_probe_archive_integrity",
    "assignedInput": git("rev-parse", ASSIGNED).decode().strip(),
    "archivalCommit": git("rev-parse", ARCHIVAL).decode().strip(),
    "observedHead": git("rev-parse", "HEAD").decode().strip(),
    "archiveSHA256": sha(archive_data),
    "archiveBytes": len(archive_data),
    "manifestSHA256": sha(raw_manifest),
}
check(sha(archive_data) == manifest["sha256"], "Archive SHA differs")
check(len(archive_data) == manifest["bytes"], "Archive byte count differs")
audit["revisionByteEquality"] = {}
for rev in (ARCHIVAL, ASSIGNED):
    matches = {
        MANIFEST: git("show", f"{rev}:{REL / MANIFEST}") == raw_manifest,
        manifest["archive"]: git("show", f"{rev}:{archive_path}") == archive_data,
    }
    audit["revisionByteEquality"][rev] = matches
    check(all(matches.values()), f"Current archive/manifest differ from {rev}")

with zipfile.ZipFile(io.BytesIO(archive_data)) as z:
    infos = z.infolist()
    names = [info.filename for info in infos]
    rows = manifest["files"]
    paths = [row["path"] for row in rows]
    inner = parse(z.read("manifest.json"))
    audit["internalManifestScope"] = inner.get("scope")
    audit["zipEntries"] = len(names)
    audit["payloadFiles"] = len(rows)
    audit["payloadBytes"] = sum(row["bytes"] for row in rows)
    audit["zipTotalUncompressedBytes"] = sum(info.file_size for info in infos)
    audit["innerManifestBytes"] = len(z.read("manifest.json"))
    audit["duplicateZipNames"] = [k for k,v in collections.Counter(names).items() if v > 1]
    audit["duplicateManifestNames"] = [k for k,v in collections.Counter(paths).items() if v > 1]
    audit["casefoldCollisions"] = [k for k,v in collections.Counter(n.casefold() for n in names).items() if v > 1]
    audit["unsafeNames"] = [name for name in names + paths if unsafe(name)]
    audit["unexpectedEntries"] = sorted(set(names) - set(paths) - {"manifest.json"})
    audit["missingEntries"] = sorted(set(paths) - set(names))
    audit["cacheEntries"] = [name for name in names if cache_name(name)]
    audit["nonRegularEntries"] = [i.filename for i in infos if i.is_dir() or
                                  stat.S_IFMT(i.external_attr >> 16) not in (0, stat.S_IFREG)]
    audit["executablePermissionEntries"] = [i.filename for i in infos if (i.external_attr >> 16) & 0o111]
    audit["compiledBinaryEntries"] = []
    audit["crcFailure"] = z.testzip()
    check(inner["files"] == rows, "Inner/external manifest records differ")
    check(len(rows) == manifest["fileCount"] == 445, "Payload count differs")
    check(audit["payloadBytes"] == manifest["uncompressedBytes"], "Payload byte total differs")
    for key in ("duplicateZipNames", "duplicateManifestNames", "casefoldCollisions", "unsafeNames",
                "unexpectedEntries", "missingEntries", "cacheEntries", "nonRegularEntries",
                "executablePermissionEntries", "crcFailure"):
        check(not audit[key], f"Rejected {key}: {audit[key]}")
    verified = 0
    for row in rows:
        name = row["path"]
        data = z.read(name)
        original = ROOT / "campaign" / name
        check(not unsafe(name), f"Unsafe manifest path: {name}")
        check(original.is_file() and not original.is_symlink(), f"Missing/non-regular scratch original: {name}")
        check(len(data) == row["bytes"], f"ZIP size differs: {name}")
        check(sha(data) == row["sha256"], f"ZIP hash differs: {name}")
        if original.is_file():
            source = original.read_bytes()
            check(len(source) == row["bytes"], f"Scratch size differs: {name}")
            check(sha(source) == row["sha256"], f"Scratch hash differs: {name}")
            check(data == source, f"ZIP/scratch bytes differ: {name}")
            if data == source and len(data) == row["bytes"] and sha(data) == row["sha256"]:
                verified += 1
        kind = compiled_kind(data)
        if kind: audit["compiledBinaryEntries"].append({"path": name, "kind": kind})
    check(not audit["compiledBinaryEntries"], "Compiled binaries retained")
    audit["filesVerifiedAgainstManifestAndScratch"] = verified
    groups = collections.Counter("/".join(name.split("/")[:2]) for name in paths)
    audit["includedGroups"] = dict(sorted(groups.items()))
    excluded = []
    unexplained = []
    archived = set(paths)
    for group in sorted(groups):
        for path in sorted((ROOT / "campaign" / group).rglob("*")):
            if not path.is_file(): continue
            name = path.relative_to(ROOT / "campaign").as_posix()
            if name in archived: continue
            with path.open("rb") as stream: prefix = stream.read(16)
            reason = "compiler cache" if cache_name(name) else compiled_kind(prefix)
            item = {"path": name, "reason": reason, "bytes": path.stat().st_size}
            excluded.append(item)
            if reason is None: unexplained.append(item)
    audit["omittedScratchFilesUnderIncludedGroups"] = excluded
    audit["omissionReasons"] = dict(collections.Counter(row["reason"] or "unexplained" for row in excluded))
    audit["unexplainedOmissions"] = unexplained
    check(not unexplained, "Non-cache/non-binary scratch originals omitted under included groups")
audit["errors"] = errors
audit["passed"] = not errors
print(json.dumps(audit, indent=2))
raise SystemExit(0 if not errors else 1)
