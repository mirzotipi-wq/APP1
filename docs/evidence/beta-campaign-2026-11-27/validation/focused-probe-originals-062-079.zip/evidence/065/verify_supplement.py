#!/usr/bin/env python3
"""Worker 065 follow-up: compare the supplemental archive to the missing originals."""
import collections
import hashlib
import io
import json
import pathlib
import re
import stat
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
REPO = ROOT / "APP1"
REL = pathlib.PurePosixPath("docs/evidence/beta-campaign-2026-11-27/validation")
NAME = "recovery-fault-original-supplement"
REV = "03df6b9"

def sha(data): return hashlib.sha256(data).hexdigest()
def strict(pairs):
    d = {}
    for k,v in pairs:
        assert k not in d, f"Duplicate JSON key {k}"
        d[k] = v
    return d
def parse(data): return json.loads(data, object_pairs_hook=strict)
def git(*args): return subprocess.check_output(["git", "-C", str(REPO), *args])

raw_manifest = (REPO / REL / f"{NAME}.json").read_bytes()
m = parse(raw_manifest)
raw_zip = (REPO / REL / m["archive"]).read_bytes()
prior = parse((ROOT / "campaign/evidence/065/archive-audit.json").read_bytes())
meaningful = {r["path"] for r in prior["unexplainedOmissions"] if not r["path"].endswith("/.keep-directory")}
paths = [r["path"] for r in m["files"]]
assert len(paths) == len(set(paths)) == m["fileCount"] == 12
assert set(paths) == meaningful
assert sha(raw_zip) == m["sha256"] and len(raw_zip) == m["bytes"] == 4669
assert sum(r["bytes"] for r in m["files"]) == m["payloadBytes"] == 4793
for name, data in ((f"{NAME}.json", raw_manifest), (m["archive"], raw_zip)):
    assert git("show", f"{REV}:{REL / name}") == data

with zipfile.ZipFile(io.BytesIO(raw_zip)) as z:
    infos = z.infolist()
    names = [i.filename for i in infos]
    assert len(names) == len(set(names)) == len(set(n.casefold() for n in names))
    assert set(names) - set(paths) <= {"manifest.json"}
    assert not set(paths) - set(names)
    assert z.testzip() is None
    if "manifest.json" in names:
        inner = parse(z.read("manifest.json"))
        assert (inner if isinstance(inner, list) else inner["files"]) == m["files"]
    for info in infos:
        name = info.filename
        assert name and not name.startswith("/") and "\\" not in name and "\x00" not in name
        assert not re.match(r"^[A-Za-z]:", name)
        assert not any(p in ("", ".", "..") for p in name.split("/"))
        assert not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG)
        assert not ((info.external_attr >> 16) & 0o111)
        assert not any(p.lower() in ("cache", "module-cache", "__pycache__", ".build") for p in name.split("/"))
    verified = []
    for row in m["files"]:
        data = z.read(row["path"])
        original = ROOT / "campaign" / row["path"]
        assert original.is_file() and not original.is_symlink()
        assert data == original.read_bytes()
        assert sha(data) == row["sha256"] and len(data) == row["bytes"]
        assert not data.startswith((b"\x7fELF", b"MZ", b"!<arch>\n"))
        verified.append(row["path"])

original_name = "focused-probe-originals-through-055.zip"
original_zip = (REPO / REL / original_name).read_bytes()
assert sha(original_zip) == prior["archiveSHA256"]
assert original_zip == git("show", f"624c2c9:{REL / original_name}")
result = {
    "passed": True,
    "supplementCommit": git("rev-parse", REV).decode().strip(),
    "sha256": sha(raw_zip), "archiveBytes": len(raw_zip),
    "zipEntries": len(names), "payloadFiles": len(verified), "payloadBytes": 4793,
    "allTwelveMissingOriginalPathsMatch": True,
    "originalArchiveUnchanged": True,
    "combinedPayloadFiles": prior["payloadFiles"] + len(verified),
    "combinedPayloadBytes": prior["payloadBytes"] + 4793,
    "remainingOmittedNonCacheNonExecutablePaths": [r["path"] for r in prior["unexplainedOmissions"]
                                                   if r["path"] not in meaningful],
    "remainingPathAssessment": "Only zero-byte compiler temporary directory marker; no meaningful original gap under the 17 audited roots",
    "verifiedPaths": verified,
    "scope": "Original archive plus supplement, with historical limitations unchanged; no probe replay",
}
print(json.dumps(result, indent=2))
