#!/usr/bin/env python3
"""Read archived evidence only; do not run its source or probes."""
import hashlib
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
VALIDATION = ROOT / "APP1/docs/evidence/beta-campaign-2026-11-27/validation"

def nodes(value):
    yield value
    if isinstance(value, dict):
        for child in value.values(): yield from nodes(child)
    elif isinstance(value, list):
        for child in value: yield from nodes(child)

with zipfile.ZipFile(VALIDATION / "focused-probe-originals-through-055.zip") as z:
    payload = {name: z.read(name) for name in z.namelist()}
    def text(name): return payload[name].decode()
    def summaries(name):
        return re.findall(r"Executed (\d+) tests, with (\d+) failures", text(name))
    fixture_names = [n for n in payload if n.startswith("probes/044/fixtures/")]
    assert len(fixture_names) == 30
    assert all(payload[n] == payload[n.replace("probes/044/", "probes/045/")] for n in fixture_names)
    raw_host = text("probes/044/host-results.log").splitlines()
    replay_host = text("probes/045/unchanged-host-kernel.log").splitlines()
    assert [s.split(": mean=",1)[1] for s in raw_host] == [s.split(": mean=",1)[1] for s in replay_host]
    result = {
        "method": "Inspection/counting of retained originals, not probe replay or current-source validation",
        "040": text("probes/040/result.txt").splitlines(),
        "042": {"beforeSummaries": summaries("probes/042/before.log"),
                "afterSummaries": summaries("probes/042/after.log")},
        "044": {"hostRows": len(raw_host), "hostFailedRows": sum(s.endswith(", FAIL") for s in raw_host),
                "eligibleRows": text("probes/044/swift-results.log").count("eligible=true")},
        "045": {"beforeSummaries": summaries("probes/045/before-focused.log"),
                "afterSummaries": summaries("probes/045/after-focused.log"),
                "ineligibleRows": text("probes/045/after-swift-results.log").count("eligible=false"),
                "byteIdenticalFixtureFiles": len(fixture_names),
                "rawHostOutcomeRowsUnchanged": len(raw_host),
                "initialCompileFailureRetained": "probes/045/initial-test-compile-failure.log" in payload},
        "053": json.loads(text("probes/053/math-check.log")),
        "053InitialReviewerFailureRetained": "probes/053/initial-probe-assumption.txt" in payload,
        "049": text("evidence/049/probe-output.txt").splitlines(),
        "051": {"beforeResult": text("evidence/051/probe-before.log").splitlines()[-1],
                "afterResult": text("evidence/051/probe-after.log").splitlines()[-1],
                "focusedSummaries": summaries("evidence/051/focused-after.log"),
                "nativeExecutionLimitation": json.loads(text("evidence/051/validation.json"))["nativeBuildAndRuntime"]},
    }
    parsed = {}
    for name, data in payload.items():
        if name.endswith(".json"):
            try: parsed[name] = list(nodes(json.loads(data)))
            except (ValueError, UnicodeDecodeError): pass
    omissions = []
    audit = json.loads((ROOT / "campaign/evidence/065/archive-audit.json").read_text())
    for row in audit["unexplainedOmissions"]:
        path = ROOT / "campaign" / row["path"]
        data = path.read_bytes()
        identical = [name for name, stored in payload.items() if stored == data]
        item = {"path": row["path"], "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                "identicalPayloadCount": len(identical),
                "firstIdenticalPayload": identical[0] if identical else None}
        if path.suffix == ".jsonl" and data:
            events = [json.loads(line) for line in data.splitlines()]
            item["parsedEvents"] = len(events)
            item["allParsedEventsRetainedIn"] = [name for name, ns in parsed.items()
                                                  if all(event in ns for event in events)]
            item["rawBytesEmbeddedIn"] = [name for name, stored in payload.items() if data in stored]
        omissions.append(item)
    result["omissionReview"] = omissions
print(json.dumps(result, indent=2))
