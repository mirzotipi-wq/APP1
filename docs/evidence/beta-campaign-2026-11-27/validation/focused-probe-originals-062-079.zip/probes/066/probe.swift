import Foundation
// Extracted task methods only. Foundation stand-ins replace PhotosUI/UIKit and
// SwiftUI storage. This does not model view ownership or UIKit dismissal events.
struct UIImage: Equatable, Sendable {
    let data: Data
    init?(data: Data) { guard !data.isEmpty else { return nil }; self.data = data }
    var cgImage: (width: Int, height: Int)? { (1, 1) }
    var size: (width: Double, height: Double) { (1, 1) }
    var scale: Double { 1 }
}
struct ReferencePhoto: Sendable {
    let png: Data
    let width = 1, height = 1
    let tones: Int? = 1
}
enum ReferenceImportError: LocalizedError {
    case unreadable
    var errorDescription: String? { "Unreadable" }
}
struct ReferenceAnalysisResult: Sendable, Equatable { let value: Int }
struct Observations { }
enum ProviderFailure: Error { case failed }
actor Suspended<Value: Sendable> {
    private var result: CheckedContinuation<Value, Error>?
    private var entered: CheckedContinuation<Void, Never>?
    func get() async throws -> Value {
        try await withCheckedThrowingContinuation { continuation in
            result = continuation
            entered?.resume()
            entered = nil
        }
    }
    func waitUntilEntered() async {
        if result != nil { return }
        await withCheckedContinuation { entered = $0 }
    }
    func succeed(_ value: Value) { result?.resume(returning: value); result = nil }
    func fail() { result?.resume(throwing: ProviderFailure.failed); result = nil }
}
struct PhotosPickerItem: Sendable {
    let gate: Suspended<ReferencePhoto?>
    func loadTransferable(type: ReferencePhoto.Type) async throws -> ReferencePhoto? {
        try await gate.get() // Deliberately ignores task cancellation.
    }
}
@MainActor enum ReferenceAnalysisService {
    static var gates: [Data: Suspended<ReferenceAnalysisResult>] = [:]
    static func analyze(png: Data) async throws -> ReferenceAnalysisResult {
        guard let gate = gates[png] else { return .init(value: Int(png.first!)) }
        return try await gate.get() // Deliberately ignores task cancellation.
    }
}
@MainActor final class ReferenceHarness {
    var selection: PhotosPickerItem?
    var requestID = UUID()
    var reference: UIImage?
    var tones: Int?
    var loading = false
    var failure: String?
    var sizeDescription = ""
    var importTask: Task<Void, Never>?
    var analysisRequestID = UUID()
    var analysisTask: Task<Void, Never>?
    var analysis: ReferenceAnalysisResult?
    var analyzing = false
    var analysisFailure: String?
    var acceptedAnalysisDirection: String?
    var observations = Observations()
    var candidates: [Int] = []
    var previewID: String?
    var rigError: String?
    var confirmApply = false
    var sessionClosed = false
    func select(_ item: PhotosPickerItem) {
        guard !sessionClosed else { return }
        let token = UUID()
        requestID = token
        loading = true
        failure = nil
        selection = nil
        load(item, token: token)
    }
    func load(_ item: PhotosPickerItem, token: UUID) {
        importTask?.cancel()
        importTask = Task {
            defer {
                if requestID == token { importTask = nil }
            }
            do {
                let transferred = try await item.loadTransferable(type: ReferencePhoto.self)
                // A provider may finish after cancellation. Reject its result
                // before constructing an obsolete image on the main actor.
                guard !Task.isCancelled, requestID == token else { return }
                guard let photo = transferred, let image = UIImage(data: photo.png) else {
                    throw ReferenceImportError.unreadable
                }
                guard !Task.isCancelled, requestID == token else { return }
                reference = image
                tones = photo.tones
                observations = .init(); candidates = []; previewID = nil; rigError = nil
                confirmApply = false
                sizeDescription = "\(photo.width) × \(photo.height) px · session only"
                loading = false
                startAnalysis(png: photo.png)
            } catch is CancellationError {
                guard !Task.isCancelled, requestID == token else { return }
                loading = false
            } catch {
                guard !Task.isCancelled, requestID == token else { return }
                let detail = (error as? ReferenceImportError)?.errorDescription ??
                    "The photo is unavailable. Check Photos or choose another local image."
                failure = reference == nil ? detail : "Replacement failed. Your previous photo is still open. \(detail)"
                loading = false
            }
        }
    }

    func startAnalysis(png: Data) {
        cancelAnalysis()
        let token = analysisRequestID
        analyzing = true
        // Keep PNG bytes only for the service call, never in view state or a project.
        analysisTask = Task {
            defer {
                if analysisRequestID == token {
                    analysisTask = nil
                    analyzing = false
                }
            }
            do {
                let result = try await ReferenceAnalysisService.analyze(png: png)
                guard !Task.isCancelled, analysisRequestID == token else { return }
                analysis = result
            } catch {
                guard !Task.isCancelled, analysisRequestID == token else { return }
                analysisFailure = "The on-device check could not finish. Choose the key side manually."
            }
        }
    }

    func cancelAnalysis() {
        analysisRequestID = UUID()
        analysisTask?.cancel()
        analysisTask = nil
        analysis = nil
        analyzing = false
        analysisFailure = nil
        acceptedAnalysisDirection = nil
    }

    func cancelImport() {
        requestID = UUID()
        importTask?.cancel()
        importTask = nil
        selection = nil
        failure = nil
        loading = false
    }

    func clear() {
        cancelImport()
        cancelAnalysis()
        reference = nil
        tones = nil
        observations = .init(); candidates = []; previewID = nil; rigError = nil
        confirmApply = false
        sizeDescription = ""
    }

    func closeSession() {
        guard !sessionClosed else { return }
        sessionClosed = true
        confirmApply = false
        clear()
    }
}
@MainActor
final class ComparisonPhotoSlot {
    private(set) var image: UIImage?
    private(set) var isLoading = false
    private(set) var failure: String?
    var requestID = UUID()
    var importTask: Task<Void, Never>?

    init(image: UIImage? = nil) { self.image = image }

    var pixelDescription: String {
        guard let image else { return "" }
        let width = image.cgImage?.width ?? Int(image.size.width * image.scale)
        let height = image.cgImage?.height ?? Int(image.size.height * image.scale)
        return "\(width) × \(height) px · session only"
    }

    func load(_ item: PhotosPickerItem) {
        cancelImport()
        let token = requestID
        isLoading = true
        importTask = Task { [weak self] in
            defer {
                if self?.requestID == token {
                    self?.isLoading = false
                    self?.importTask = nil
                }
            }
            do {
                let transferred = try await item.loadTransferable(type: ReferencePhoto.self)
                guard let self, !Task.isCancelled, self.requestID == token else { return }
                guard let photo = transferred, let replacement = UIImage(data: photo.png) else {
                    throw ReferenceImportError.unreadable
                }
                guard !Task.isCancelled, self.requestID == token else { return }
                self.image = replacement
                self.failure = nil
            } catch is CancellationError {
                // Provider cancellation leaves any previous image intact.
            } catch {
                guard let self, !Task.isCancelled, self.requestID == token else { return }
                let detail = (error as? ReferenceImportError)?.errorDescription ??
                    "The photo is unavailable. Check Photos or choose another local image."
                self.failure = self.image == nil ? detail :
                    "Replacement failed. Your previous photo is still open. \(detail)"
            }
        }
    }

    func cancelImport() {
        requestID = UUID()
        importTask?.cancel()
        importTask = nil
        isLoading = false
        failure = nil
    }

    func clear() {
        cancelImport()
        image = nil
    }

    deinit { importTask?.cancel() }
}

@main struct Probe {
    @MainActor static func main() async {
        var checks = 0
        func require(_ condition: @autoclosure () -> Bool, _ label: String) {
            precondition(condition(), label)
            checks += 1
            print("PASS \(label)")
        }
        func photo(_ n: UInt8) -> ReferencePhoto { .init(png: Data([n])) }
        let old = photo(1), newer = photo(2)
        // A provider result arrives after completed close.
        do {
            let h = ReferenceHarness(), gate = Suspended<ReferencePhoto?>()
            h.select(.init(gate: gate)); let pending = h.importTask!
            await gate.waitUntilEntered()
            h.closeSession()
            await gate.succeed(old); await pending.value
            require(h.sessionClosed && h.reference == nil && h.analysis == nil && !h.loading, "closed reference rejects late success")
        }
        // A's error cannot stop B's loading state or publish stale error text.
        do {
            let h = ReferenceHarness(), a = Suspended<ReferencePhoto?>(), b = Suspended<ReferencePhoto?>()
            h.select(.init(gate: a)); let oldTask = h.importTask!
            await a.waitUntilEntered()
            h.select(.init(gate: b)); let newTask = h.importTask!
            await b.waitUntilEntered()
            await a.fail(); await oldTask.value
            require(h.loading && h.failure == nil && h.importTask != nil, "old error leaves new import active")
            await b.succeed(newer); await newTask.value
            require(h.reference?.data == newer.png && !h.loading, "latest reference result wins")
            h.closeSession()
        }
        // A succeeds after B has already installed a newer photo.
        do {
            let h = ReferenceHarness(), a = Suspended<ReferencePhoto?>(), b = Suspended<ReferencePhoto?>()
            h.select(.init(gate: a)); let oldTask = h.importTask!
            await a.waitUntilEntered()
            h.select(.init(gate: b)); let newTask = h.importTask!
            await b.waitUntilEntered()
            await b.succeed(newer); await newTask.value
            await a.succeed(old); await oldTask.value
            require(h.reference?.data == newer.png && h.failure == nil, "late older reference cannot overwrite newer photo")
            h.closeSession()
        }
        // Failed replacement retains prior photo, guided work, and its analysis.
        do {
            let h = ReferenceHarness(), analysisGate = Suspended<ReferenceAnalysisResult>()
            ReferenceAnalysisService.gates[old.png] = analysisGate
            let initial = Suspended<ReferencePhoto?>()
            h.select(.init(gate: initial)); let initialTask = h.importTask!
            await initial.waitUntilEntered(); await initial.succeed(old); await initialTask.value
            let analysisTask = h.analysisTask!
            await analysisGate.waitUntilEntered()
            h.candidates = [7]; h.previewID = "seven"
            let replacement = Suspended<ReferencePhoto?>()
            h.select(.init(gate: replacement)); let replacementTask = h.importTask!
            await replacement.waitUntilEntered(); await replacement.fail(); await replacementTask.value
            await analysisGate.succeed(.init(value: 7)); await analysisTask.value
            require(h.reference?.data == old.png && h.candidates == [7] && h.previewID == "seven" && h.analysis?.value == 7, "failed replacement retains previous session and analysis")
            h.closeSession(); ReferenceAnalysisService.gates.removeAll()
        }
        // Clear invalidates the separately owned analysis result.
        do {
            let h = ReferenceHarness(), analysisGate = Suspended<ReferenceAnalysisResult>()
            ReferenceAnalysisService.gates[old.png] = analysisGate
            h.reference = UIImage(data: old.png); h.startAnalysis(png: old.png)
            let pending = h.analysisTask!
            await analysisGate.waitUntilEntered(); h.clear()
            await analysisGate.succeed(.init(value: 9)); await pending.value
            require(h.reference == nil && h.analysis == nil && !h.analyzing, "clear rejects late analysis")
            ReferenceAnalysisService.gates.removeAll()
        }
        // Slot ownership has independent invalidation and never clears new work.
        do {
            let slot = ComparisonPhotoSlot(), a = Suspended<ReferencePhoto?>(), b = Suspended<ReferencePhoto?>()
            slot.load(.init(gate: a)); let oldTask = slot.importTask!
            await a.waitUntilEntered()
            slot.load(.init(gate: b)); let newTask = slot.importTask!
            await b.waitUntilEntered(); await a.succeed(old); await oldTask.value
            require(slot.image == nil && slot.isLoading && slot.importTask != nil, "old slot success preserves newer loading state")
            await b.succeed(newer); await newTask.value
            require(slot.image?.data == newer.png && !slot.isLoading, "latest comparison-slot result wins")
        }
        do {
            let slot = ComparisonPhotoSlot(image: UIImage(data: old.png)), gate = Suspended<ReferencePhoto?>()
            slot.load(.init(gate: gate)); let pending = slot.importTask!
            await gate.waitUntilEntered(); slot.clear()
            await gate.succeed(newer); await pending.value
            require(slot.image == nil && !slot.isLoading && slot.failure == nil, "cleared comparison slot rejects late result")
        }
        print("\(checks) extracted lifecycle assertions passed; no native lifecycle execution.")
    }
}
