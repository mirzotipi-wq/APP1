import Foundation

/// Strict decimal input for scene parameters. Values are never silently
/// clamped, rounded to a slider step, or interpreted as grouped numbers.
public enum StudioNumericInput {
    /// A raw editing draft can include padding and temporarily incomplete
    /// input. Keep the parser's existing byte allowance without walking an
    /// unbounded pasted string or its potentially enormous grapheme clusters.
    public static let maximumDraftUTF8Bytes = 256

    /// Check before storing a TextField replacement. This checks size only;
    /// empty drafts, signs, local decimal digits, and intermediate edits remain
    /// editable. A rejected replacement must leave the previous draft intact.
    public static func isWithinDraftLimit(_ text: String) -> Bool {
        text.utf8.prefix(maximumDraftUTF8Bytes + 1).count <= maximumDraftUTF8Bytes
    }

    /// The shared current-value readout for numeric controls. Slider steps
    /// describe adjustment increments, not the precision of an imported or
    /// directly entered value. Round-trip digits preserve the stored Double;
    /// scientific notation bounds values that need more than 32 decimal
    /// characters. Localization changes symbols, never the numeric precision.
    public static func formattedValue(_ value: Double, unit: String = "",
                                      locale: Locale = .current) -> String {
        guard value.isFinite else { return unit.isEmpty ? "Unavailable" : "Unavailable " + unit }
        let source = decimalText(value, omitLeadingZeroWhenNeeded: false) ?? String(value)
        let integerStyle = IntegerFormatStyle<Int>.number.grouping(.never).locale(locale)
        let digits = (0...9).map { $0.formatted(integerStyle) }
        let minus = (-1).formatted(integerStyle).replacingOccurrences(of: digits[1], with: "")
        let number = source.map { character -> String in
            if let digit = character.wholeNumberValue { return digits[digit] }
            if character == "." { return locale.decimalSeparator ?? "." }
            if character == "-" { return minus }
            return String(character)
        }.joined()
        return unit.isEmpty ? number : number + " " + unit
    }

    /// An exact, bounded decimal draft using ASCII digits and the user's
    /// separator. nil means the editor must retain the value explicitly rather
    /// than seed its decimal field with rounded zero or scientific notation.
    public static func editableText(_ value: Double, decimalSeparator: String = ".") -> String? {
        guard let decimal = decimalText(value, omitLeadingZeroWhenNeeded: true) else { return nil }
        let text = decimal.replacingOccurrences(of: ".", with: decimalSeparator)
        guard let parsed = parse(text, decimalSeparator: decimalSeparator,
                                 in: -Double.greatestFiniteMagnitude...Double.greatestFiniteMagnitude),
              parsed.bitPattern == value.bitPattern else { return nil }
        return text
    }

    /// Expand Double's round-trip description only after checking the output
    /// length. No hundreds-of-digits intermediate is allocated for subnormals.
    private static func decimalText(_ value: Double, omitLeadingZeroWhenNeeded: Bool) -> String? {
        guard value.isFinite else { return nil }
        let parts = String(value).split(separator: "e")
        let exponent = parts.count == 2 ? Int(parts[1])! : 0
        var mantissa = String(parts[0])
        let negative = mantissa.first == "-"
        if negative { mantissa.removeFirst() }
        let components = mantissa.split(separator: ".")
        var point = components[0].count + exponent
        var digits = components.joined()
        while digits.last == "0", digits.count > 1 { digits.removeLast() }
        while digits.first == "0", digits.count > 1 { digits.removeFirst(); point -= 1 }
        let sign = negative ? "-" : ""
        let fullLength = sign.count + (point <= 0 ? 2 - point + digits.count :
            max(point, digits.count) + (point < digits.count ? 1 : 0))
        // The input grammar permits .125. Use that one-character saving only
        // when necessary to retain an otherwise 33-character exact draft.
        let omitZero = omitLeadingZeroWhenNeeded && point <= 0 && fullLength == 33
        guard fullLength - (omitZero ? 1 : 0) <= 32 else { return nil }
        if point <= 0 {
            return sign + (omitZero ? "." : "0.") + String(repeating: "0", count: -point) + digits
        }
        if point >= digits.count {
            return sign + digits + String(repeating: "0", count: point - digits.count)
        }
        let split = digits.index(digits.startIndex, offsetBy: point)
        return sign + digits[..<split] + "." + digits[split...]
    }

    public static func parse(_ text: String, decimalSeparator: String = ".",
                             in range: ClosedRange<Double>) -> Double? {
        // Bound pasted input before trimming or traversing grapheme clusters.
        // The small whitespace allowance preserves ordinary padded decimals.
        guard isWithinDraftLimit(text),
              decimalSeparator.utf8.prefix(5).count <= 4,
              range.lowerBound.isFinite, range.upperBound.isFinite else { return nil }
        let input = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !input.isEmpty, input.utf8.count <= 96, input.count <= 32,
              decimalSeparator.unicodeScalars.count == 1,
              let scalar = decimalSeparator.unicodeScalars.first,
              !CharacterSet.whitespacesAndNewlines.contains(scalar),
              !CharacterSet.letters.contains(scalar),
              let separator = decimalSeparator.first,
              separator != "+", separator != "-", separator != "−",
              separator.wholeNumberValue == nil else { return nil }
        var canonical = ""
        var seenSeparator = false
        var digits = 0
        for (index, character) in input.enumerated() {
            if index == 0 && (character == "-" || character == "−" || character == "+") {
                if character != "+" { canonical.append("-") }
            } else if character == separator && !seenSeparator {
                canonical.append("."); seenSeparator = true
            } else if character.unicodeScalars.count == 1,
                      character.unicodeScalars.first?.properties.numericType == .decimal,
                      let digit = character.wholeNumberValue, (0...9).contains(digit) {
                canonical.append(String(digit)); digits += 1
            } else {
                return nil
            }
        }
        guard digits > 0, let value = Double(canonical), value.isFinite,
              range.contains(value) else { return nil }
        return value
    }

    /// A valid imported or directly entered value must remain representable
    /// even when it falls outside the quick-adjustment slider's usual span.
    public static func sliderBounds(usual: ClosedRange<Double>, current: Double) -> ClosedRange<Double> {
        guard current.isFinite else { return usual }
        return min(usual.lowerBound, current)...max(usual.upperBound, current)
    }
}

func beforeTarget(_ draft: String, _ locale: Locale) -> Double? {
        // Bound pasted input before the shared parser trims or scans it.
        guard draft.utf8.prefix(97).count <= 96 else { return nil }
        return StudioNumericInput.parse(draft, decimalSeparator: locale.decimalSeparator ?? ".",
                                        in: 0...Double.greatestFiniteMagnitude)
    }

import Foundation

/// Retains the number format that accepted a target-lux draft. A locale
/// change cannot make unchanged text eligible for a different interpretation.
struct LightTargetLuxDraft {
    struct LocaleContext: Equatable {
        let identifier: String
        let decimalSeparator: String

        init(locale: Locale) {
            // Store values, not a potentially autoupdating Locale instance.
            identifier = locale.identifier
            decimalSeparator = locale.decimalSeparator ?? "."
        }
    }

    private(set) var text = ""
    private(set) var rejectedOversizedDraft = false
    private var acceptedLocale: LocaleContext?
    private var localeInvalidated = false

    mutating func initialize(value: Double?, in context: LocaleContext) {
        guard acceptedLocale == nil else { return }
        acceptedLocale = context
        text = value.flatMap {
            StudioNumericInput.editableText($0, decimalSeparator: context.decimalSeparator)
        } ?? ""
    }

    func requiresLocaleEdit(in context: LocaleContext) -> Bool {
        localeInvalidated || acceptedLocale.map { $0 != context } == true
    }

    mutating func invalidate(ifChangedTo context: LocaleContext) {
        guard let acceptedLocale, acceptedLocale != context else { return }
        // Returning to the original locale must not revive a retired draft.
        localeInvalidated = true
    }

    /// True means an actual bounded edit, the only event that may clear the
    /// view's existing validation error or adopt the current number format.
    mutating func replaceText(with replacement: String, in context: LocaleContext) -> Bool {
        guard StudioNumericInput.isWithinDraftLimit(replacement) else {
            rejectedOversizedDraft = true
            return false
        }
        guard replacement != text else { return false }
        text = replacement
        acceptedLocale = context
        localeInvalidated = false
        rejectedOversizedDraft = false
        return true
    }

    func target(in context: LocaleContext) -> Double? {
        // Check immediately for preview and Apply, before onChange may run.
        guard let acceptedLocale, acceptedLocale == context, !localeInvalidated,
              text.utf8.prefix(97).count <= 96 else { return nil }
        return StudioNumericInput.parse(text, decimalSeparator: acceptedLocale.decimalSeparator,
                                        in: 0...Double.greatestFiniteMagnitude)
    }
}


var assertions = 0
var failures = 0
func check(_ condition: Bool, _ label: String) {
    assertions += 1
    if !condition { failures += 1; print("FAIL: \(label)") }
}
let enLocale = Locale(identifier: "en_US")
let frLocale = Locale(identifier: "fr_FR")
let en = LightTargetLuxDraft.LocaleContext(locale: enLocale)
let fr = LightTargetLuxDraft.LocaleContext(locale: frLocale)
let gb = LightTargetLuxDraft.LocaleContext(locale: Locale(identifier: "en_GB"))

// Identical raw text, exact baseline target property, unchanged exact parser.
check(beforeTarget("1,000", enLocale) == nil, "before English rejects comma grouping")
check(beforeTarget("1,000", frLocale) == 1, "before French reinterprets untouched input as one lux")
print("BEFORE: raw 1,000: en_US=nil; fr_FR=1")
var originalWitness = LightTargetLuxDraft()
originalWitness.initialize(value: nil, in: en)
check(originalWitness.replaceText(with: "1,000", in: en), "witness edit accepted as raw text")
check(originalWitness.target(in: en) == nil, "after original English remains rejected")
check(originalWitness.target(in: fr) == nil, "after French cannot reinterpret before observer")
originalWitness.invalidate(ifChangedTo: fr)
check(!originalWitness.replaceText(with: "1,000", in: fr), "same-text callback does not authorize reinterpretation")
check(originalWitness.target(in: fr) == nil, "same-text callback leaves target unavailable")
print("AFTER: raw 1,000: en_US=nil; fr_FR=nil; same-text echo remains nil")

// A genuine new-locale edit can precede delivery of its locale-change observer.
var reordered = LightTargetLuxDraft()
reordered.initialize(value: 12.5, in: en)
check(reordered.replaceText(with: "12,5", in: fr), "new-locale changed edit accepted before observer")
reordered.invalidate(ifChangedTo: fr)
check(reordered.target(in: fr) == 12.5, "delayed observer for accepted locale preserves explicit edit")
check(!reordered.requiresLocaleEdit(in: fr), "delayed same-context observer does not relatch")
check(reordered.target(in: en) == nil, "old context cannot read newly accepted draft")

// Once observed, returning to the previous locale and reseeding cannot revive.
var retired = LightTargetLuxDraft()
retired.initialize(value: 250, in: en)
retired.invalidate(ifChangedTo: fr)
retired.invalidate(ifChangedTo: en)
retired.initialize(value: 999, in: en)
check(retired.text == "250", "reappearance cannot overwrite retired draft")
check(retired.requiresLocaleEdit(in: en) && retired.target(in: en) == nil, "observed locale round trip stays retired")
check(!retired.replaceText(with: "250", in: en), "retired same-text echo rejected")
check(retired.replaceText(with: "250 ", in: en), "explicit raw edit may reauthorize same numeric value")
check(retired.target(in: en) == 250, "raw edit recovery retains numerical interpretation")

// Same separator is not enough to authorize a different locale identifier.
var sameSeparator = LightTargetLuxDraft()
sameSeparator.initialize(value: 5, in: en)
check(en.decimalSeparator == gb.decimalSeparator && en.identifier != gb.identifier, "same-separator fixture is distinct")
check(sameSeparator.target(in: gb) == nil, "identifier mismatch is guarded")
sameSeparator.invalidate(ifChangedTo: gb)
check(sameSeparator.target(in: en) == nil, "same-separator locale transition latches retirement")

// Oversized edits must preserve prior text and context; echoes cannot clear it.
var bounded = LightTargetLuxDraft()
bounded.initialize(value: 250, in: en)
let tooLong = String(repeating: "8", count: 257)
check(!bounded.replaceText(with: tooLong, in: fr), "oversized foreign-context edit rejected")
check(bounded.text == "250" && bounded.rejectedOversizedDraft, "oversize leaves draft and sticky rejection")
check(bounded.target(in: fr) == nil, "oversize cannot adopt different locale")
bounded.invalidate(ifChangedTo: fr)
check(!bounded.replaceText(with: "250", in: fr), "foreign unchanged echo still rejected")
check(bounded.rejectedOversizedDraft && bounded.requiresLocaleEdit(in: fr), "echo preserves both rejection reasons")
check(bounded.replaceText(with: "250,1", in: fr), "changed bounded foreign edit recovers")
check(bounded.target(in: fr) == 250.1 && !bounded.rejectedOversizedDraft, "recovery adopts separator and clears size error")

// Raw 96-byte target limit is separate from 256-byte editing admission.
var limits = LightTargetLuxDraft()
limits.initialize(value: nil, in: en)
check(limits.replaceText(with: String(repeating: " ", count: 95) + "1", in: en), "96 raw bytes admitted")
check(limits.target(in: en) == 1, "96 raw bytes parse")
check(limits.replaceText(with: String(repeating: " ", count: 96) + "1", in: en), "97 raw bytes remain editable")
check(limits.target(in: en) == nil, "97 raw bytes cannot preview or apply")
let boundary256 = String(repeating: " ", count: 255) + "1"
check(limits.replaceText(with: boundary256, in: en), "256 bytes admitted without truncation")
check(limits.text == boundary256 && limits.target(in: en) == nil, "editing admission does not weaken target limit")
check(!limits.replaceText(with: boundary256 + "0", in: fr), "257 bytes rejected before new-context adoption")
check(limits.text == boundary256 && limits.rejectedOversizedDraft, "257 rejection keeps all previous bytes")
check(limits.replaceText(with: String(repeating: "1", count: 33), in: en), "33 digits remain editable")
check(limits.target(in: en) == nil, "32-character grammar remains enforced")

// Unicode decimal digits remain the shared parser's responsibility.
let arLocale = Locale(identifier: "ar_EG")
let ar = LightTargetLuxDraft.LocaleContext(locale: arLocale)
var unicode = LightTargetLuxDraft()
unicode.initialize(value: nil, in: ar)
let arabicValue = "١٢" + ar.decimalSeparator + "٥"
check(unicode.replaceText(with: arabicValue, in: ar), "Arabic decimal draft accepted")
check(unicode.target(in: ar) == 12.5, "Arabic digits retain shared parser behavior")
check(unicode.target(in: en) == nil, "Arabic draft cannot transfer ownership to English")
check(unicode.replaceText(with: "-0", in: en), "negative zero raw edit accepted")
check(unicode.target(in: en)?.bitPattern == (-0.0).bitPattern, "existing signed-zero parser behavior preserved")
check(unicode.replaceText(with: "1e3", in: en), "exponent can be an editing draft")
check(unicode.target(in: en) == nil, "exponent grammar remains rejected")
check(unicode.replaceText(with: "-1", in: en), "negative can be an editing draft")
check(unicode.target(in: en) == nil, "negative lux remains rejected")
print("REVIEW PROBE: \(assertions) assertions; \(failures) failures")
if failures != 0 { exit(1) }
