import Foundation

public struct Position: Codable, Equatable, Sendable {
    public static let coordinateRange: ClosedRange<Double> = -100...100
    public var x: Double
    public var y: Double
    public var z: Double
    public init(x: Double, y: Double, z: Double) {
        self.x = x; self.y = y; self.z = z
    }
    public var isValid: Bool {
        [x, y, z].allSatisfy { $0.isFinite && Self.coordinateRange.contains($0) }
    }
    public func distance(to other: Position) -> Double {
        let dx = x - other.x, dy = y - other.y, dz = z - other.z
        return (dx * dx + dy * dy + dz * dz).squareRoot()
    }
}


import Foundation

public enum PlanUnits: String, CaseIterable, Sendable {
    case metric, imperial
    public var symbol: String { self == .metric ? "m" : "ft" }
    public func fromMeters(_ meters: Double) -> Double { self == .metric ? meters : meters / 0.3048 }
    public func toMeters(_ value: Double) -> Double { self == .metric ? value : value * 0.3048 }
    public func distance(_ meters: Double) -> String { "\(Self.number(fromMeters(meters), decimals: 2)) \(symbol)" }
    public func coordinates(_ position: Position) -> String {
        let values = [position.x, position.y, position.z].map { Self.number(fromMeters($0), decimals: 2) }
        return "(\(values.joined(separator: ", "))) \(symbol)"
    }
    /// Editable parameters retain up to six fractional digits in the report.
    /// Keep a minimum for familiar readouts; derived distances remain at two.
    public static func parameterNumber(_ value: Double, minimumDecimals: Int = 0) -> String {
        let minimum = min(6, max(0, minimumDecimals))
        var text = number(value, decimals: 6)
        guard let dot = text.firstIndex(of: ".") else { return text }
        while text.last == "0", text.distance(from: dot, to: text.endIndex) > minimum + 1 { text.removeLast() }
        if text.last == "." { text.removeLast() }
        return text
    }
    public func parameterDistance(_ meters: Double) -> String {
        "\(Self.parameterNumber(fromMeters(meters), minimumDecimals: 2)) \(symbol)"
    }
    public func parameterCoordinates(_ position: Position) -> String {
        let values = [position.x, position.y, position.z].map { Self.parameterNumber(fromMeters($0), minimumDecimals: 2) }
        return "(\(values.joined(separator: ", "))) \(symbol)"
    }
    /// Wall coordinates and projected overhangs must retain their sign even
    /// below the report's six-decimal display precision. The threshold is in
    /// the selected export unit, not implicitly in meters.
    public func roomDistance(_ meters: Double) -> String {
        let value = fromMeters(meters)
        guard value.isFinite else { return "Unavailable" }
        if value != 0, abs(value) < 0.000001 {
            return value < 0 ? "between -0.000001 and 0 \(symbol)" : "less than 0.000001 \(symbol)"
        }
        return parameterDistance(meters)
    }
    public static func number(_ value: Double, decimals: Int = 1) -> String {
        // Foundation on Apple SDKs rejects the dynamic-precision vararg
        // signature used here previously. A fixed, bounded format has one Double.
        let precision = min(12, max(0, decimals))
        let threshold = 0.5 * pow(10.0, -Double(precision))
        let normalized: Double = abs(value) < threshold ? 0.0 : value
        return String(format: "%.\(precision)f", locale: Locale(identifier: "en_US_POSIX"), normalized)
    }
}

public enum PlanPaper: String, CaseIterable, Sendable {
    case letter, a4
    public var title: String { self == .letter ? "US Letter" : "A4" }
    public var width: Double { self == .letter ? 612 : 595.28 }
    public var height: Double { self == .letter ? 792 : 841.89 }
}

/// x and y in PDF points, or world x and z when explicitly described as world coordinates.
public struct PlanPoint: Equatable, Sendable {
    public let x: Double
    public let y: Double
    public init(x: Double, y: Double) { self.x = x; self.y = y }
    fileprivate init(_ position: Position) { self.init(x: position.x, y: position.z) }
    public func distance(to other: Self) -> Double { hypot(x - other.x, y - other.y) }
}

public struct PlanMarker: Equatable, Sendable {
    public enum Kind: Equatable, Sendable { case subject, camera, light }
    public let kind: Kind
    public let label: String
    /// Actual projected point, never displaced for readability.
    public let anchor: PlanPoint
    /// Numbered label center; a leader connects this to anchor when displaced.
    public let center: PlanPoint
}

public struct PlanLine: Equatable, Sendable {
    public enum Kind: Equatable, Sendable { case camera, aim, modifier }
    public let kind: Kind
    public let points: [PlanPoint]
}

public struct PlanGridLine: Equatable, Sendable {
    public let from: PlanPoint
    public let to: PlanPoint
    public let isAxis: Bool
}

public struct PlanDiagram: Equatable, Sendable {
    public let width: Double
    public let height: Double
    public let pointsPerMeter: Double
    public let worldCenter: PlanPoint
    public let gridStep: Double // in selected display units
    public let grid: [PlanGridLine]
    public let markers: [PlanMarker]
    public let lines: [PlanLine]
    public let units: PlanUnits

    public func project(_ world: PlanPoint) -> PlanPoint {
        .init(x: width / 2 + (world.x - worldCenter.x) * pointsPerMeter,
              y: height / 2 + (world.y - worldCenter.y) * pointsPerMeter)
    }
    public var scaleLabel: String { "Grid: \(PlanUnits.number(gridStep, decimals: gridStep < 1 ? 2 : 1)) \(units.symbol)" }
}


func extractedDiagram(paper: PlanPaper, units: PlanUnits, entries: [(PlanMarker.Kind, String, PlanPoint)], positions: [PlanPoint], worldLines: [(PlanLine.Kind, [PlanPoint])]) -> PlanDiagram {
    let width = paper.width - 80, height = 384.0
        let minX = positions.map(\.x).min()!, maxX = positions.map(\.x).max()!
        let minZ = positions.map(\.y).min()!, maxZ = positions.map(\.y).max()!
        let worldCenter = PlanPoint(x: (minX + maxX) / 2, y: (minZ + maxZ) / 2)
        let padding = 54.0
        let scale = min((width - 2 * padding) / max(2, maxX - minX),
                        (height - 2 * padding) / max(2, maxZ - minZ))
        func project(_ p: PlanPoint) -> PlanPoint {
            .init(x: width / 2 + (p.x - worldCenter.x) * scale,
                  y: height / 2 + (p.y - worldCenter.y) * scale)
        }
        // Select 1/2/5-based grid spacing with ~7 lines along the long side.
        let targetStep = units.fromMeters(max(width, height) / scale) / 7
        let decade = pow(10, floor(log10(targetStep)))
        let step = ([1.0, 2.0, 5.0, 10.0].first { $0 * decade >= targetStep } ?? 10) * decade
        let stepMeters = units.toMeters(step)
        var grid: [PlanGridLine] = []
        let xmin = worldCenter.x - width / (2 * scale), xmax = worldCenter.x + width / (2 * scale)
        let zmin = worldCenter.y - height / (2 * scale), zmax = worldCenter.y + height / (2 * scale)
        func indices(_ minimum: Double, _ maximum: Double) -> [Int] {
            let first = Int(ceil(minimum / stepMeters)), last = Int(floor(maximum / stepMeters))
            return first <= last ? Array(first...last) : []
        }
        for i in indices(xmin, xmax) {
            let x = Double(i) * stepMeters
            grid.append(.init(from: project(.init(x: x, y: zmin)), to: project(.init(x: x, y: zmax)), isAxis: i == 0))
        }
        for i in indices(zmin, zmax) {
            let z = Double(i) * stepMeters
            grid.append(.init(from: project(.init(x: xmin, y: z)), to: project(.init(x: xmax, y: z)), isAxis: i == 0))
        }
        var markers: [PlanMarker] = []
        let labelRadius = 11.0, spacing = 27.0
        // Precompute anchors so displaced labels do not cover other actual positions.
        let anchors = entries.map { project($0.2) }
        for (index, entry) in entries.enumerated() {
            let anchor = anchors[index]
            var candidates = [anchor]
            for ring in 1...5 {
                let radius = spacing * Double(ring), count = 8 * ring
                candidates += (0..<count).map { i in
                    let angle = 2 * Double.pi * Double(i) / Double(count)
                    return PlanPoint(x: anchor.x + radius * cos(angle), y: anchor.y + radius * sin(angle))
                }
            }
            func fits(_ p: PlanPoint) -> Bool {
                p.x >= labelRadius && p.x <= width - labelRadius && p.y >= labelRadius && p.y <= height - labelRadius &&
                markers.allSatisfy { p.distance(to: $0.center) >= spacing - 0.001 }
            }
            // A page-wide lattice is a bounded fallback if all local rings are occupied.
            // There are far more disjoint lattice positions than the 14 supported markers.
            for y in stride(from: labelRadius, through: height - labelRadius, by: spacing) {
                for x in stride(from: labelRadius, through: width - labelRadius, by: spacing) {
                    candidates.append(.init(x: x, y: y))
                }
            }
            let center = candidates.first { candidate in
                fits(candidate) && (candidate == anchor || anchors.enumerated().allSatisfy { j, p in j == index || candidate.distance(to: p) > labelRadius + 3 })
            } ?? candidates.first(where: fits) ?? anchor
            markers.append(.init(kind: entry.0, label: entry.1, anchor: anchor, center: center))
        }
        return .init(width: width, height: height, pointsPerMeter: scale, worldCenter: worldCenter,
                     gridStep: step, grid: grid, markers: markers,
                     lines: worldLines.map { .init(kind: $0.0, points: $0.1.map(project)) }, units: units)
}
var cases = 0
var largestGrid = 0
var minimumSeparation = Double.infinity
for paper in PlanPaper.allCases {
    for units in PlanUnits.allCases {
        for value in [-100.0, 0, 100] {
            let entries: [(PlanMarker.Kind, String, PlanPoint)] = (0..<14).map { i in
                (i == 0 ? .subject : i == 1 ? .camera : .light, String(i), .init(x: value, y: value))
            }
            let diagram = extractedDiagram(paper: paper, units: units, entries: entries, positions: entries.map { $0.2 }, worldLines: [])
            precondition(diagram.grid.count <= 18)
            precondition(diagram.pointsPerMeter.isFinite && diagram.pointsPerMeter > 0)
            precondition(diagram.gridStep.isFinite && diagram.gridStep > 0)
            for (i, marker) in diagram.markers.enumerated() {
                precondition((11...diagram.width - 11).contains(marker.center.x))
                precondition((11...diagram.height - 11).contains(marker.center.y))
                for other in diagram.markers.dropFirst(i + 1) {
                    let distance = marker.center.distance(to: other.center)
                    precondition(distance >= 26.999)
                    minimumSeparation = min(minimumSeparation, distance)
                }
            }
            largestGrid = max(largestGrid, diagram.grid.count)
            cases += 1
        }
        let points: [PlanPoint] = [.init(x: -104, y: -104), .init(x: -104, y: 104), .init(x: 104, y: 104), .init(x: 104, y: -104)]
        let entries: [(PlanMarker.Kind, String, PlanPoint)] = (0..<14).map { i in
            (i == 0 ? .subject : i == 1 ? .camera : .light, String(i), points[i % 4])
        }
        let diagram = extractedDiagram(paper: paper, units: units, entries: entries, positions: points, worldLines: [(.modifier, points)])
        precondition(diagram.grid.count <= 18)
        for p in diagram.lines.flatMap(\.points) + diagram.markers.map(\.anchor) {
            precondition(p.x.isFinite && p.y.isFinite)
            precondition((0...diagram.width).contains(p.x) && (0...diagram.height).contains(p.y))
        }
        largestGrid = max(largestGrid, diagram.grid.count)
        cases += 1
    }
}
print("Extracted source diagram cases: \(cases); largest observed grid: \(largestGrid); minimum crowded-label separation: \(minimumSeparation)")
print("Scope: source math only; +/-104m synthetic corner envelope is conservative, not a full scene or PDF runtime.")
