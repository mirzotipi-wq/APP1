import Foundation

struct BeforeDraft {
    var draft: String
    var locale: Locale
    var target: Double? {
        // Bound pasted input before the shared parser trims or scans it.
        guard draft.utf8.prefix(97).count <= 96 else { return nil }
        return StudioNumericInput.parse(draft, decimalSeparator: locale.decimalSeparator ?? ".",
                                        in: 0...Double.greatestFiniteMagnitude)
    }
}

var input = BeforeDraft(draft: "1,000", locale: Locale(identifier: "en_US"))
precondition(input.target == nil)
print("Before: en_US raw=\(input.draft), target=nil")
input.locale = Locale(identifier: "fr_FR")
precondition(input.draft == "1,000")
print("Before: fr_FR unchanged raw=\(input.draft), target=\(String(describing: input.target))")
if input.target != nil {
    print("FAIL: unchanged English-invalid draft became accepted after locale-only change")
    exit(1)
}
