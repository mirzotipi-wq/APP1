// Source: 700486b83740f6fa1d4c470ed9befa805268c00c
import Foundation
#if canImport(SwiftUI) && canImport(CoreGraphics)
import SwiftUI
import CoreGraphics
#endif

/// The publication seam has no dependency on a GPU or on image conversion.
/// Tests can finish a noncooperative renderer after a newer request has won.
struct StudyPreviewOutput: Sendable {
    let image: StudyImage
    let backendLabel: String
}

@MainActor final class StudyPreviewPipeline<DisplayImage> {
    struct Completion {
        let image: DisplayImage?
        let unsupportedPixels: Int
        let backendLabel: String?
        let message: String?
    }

    private var current: UUID?

    /// Begin even when reusing a completed frame: an A → B → A switch must
    /// invalidate B without requiring another render of the cached A image.
    /// A cancelled caller gets an unused ticket without superseding live work.
    func begin() -> UUID {
        let ticket = UUID()
        guard !Task.isCancelled else { return ticket }
        current = ticket
        return ticket
    }

    func invalidate() { current = nil }

    func load(ticket: UUID,
              render: () async throws -> StudyPreviewOutput,
              convert: (StudyImage) -> DisplayImage?,
              publish: (Completion) -> Void) async {
        guard current == ticket, !Task.isCancelled else { return }
        do {
            let output = try await render()
            guard current == ticket, !Task.isCancelled else { return }
            let image = convert(output.image)
            guard current == ticket, !Task.isCancelled else { return }
            publish(.init(image: image, unsupportedPixels: image == nil ? 0 : output.image.unsupportedPixels,
                          backendLabel: image == nil ? nil : output.backendLabel,
                          message: image == nil ? "The rendered image could not be displayed." : nil))
        } catch {
            guard current == ticket, !Task.isCancelled, !(error is CancellationError),
                  (error as? StudyError) != .cancelled else { return }
            let message: String
            switch error as? StudyError {
            case .invalidCamera: message = "Move the camera above the panel and away from the subject."
            case .invalidEmitter: message = "Check the aiming direction of each active light."
            default: message = "Check the camera, light positions, and preview settings."
            }
            publish(.init(image: nil, unsupportedPixels: 0, backendLabel: nil, message: message))
        }
    }
}


// Only payload types are replaced; publication logic above is exact source 700486b.
// This probe does not render or validate images, and has no SwiftUI/Metal execution.
struct StudyImage: Sendable { let rgba: Data; let unsupportedPixels: Int }
enum StudyError: Error, Equatable {
    case invalidScene, invalidCamera, invalidEmitter, invalidResolution, invalidSurface, invalidComputeOutput, cancelled
}
@MainActor final class Gate {
    private var continuation: CheckedContinuation<StudyPreviewOutput, Error>?
    private var started = false
    private var waiters: [CheckedContinuation<Void, Never>] = []
    func render() async throws -> StudyPreviewOutput {
        try await withCheckedThrowingContinuation {
            continuation = $0; started = true
            waiters.forEach { $0.resume() }; waiters.removeAll()
        }
    }
    func waitUntilStarted() async {
        if started { return }
        await withCheckedContinuation { waiters.append($0) }
    }
    func finish(_ result: Result<StudyPreviewOutput, Error>) {
        precondition(continuation != nil)
        continuation?.resume(with: result); continuation = nil
    }
}
@main @MainActor struct Probe {
    static func output(_ byte: UInt8) -> StudyPreviewOutput {
        .init(image: .init(rgba: Data([byte]), unsupportedPixels: 3), backendLabel: "synthetic")
    }
    static func main() async {
        for lateFailure in [false, true] {
            let pipeline = StudyPreviewPipeline<UInt8>(), old = Gate()
            var completions: [StudyPreviewPipeline<UInt8>.Completion] = []
            let oldTicket = pipeline.begin()
            let task = Task { await pipeline.load(ticket: oldTicket, render: old.render,
                convert: { $0.rgba[0] }, publish: { completions.append($0) }) }
            await old.waitUntilStarted()
            await pipeline.load(ticket: pipeline.begin(), render: { output(2) },
                convert: { $0.rgba[0] }, publish: { completions.append($0) })
            old.finish(lateFailure ? .failure(StudyError.invalidCamera) : .success(output(1)))
            await task.value
            precondition(completions.count == 1 && completions[0].image == 2 && completions[0].message == nil)
            print("PASS late \(lateFailure ? "error" : "success") cannot replace newer completion")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>(), old = Gate()
            var published = 0
            _ = pipeline.begin()
            let ticketB = pipeline.begin()
            let task = Task { await pipeline.load(ticket: ticketB, render: old.render,
                convert: { $0.rgba[0] }, publish: { _ in published += 1 }) }
            await old.waitUntilStarted()
            _ = pipeline.begin()
            old.finish(.success(output(4)))
            await task.value
            precondition(published == 0)
            print("PASS A-B-A ticket reuse discards intermediate completion")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>(), old = Gate()
            let ticket = pipeline.begin()
            var published = 0, converted = 0
            let task = Task { await pipeline.load(ticket: ticket, render: old.render,
                convert: { converted += 1; return $0.rgba[0] }, publish: { _ in published += 1 }) }
            await old.waitUntilStarted()
            task.cancel()
            old.finish(.success(output(5)))
            await task.value
            precondition(published == 0 && converted == 0)
            print("PASS actual task cancellation rejects noncooperative success before conversion")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>(), old = Gate()
            let ticket = pipeline.begin()
            var published = 0
            let task = Task { await pipeline.load(ticket: ticket, render: old.render,
                convert: { $0.rgba[0] }, publish: { _ in published += 1 }) }
            await old.waitUntilStarted()
            pipeline.invalidate()
            old.finish(.failure(StudyError.invalidEmitter))
            await task.value
            precondition(published == 0)
            print("PASS lifecycle invalidation suppresses delayed failure")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>(), live = Gate()
            let ticket = pipeline.begin()
            var published: [UInt8] = []
            let task = Task { await pipeline.load(ticket: ticket, render: live.render,
                convert: { $0.rgba[0] }, publish: { published.append($0.image!) }) }
            await live.waitUntilStarted()
            let cancelledTask = Task { @MainActor in
                precondition(Task.isCancelled)
                await pipeline.load(ticket: pipeline.begin(), render: { preconditionFailure("cancelled render") },
                    convert: { $0.rgba[0] }, publish: { _ in preconditionFailure("cancelled publication") })
            }
            cancelledTask.cancel()
            await cancelledTask.value
            live.finish(.success(output(9)))
            await task.value
            precondition(published == [9])
            print("PASS precancelled begin preserves live request")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>()
            var completions: [StudyPreviewPipeline<UInt8>.Completion] = []
            await pipeline.load(ticket: pipeline.begin(), render: { throw StudyError.invalidCamera },
                convert: { $0.rgba[0] }, publish: { completions.append($0) })
            await pipeline.load(ticket: pipeline.begin(), render: { output(6) },
                convert: { $0.rgba[0] }, publish: { completions.append($0) })
            precondition(completions.count == 2 && completions[0].image == nil && completions[0].backendLabel == nil)
            precondition(completions[1].image == 6 && completions[1].message == nil && completions[1].unsupportedPixels == 3)
            print("PASS current failure and retry replace metadata together")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>()
            var completion: StudyPreviewPipeline<UInt8>.Completion?
            await pipeline.load(ticket: pipeline.begin(), render: { output(7) },
                convert: { _ in nil }, publish: { completion = $0 })
            precondition(completion != nil && completion?.image == nil && completion?.backendLabel == nil && completion?.unsupportedPixels == 0)
            print("PASS failed conversion cannot retain successful backend or warning metadata")
        }
        do {
            let pipeline = StudyPreviewPipeline<UInt8>()
            var published = 0
            await pipeline.load(ticket: pipeline.begin(), render: { output(8) },
                convert: { image in pipeline.invalidate(); return image.rgba[0] },
                publish: { _ in published += 1 })
            precondition(published == 0)
            print("PASS invalidation during conversion suppresses completion")
        }
    }
}
