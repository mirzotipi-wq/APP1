"""Recheck retained current accessibility evidence; does not execute the app."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import plistlib
import re
import stat
import zipfile
import zstandard

P = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def audit_archive(receipt_name, directory):
    receipt = json.loads((P / receipt_name).read_text())
    data = (P / receipt["archive"]).read_bytes()
    assert len(data) == receipt["bytes"] and digest(data) == receipt["sha256"]
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None
        seen = set()
        for info in z.infolist():
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and ".." not in path.parts
            assert "\\" not in info.filename and info.filename not in seen
            assert not stat.S_ISLNK(info.external_attr >> 16) and not info.flag_bits & 1
            seen.add(info.filename)
        for item in receipt["files"]:
            raw = z.read(item["path"])
            assert len(raw) == item["bytes"] and digest(raw) == item["sha256"]
            assert raw == (P / directory / item["path"]).read_bytes()
    return receipt


audit_archive("archive-receipt.json", "originals")
audit_archive("full-archive-receipt.json", "full")
job = json.loads((P / "github-job.json").read_text())
assert job["id"] == 140527589886 and job["conclusion"] == "failure"
record = json.loads((P / "reconciliation.json").read_text())
log = (P / "full/native-tests.log").read_text()
events = re.findall(r"Test Case '-\[KeyAndFillUITests\.(\w+) (\w+)\]' (started|passed|failed|skipped)", log)
assert [list(e) for e in events] == record["events"]
assert [e[2] for e in events] == ["started", "failed"]
assert "Requested size: AXXXL" not in log
for capture in record["captures"]:
    assert digest((P / capture["file"]).read_bytes()) == capture["sha256"]
assert sum(c["name"].startswith("Default-") for c in record["captures"]) == 5
with zipfile.ZipFile(P / "full/artifacts/native-results.zip") as z:
    assert plistlib.loads(z.read("NativeTests.xcresult/Info.plist"))["rootId"]
    for item in json.loads((P / "diagnostics-receipt.json").read_text()):
        raw = z.read(item["source"])
        assert digest(raw) == item["compressedSHA256"]
        with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw)) as reader:
            decoded = reader.read(20_000_001)
        assert len(decoded) <= 20_000_000
        assert digest(decoded) == item["decodedSHA256"]
        assert decoded == (P / "diagnostics" / item["decoded"]).read_bytes()
print("Verified current source-bound artifacts, 1 failed method, 5 required Default PNGs, 1 diagnostic PNG and exact diagnostic log decoding.")
