#!/usr/bin/env python3
"""Hash, validate, and retain originals; never execute artifact content."""
import hashlib
import json
import stat
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
METADATA = json.loads((ROOT / "github-precutover-artifacts.json").read_text())
BY_ID = {item["id"]: item for item in METADATA["artifacts"]}
SPECS = (
    (15198159888, "studio-export-compact-original.zip", "studio-export-compact"),
    (15199237483, "studio-export-full-original.zip", "studio-export-full"),
)
receipts = []
for artifact_id, archive_name, directory in SPECS:
    metadata = BY_ID[artifact_id]
    archive = ROOT / archive_name
    destination = ROOT / directory
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert archive.stat().st_size == metadata["size_in_bytes"]
    assert metadata["digest"] == "sha256:" + actual
    assert metadata["workflow_run"]["head_sha"] == "134f9adabe0203b1d6d8ed21abb6aaeb4e19d256"
    assert not destination.exists()
    with zipfile.ZipFile(archive) as z:
        entries = z.infolist()
        assert len(entries) <= 5000
        assert sum(item.file_size for item in entries) <= 512 * 1024 * 1024
        assert len({item.filename for item in entries}) == len(entries)
        for item in entries:
            p = PurePosixPath(item.filename)
            assert p.parts and not p.is_absolute() and ".." not in p.parts
            assert "\\" not in item.filename and ":" not in p.parts[0]
            assert str(p) == item.filename.rstrip("/")
            assert not (item.flag_bits & 1)
            kind = stat.S_IFMT(item.external_attr >> 16)
            assert kind in (0, stat.S_IFREG, stat.S_IFDIR)
            assert not stat.S_ISLNK(item.external_attr >> 16)
            assert item.file_size <= 256 * 1024 * 1024
        assert z.testzip() is None
        destination.mkdir()
        files = []
        for item in entries:
            target = destination.joinpath(*PurePosixPath(item.filename).parts)
            assert target.resolve().is_relative_to(destination.resolve())
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            content = z.read(item)
            target.open("xb").write(content)
            files.append({"path": item.filename, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(), "zip_crc32": format(item.CRC, "08x")})
    receipts.append({"artifact": metadata, "archive": archive.name, "archive_sha256": actual, "digest_matches": True, "extracted_directory": directory, "file_count": len(files), "files": files, "safe_zip_checks": ["unique canonical relative paths", "no traversal/backslash/absolute paths", "no symlinks/special files", "no encrypted entries", "bounded entry count and expanded sizes", "every CRC verified", "no destination overwrite"], "nested_archives": "Retained as original files; not executed or extracted."})
(ROOT / "artifact-receipts.json").write_text(json.dumps(receipts, indent=2, sort_keys=True) + "\n")
for receipt in receipts:
    print(json.dumps({"artifact_id": receipt["artifact"]["id"], "name": receipt["artifact"]["name"], "bytes": receipt["artifact"]["size_in_bytes"], "sha256": receipt["archive_sha256"], "file_count": receipt["file_count"], "png_count": sum(item["path"].lower().endswith(".png") for item in receipt["files"])}))
