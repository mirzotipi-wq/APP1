#!/usr/bin/env python3
"""Read-only, pinned-source inventory for superseded workflow run 45999974158."""
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3] / "APP1"
DEST = Path(__file__).resolve().parent
SHA = "134f9adabe0203b1d6d8ed21abb6aaeb4e19d256"

def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])

def source(path):
    return git("show", f"{SHA}:{path}")

def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")

tree = git("rev-parse", f"{SHA}^{{tree}}").decode().strip()
paths = git("ls-tree", "-r", "--name-only", SHA, "App", "Sources", "NativeTests", "UITests", "Package.swift", "project.yml", "scripts/native_test_shards.py", ".github/workflows/ios-prototype.yml").decode().splitlines()
blobs = {path: source(path) for path in paths}
file_inventory = {path: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "git_blob_sha": hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()} for path, data in sorted(blobs.items())}
parser_path = "scripts/native_test_shards.py"
mapping = {}
for node in ast.parse(blobs[parser_path]).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in {"SHARDS", "DIAGNOSTIC_SHARDS"}:
                mapping[target.id] = ast.literal_eval(node.value)
assert set(mapping) == {"SHARDS", "DIAGNOSTIC_SHARDS"}
methods_by_class = {}
for directory in ("NativeTests", "UITests"):
    inventory = {}
    for path, data in sorted(blobs.items()):
        if not path.startswith(directory + "/") or not path.endswith(".swift"):
            continue
        content = data.decode("utf-8")
        methods = re.findall(r"\bfunc\s+(test\w*)\s*\(", content)
        if not methods:
            continue
        classes = re.findall(r"\bclass\s+(\w+)\s*:\s*XCTestCase\b", content)
        assert len(classes) == 1 and len(methods) == len(set(methods)) and classes[0] not in inventory, path
        inventory[classes[0]] = {"source": path, "methods": sorted(methods)}
    methods_by_class[directory] = inventory
required_classes = [cls for group in mapping["SHARDS"].values() for cls in group]
diagnostic_classes = [cls for group in mapping["DIAGNOSTIC_SHARDS"].values() for cls in group]
assert len(required_classes + diagnostic_classes) == len(set(required_classes + diagnostic_classes))
assert set(required_classes + diagnostic_classes) == set(methods_by_class["UITests"])
shards = {"unit": {"target": "KeyAndFillTests", "methods": sorted(f"{cls}.{method}" for cls, item in methods_by_class["NativeTests"].items() for method in item["methods"])}}
for name, classes in {**mapping["SHARDS"], **mapping["DIAGNOSTIC_SHARDS"]}.items():
    shards[name] = {"target": "KeyAndFillUITests", "diagnostic": name in mapping["DIAGNOSTIC_SHARDS"], "classes": list(classes), "methods": sorted(f"{cls}.{method}" for cls in classes for method in methods_by_class["UITests"][cls]["methods"])}
counts = {key: len(value["methods"]) for key, value in shards.items()}
assert counts["unit"] == 314, counts
assert sum(counts[name] for name in mapping["SHARDS"]) == 44, counts
assert sum(counts[name] for name in mapping["DIAGNOSTIC_SHARDS"]) == 2, counts
report = {"schema": 1, "source_sha": SHA, "tree_sha": tree, "workflow_run": 45999974158, "method_counts": counts, "required_native_count": 314, "required_ui_count": 44, "diagnostic_ui_count": 2, "source_files": file_inventory, "classes": methods_by_class, "shards": shards, "limits": ["Inventory is a source obligation, not an execution result.", "The simulator-only conditional in StudioSmokeTests is included because these jobs target iOS Simulator.", "Two platform audit methods are separately dispatched diagnostics, not part of this required run."]}
write(DEST / "source-inventory.json", report)
print(json.dumps({"source_sha": SHA, "tree_sha": tree, "input_files": len(file_inventory), "method_counts": counts}, sort_keys=True))
