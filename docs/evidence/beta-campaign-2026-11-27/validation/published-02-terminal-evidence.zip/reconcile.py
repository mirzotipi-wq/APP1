#!/usr/bin/env python3
"""Reconcile original job consoles without treating interruption as success."""
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

DEST = Path(__file__).resolve().parent
INVENTORY = json.loads((DEST / "source-inventory.json").read_text())
CHECKPOINT = "--apple-checkpoint" in sys.argv
PREFIX = "github-apple-terminal" if CHECKPOINT else "github-terminal"
RUN = json.loads((DEST / f"{PREFIX}-run.json").read_text())["data"]
JOBS_PACKET = json.loads((DEST / f"{PREFIX}-jobs.json").read_text())
JOBS = JOBS_PACKET["data"]
assert RUN["id"] == 45999974158 and RUN["head_sha"] == INVENTORY["source_sha"]
assert JOBS["total_count"] == len(JOBS["jobs"]), "Pagination is incomplete"
if not CHECKPOINT:
    assert RUN["status"] == "completed" and all(job["status"] == "completed" for job in JOBS["jobs"])
BY_ID = {job["id"]: job for job in JOBS["jobs"]}
SELECTION = {
    140511739635: "unit", 140511739618: "studio-export",
    140511739640: "app-accessibility", 140511739680: "library-reference",
    140511739682: "room-precision", 140511739714: "studio-optics",
}
assert all(BY_ID[job_id]["status"] == "completed" for job_id in SELECTION)
TIMESTAMP = re.compile(r"^(?P<time>\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z)\s*")
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
EVENT = re.compile(r"Test Case '-\[(?P<target>[^.\s\[\]]+)\.(?P<class>\w+) (?P<method>\w+)\]' (?P<event>started|passed|failed|skipped)(?: \(\d+(?:\.\d+)? seconds\))?\.?\s*")
CATEGORIES = ("passed", "failed", "skipped", "incomplete", "unstarted", "unverified", "invalid_sequence")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def normalize(line):
    clean = ANSI.sub("", line)
    timestamp = TIMESTAMP.match(clean)
    return (clean[timestamp.end():] if timestamp else clean), (timestamp["time"] if timestamp else None)

def analyse(job_id, shard):
    job = BY_ID[job_id]
    assert job["head_sha"] == INVENTORY["source_sha"]
    expected = set(INVENTORY["shards"][shard]["methods"])
    target = INVENTORY["shards"][shard]["target"]
    log = DEST / f"job-{job_id}.log"
    events = {method: [] for method in expected}
    invalid_events = []
    markers = []
    failure_context = []
    attachment_emissions = []
    lines = log.read_text(errors="replace").splitlines() if log.exists() else []
    for number, line in enumerate(lines, 1):
        clean, timestamp = normalize(line)
        attachment = re.search(r"Added attachment named '([^']+)'", clean)
        if attachment:
            attachment_emissions.append({"line": number, "utc": timestamp, "name": attachment[1]})
        # Workflow commands echo regex literals containing Test Case. Only
        # complete XCTest event lines from the real console count as execution.
        match = EVENT.fullmatch(clean)
        if match:
            name = f"{match['class']}.{match['method']}"
            event = {"line": number, "utc": timestamp, "event": match["event"]}
            if match["target"] != target or name not in expected:
                invalid_events.append({**event, "target": match["target"], "method": name})
            else:
                events[name].append(event)
        elif clean.startswith("Test Case '-["):
            invalid_events.append({"line": number, "utc": timestamp, "text": clean, "reason": "Unrecognized XCTest event"})
        if any(term in clean for term in ("** TEST BUILD SUCCEEDED **", "** BUILD SUCCEEDED **", "** TEST SUCCEEDED **", "** TEST FAILED **", "** TEST EXECUTE FAILED **", "The operation was canceled", "Cancelling since a higher priority", "Canceling since a higher priority", "The job running on runner", "Native command start:", "Native command exit:", "Native shell exit:")):
            if not clean.startswith(("echo ", "printf ")):
                markers.append({"line": number, "utc": timestamp, "text": clean})
        if re.search(r"(?:error: -\[|XCTAssert.*failed|Assertion Failure:|##\[error\]|failed -|Failed to initialize for UI testing:|test runner failed to initialize|Simulator startup.*(?:timed_out|not_started|failed))", clean):
            failure_context.append({"line": number, "utc": timestamp, "text": clean})
    no_execution = not job.get("runner_name") and not job.get("steps")
    categories = {name: [] for name in CATEGORIES}
    started = []
    for method in sorted(expected):
        sequence = [event["event"] for event in events[method]]
        if "started" in sequence:
            started.append(method)
        if sequence == ["started", "passed"]:
            category = "passed"
        elif "failed" in sequence:
            category = "failed"
        elif "skipped" in sequence:
            category = "skipped"
        elif "started" in sequence and not any(x in sequence for x in ("passed", "failed", "skipped")):
            category = "incomplete"
        elif not sequence:
            category = "unstarted" if log.exists() or no_execution else "unverified"
        else:
            category = "invalid_sequence"
        categories[category].append(method)
    assert sum(map(len, categories.values())) == len(expected)
    build = next((step for step in job.get("steps", []) if step["name"] in ("Build native UI test bundle", "Build unsigned simulator app and native unit test bundle")), None)
    build_markers = [marker for marker in markers if "** TEST BUILD SUCCEEDED **" in marker["text"]]
    source_bound = INVENTORY["source_sha"] in "\n".join(lines)
    if log.exists():
        assert source_bound, f"No pinned source revision in console {job_id}"
    return {
        "job_id": job_id, "shard": shard, "job_name": job["name"], "status": job["status"], "conclusion": job["conclusion"],
        "started_at_metadata": job.get("started_at"), "completed_at": job.get("completed_at"),
        "runner_name": job.get("runner_name"), "runner_id": job.get("runner_id"),
        "no_execution_from_metadata": no_execution,
        "log": log.name if log.exists() else None, "log_sha256": sha(log) if log.exists() else None,
        "pinned_source_sha_found_in_console": source_bound,
        "expected_count": len(expected), "observed_start_count": len(started),
        "counts": {key: len(value) for key, value in categories.items()},
        "started": started, "methods": categories,
        "method_events": {name: items for name, items in sorted(events.items()) if items},
        "unrecognized_or_foreign_events": invalid_events,
        "build_step": build, "build_success_console_markers": build_markers,
        "warmup_step": next((step for step in job.get("steps", []) if step["name"] == "Warm selected iPhone simulator (diagnostic)"), None),
        "raw_warmup_failures": [item for item in failure_context if "Simulator startup" in item["text"]],
        "accounting_step": next((step for step in job.get("steps", []) if "method accounting" in step["name"]), None),
        "result_export_step": next((step for step in job.get("steps", []) if step["name"] == "Export finalized XCTest result bundle and genuine attachments"), None),
        "console_markers": markers, "failure_context": failure_context,
        "attachment_emissions": attachment_emissions,
        "attachment_limits": "Console emissions do not establish exported, retained or visually reviewed original files.",
        "interpretation": "No observed start is reported as unstarted; when a job ran but its console is unavailable, methods remain unverified. Incomplete means a start without any terminal event. Job cancellation never creates a pass.",
    }

results = {shard: analyse(job_id, shard) for job_id, shard in SELECTION.items()}
ui = [value for key, value in results.items() if key != "unit"]
core_path = DEST.parent / "published-core-02/reconciliation.json"
auxiliary = []
for job in JOBS["jobs"]:
    if job["id"] in SELECTION or job["conclusion"] != "failure":
        continue
    log = DEST / f"job-{job['id']}.log"
    errors = []
    if log.exists():
        for number, line in enumerate(log.read_text(errors="replace").splitlines(), 1):
            clean, timestamp = normalize(line)
            if "##[error]" in clean:
                errors.append({"line": number, "utc": timestamp, "text": clean})
    auxiliary.append({"job_id": job["id"], "name": job["name"], "conclusion": job["conclusion"], "log": log.name if log.exists() else None, "log_sha256": sha(log) if log.exists() else None, "errors": errors})
report = {
    "schema": 1, "task": "/root/a081_superseded_run_evidence", "source_sha": INVENTORY["source_sha"], "source_tree_sha": INVENTORY["tree_sha"],
    "scope": "Apple jobs terminal; whole workflow pending" if CHECKPOINT else "Whole workflow terminal",
    "run_id": RUN["id"], "run_attempt": RUN["run_attempt"], "run_status": RUN["status"], "run_conclusion": RUN["conclusion"],
    "terminal_observed_at_utc": JOBS_PACKET["observed_at_utc"],
    "source_inventory_sha256": sha(DEST / "source-inventory.json"),
    "required_native": {"expected": 314, "started": results["unit"]["observed_start_count"], **results["unit"]["counts"]},
    "required_ui": {"expected": 44, "started": sum(x["observed_start_count"] for x in ui), **{key: sum(x["counts"][key] for x in ui) for key in CATEGORIES}},
    "ui_build_steps_successful": sum(x["build_step"] is not None and x["build_step"].get("conclusion") == "success" for x in ui),
    "ui_build_success_console_markers": sum(bool(x["build_success_console_markers"]) for x in ui),
    "jobs": results,
    "all_terminal_job_dispositions": [{"id": job["id"], "name": job["name"], "status": job["status"], "conclusion": job["conclusion"]} for job in JOBS["jobs"]],
    "auxiliary_failure_jobs": auxiliary,
    "portable_receipt_reference": {"path": str(core_path.relative_to(DEST.parents[2])), "sha256": sha(core_path), "independently_reconciled_by_worker": "072", "core_job_conclusion": BY_ID[140508813441]["conclusion"], "not_reexecuted_or_rereconciled_here": True},
    "limitations": ["Per-method terminal events and job conclusions are separate evidence.", "No local build, test, simulator, or workflow rerun was performed.", "No image or finalized xcresult review is implied by console capture.", "Native/Metal, macOS, simulator Release and arm64 device Release acceptance cannot be inferred from UI bundle compile success.", "The source-known dirty-library fixture contradiction and target-lux locale gap motivated replacement; no runtime failure causality is inferred from those source findings."]
}
if not CHECKPOINT:
    artifacts_path = DEST / "github-terminal-artifacts.json"
    artifacts = json.loads(artifacts_path.read_text())["artifacts"]
    assert all(item["workflow_run"]["id"] == RUN["id"] and item["workflow_run"]["head_sha"] == INVENTORY["source_sha"] for item in artifacts)
    report["artifact_inventory"] = {"path": artifacts_path.name, "sha256": sha(artifacts_path), "count": len(artifacts)}
    report["superseding_run_notification"] = json.loads((DEST / "superseding-run-notification.json").read_text())
    report["retained_artifact_receipts"] = {name: sha(DEST / name) for name in ("artifact-receipts.json", "studio-export-reconciliation.json", "studio-optics-compact-reconciliation.json")}
    recovery_path = DEST.parent / "085/recovery.json"
    recovery = json.loads(recovery_path.read_text())
    assert sha(recovery_path) == "bb6478352b5f3f05141db71a851233521449c3ed5918b58e0d609ca0a41eb38d"
    assert recovery["artifact"]["workflow_run"]["head_sha"] == INVENTORY["source_sha"]
    assert recovery["job_id"] == 140511739640
    report["independent_accessibility_recovery"] = {
        "worker": "085", "path": "campaign/evidence/085/recovery.json", "sha256": sha(recovery_path),
        "review_here": "Read the final independent receipt and exact session launch excerpt; verified their hashes. Original archive recovery was performed by worker 085.",
        "default_capture_emission_count": recovery["default_capture_emission_count"],
        "axxxl_capture_emission_count": recovery["axxxl_capture_emission_count"],
        "largest_size_execution_status": recovery["largest_size_execution_status"],
        "observed_launches": recovery["observed_launches"],
        "recovered_original_png_count": recovery["recovered_original_png_count"],
        "visually_reviewed_original_png_count": recovery["visually_reviewed_original_png_count"],
        "limits": "The AXXXL launch was entered at 13:06:10.840; zero AXXXL capture emissions and zero recoverable screenshot originals do not pass the 28-image gate."
    }
OUTPUT = DEST / ("apple-method-reconciliation.json" if CHECKPOINT else "reconciliation.json")
OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: report[key] for key in ("source_sha", "run_conclusion", "required_native", "required_ui", "ui_build_steps_successful", "ui_build_success_console_markers")}, sort_keys=True))
print("receipt_sha256=" + sha(OUTPUT))
