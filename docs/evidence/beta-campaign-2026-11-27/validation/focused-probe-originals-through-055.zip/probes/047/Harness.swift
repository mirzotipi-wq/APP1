import Foundation
import Foundation

public enum PlanUnits: String, CaseIterable, Sendable {
    case metric, imperial
    public var symbol: String { self == .metric ? "m" : "ft" }
    public func fromMeters(_ meters: Double) -> Double { self == .metric ? meters : meters / 0.3048 }
    public func toMeters(_ value: Double) -> Double { self == .metric ? value : value * 0.3048 }
}

enum StudioPreferences {
static func units(from rawValue: String) -> PlanUnits {
        PlanUnits(rawValue: rawValue) ?? .metric
    }
}
final class DistanceHarness {
    var value: Double
    let range: ClosedRange<Double>
    var unitsRawValue: String
    init(_ value: Double, _ range: ClosedRange<Double>, _ units: PlanUnits) {
        self.value=value; self.range=range; self.unitsRawValue=units.rawValue
    }
static func convertedRange(_ meters: ClosedRange<Double>,
                                       units: PlanUnits) -> ClosedRange<Double>? {
        let lower = units.fromMeters(meters.lowerBound)
        let upper = units.fromMeters(meters.upperBound)
        guard meters.lowerBound.isFinite, meters.upperBound.isFinite,
              lower.isFinite, upper.isFinite, lower <= upper,
              units.toMeters(lower).isFinite, units.toMeters(upper).isFinite else { return nil }
        return lower...upper
    }
    func set(_ entered: Double, units: PlanUnits, displayRange: ClosedRange<Double>?) {
            // Reject a late Apply from a sheet whose unit identity has changed.
            guard units == StudioPreferences.units(from: unitsRawValue) else { return }
            guard let displayRange, entered.isFinite, displayRange.contains(entered) else { return }
            // A numerically unchanged edit must preserve the exact original SI
            // value, including signed zero and feet -> meters round-trip drift.
            guard entered != units.fromMeters(value) else { return }
            let meters: Double
            if entered == displayRange.lowerBound {
                meters = range.lowerBound
            } else if entered == displayRange.upperBound {
                meters = range.upperBound
            } else {
                meters = units.toMeters(entered)
            }
            // Preserve exact SI endpoints when their converted Double would
            // otherwise round just outside the domain. Other input is validated,
            // never clamped or snapped to a slider increment.
            guard meters.isFinite, range.contains(meters),
                  units.fromMeters(meters).isFinite else { return }
            value = meters
    }
}
final class ApplyHarness {
    struct Underlying { var wrappedValue: Double }
    enum InputError { case invalidDecimal, oversizedDraft }
    var writes=0
    var value: Double { didSet { writes += 1 } }
    var range: ClosedRange<Double>
    var underlyingValue: Underlying?
    var isPresented=true
    var locale: Locale
    var focused=true
    var draft: String
    var initialDraft: String
    var inputError: InputError?
    var active=true
    var originalValueBits: UInt64?
    var originalUnderlyingValueBits: UInt64?
    var originalLocale: Locale
    var originalRange: ClosedRange<Double>?
    init(_ value: Double, range: ClosedRange<Double> = -100...100, locale: Locale = Locale(identifier: "en_US_POSIX"), underlying: Double? = nil) {
        self.value=value; self.range=range; self.locale=locale; originalLocale=locale
        originalValueBits=value.bitPattern; originalRange=range
        underlyingValue=underlying.map { Underlying(wrappedValue: $0) }
        originalUnderlyingValueBits=underlying?.bitPattern
        initialDraft=StudioNumericInput.editableText(value, decimalSeparator: locale.decimalSeparator ?? ".") ?? ""
        draft=initialDraft
    }
    func dismiss() {}
func apply() {
        // A stale keyboard submission must not overwrite an external edit or
        // reinterpret digits after the presentation's locale has changed.
        guard active, isPresented else { return }
        // Read the live source even if a view update has not yet observed it;
        // converting distinct source values can collapse their displayed bits.
        guard value.bitPattern == originalValueBits, locale == originalLocale,
              underlyingValue?.wrappedValue.bitPattern == originalUnderlyingValueBits,
              range == originalRange else { cancel(); return }
        // A rejected paste is not permission to apply the preceding draft.
        // The next bounded edit clears this error, including delete/retype.
        if case .oversizedDraft? = inputError { return }
        // Applying untouched formatted text must not round an imported value.
        if draft == initialDraft {
            cancel(); return
        }
        guard let next = StudioNumericInput.parse(draft, decimalSeparator: locale.decimalSeparator ?? ".",
                                                  in: range) else {
            inputError = .invalidDecimal
            return
        }
        active = false
        // Equivalent decimal spellings preserve the stored bits (and signed
        // zero), and do not create a redundant history entry.
        if next != value { value = next }
        focused = false
        isPresented = false
        dismiss()
    }
func cancel() {
        active = false
        focused = false
        isPresented = false
        dismiss()
    }
}
