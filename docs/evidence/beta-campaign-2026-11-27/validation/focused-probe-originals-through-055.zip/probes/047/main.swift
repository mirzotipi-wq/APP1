
import Foundation
var checks=0
func check(_ okay: @autoclosure () -> Bool, _ message: String) {
    checks += 1
    if !okay() { fatalError(message) }
}
let full = -Double.greatestFiniteMagnitude...Double.greatestFiniteMagnitude
func canonical(_ text: String, _ separator: String) -> String {
    var result=""
    for character in text {
        if String(character)==separator { result += "." }
        else if character=="−" { result += "-" }
        else if let digit=character.wholeNumberValue, (0...9).contains(digit) { result += String(digit) }
        else if character.unicodeScalars.allSatisfy({ CharacterSet.controlCharacters.contains($0) }) { continue }
        else { result += String(character) }
    }
    return result
}
let edges: [Double] = [0.0,-0.0,Double.leastNonzeroMagnitude,-Double.leastNonzeroMagnitude,Double.leastNormalMagnitude,Double.greatestFiniteMagnitude,-Double.greatestFiniteMagnitude,1e-30,1e-29,-1e-29,-1.2345678901234567e-14,1e31,-1e30,1.2345678901234567,100,-100]
var values=edges
var bits: UInt64 = 0x93f2a4c5b678d10e
for _ in 0..<512 {
    bits=bits &* 6364136223846793005 &+ 1442695040888963407
    let value=Double(bitPattern: bits)
    if value.isFinite { values.append(value) }
}
for localeID in ["en_US_POSIX","fr_FR","fa_IR","ar_EG","bn_BD","th_TH"] {
    let locale=Locale(identifier:localeID), separator=locale.decimalSeparator ?? "."
    for value in values {
        let text=StudioNumericInput.formattedValue(value,locale:locale)
        check(Double(canonical(text,separator))?.bitPattern == value.bitPattern,"display lost bits: \(localeID) \(value) \(text)")
        if let draft=StudioNumericInput.editableText(value,decimalSeparator:separator) {
            check(draft.count<=32,"draft length")
            check(StudioNumericInput.parse(draft,decimalSeparator:separator,in:full)?.bitPattern==value.bitPattern,"draft lost bits")
        }
    }
}
for (text, separator) in [("−۱۲,۵",","),("١٢٫٥","٫"),("१२.५","."),("１２.５","."),("𝟙𝟚.𝟝",".")] {
    let expected=text.hasPrefix("−") ? -12.5 : 12.5
    check(StudioNumericInput.parse(text,decimalSeparator:separator,in:-20...20)==expected,"native decimal digits")
}
for text in ["1e-7","-5e-324","1,000","1.2.3","NaN","inf","²","Ⅲ"] {
    check(StudioNumericInput.parse(text,in:full)==nil,"invalid/scientific input admitted")
}
check(StudioNumericInput.isWithinDraftLimit(String(repeating:" ",count:252)+"1.25"),"boundary rejected")
check(!StudioNumericInput.isWithinDraftLimit(String(repeating:" ",count:253)+"1.25"),"oversize admitted")
check(!StudioNumericInput.isWithinDraftLimit("1"+String(repeating:"\u{0301}",count:100_000)),"combining paste admitted")
for value in edges {
    let untouched=ApplyHarness(value,range:full); untouched.apply()
    check(untouched.value.bitPattern==value.bitPattern && untouched.writes==0 && !untouched.isPresented,"untouched apply changed value")
    let cancelled=ApplyHarness(value,range:full); cancelled.draft="42.5"; cancelled.cancel()
    check(cancelled.value.bitPattern==value.bitPattern && cancelled.writes==0 && !cancelled.isPresented,"cancel changed value")
}
for value in [0.0,-0.0,1.25] {
    let h=ApplyHarness(value); h.draft=value==0 ? "+0.0" : "01.250"; h.apply()
    check(h.value.bitPattern==value.bitPattern && h.writes==0,"equivalent spelling changed source bits")
}
let stale=ApplyHarness(1.25); stale.draft="2.5"; stale.value=1.5; let prior=stale.writes; stale.apply()
check(stale.value==1.5 && stale.writes==prior,"stale source overwritten")
let sameDisplay=ApplyHarness(1.25,underlying:0.381); sameDisplay.draft="2.5"; sameDisplay.underlyingValue?.wrappedValue = 0.381.nextUp; sameDisplay.apply()
check(sameDisplay.value==1.25 && sameDisplay.writes==0,"stale underlying overwritten")
let localeChange=ApplyHarness(1.25); localeChange.draft="2,5"; localeChange.locale=Locale(identifier:"fr_FR"); localeChange.apply()
check(localeChange.writes==0 && !localeChange.isPresented,"locale change reinterpreted")
let rangeChange=ApplyHarness(1.25); rangeChange.draft="2.5"; rangeChange.range=0...100; rangeChange.apply()
check(rangeChange.writes==0 && !rangeChange.isPresented,"range change admitted")
let oversize=ApplyHarness(1.25); oversize.draft="2.5"; oversize.inputError = .oversizedDraft; oversize.apply()
check(oversize.writes==0 && oversize.isPresented,"rejected paste applied prior draft")
let changed=ApplyHarness(1.25); changed.draft="2.5"; changed.apply()
check(changed.value==2.5 && changed.writes==1 && !changed.isPresented,"valid edit lost")
var drift=0
for units in [PlanUnits.metric,.imperial] {
    for range in [-100.0...100.0,0.05...4.0] {
        let display=DistanceHarness.convertedRange(range,units:units)!
        for endpoint in [range.lowerBound,range.upperBound] {
            let h=DistanceHarness((range.lowerBound+range.upperBound)/2,range,units)
            h.set(units.fromMeters(endpoint),units:units,displayRange:display)
            check(h.value.bitPattern==endpoint.bitPattern,"endpoint drift")
        }
        for value in [range.lowerBound,range.upperBound,1.2345678901234567] {
            if units.toMeters(units.fromMeters(value)).bitPattern != value.bitPattern { drift += 1 }
            let h=DistanceHarness(value,range,units)
            h.set(units.fromMeters(value),units:units,displayRange:display)
            check(h.value.bitPattern==value.bitPattern,"unchanged unit round trip changed meters")
        }
    }
    for zero in [0.0,-0.0] {
        let h=DistanceHarness(zero,-100...100,units)
        h.set(-zero,units:units,displayRange:DistanceHarness.convertedRange(-100...100,units:units))
        check(h.value.bitPattern==zero.bitPattern,"distance equivalent zero changed bits")
    }
}
let late=DistanceHarness(1,-100...100,.metric); late.unitsRawValue=PlanUnits.imperial.rawValue
late.set(2,units:.metric,displayRange:-100...100)
check(late.value==1,"late unit apply wrote meters")
let feet=DistanceHarness(1,-100...100,.imperial)
feet.set(10,units:.imperial,displayRange:DistanceHarness.convertedRange(-100...100,units:.imperial))
check(feet.value==3.048,"feet conversion wrong")
print("PASS \(checks) assertions; \(values.count) finite values across 6 locales; conversion drift witnesses=\(drift)")
print("Exact source parser + extracted apply/cancel and distance setter logic only; no SwiftUI/UIKit execution.")
