import Foundation

struct Payload: Sendable {
    var rgba: Data
    var mask: Data
}
typealias Cache = StudyFrameCache<Int, Payload>
func cache() -> Cache {
    Cache(maximumCount: 4, maximumPixelBytes: 262_144, maximumMaskBytes: 65_536)
}
func payload(width: Int) -> Payload {
    let pixels = width * (width * 2 / 3)
    return Payload(rgba: Data(repeating: 7, count: pixels * 4), mask: Data(repeating: 0, count: pixels))
}
func put(_ value: Payload, in target: inout Cache, key: Int) {
    precondition(target.insert(value, for: key, pixelBytes: value.rgba.count, maskBytes: value.mask.count))
}
var small = cache()
for key in 0..<5 { put(payload(width: 24), in: &small, key: key) }
precondition(small.count == 4 && small.pixelBytes == 6144 && small.maskBytes == 1536)
precondition(small.value(for: 0) == nil)
var busts = cache()
for key in 0..<4 { put(payload(width: 144), in: &busts, key: key) }
precondition(busts.count == 4 && busts.pixelBytes == 221184 && busts.maskBytes == 55296)
var spheres = cache()
for key in 0..<3 { put(payload(width: 192), in: &spheres, key: key) }
precondition(spheres.count == 2 && spheres.pixelBytes == 196608 && spheres.maskBytes == 49152)
precondition(spheres.value(for: 0) == nil)
var mixed = cache()
for key in 0..<3 { put(payload(width: 144), in: &mixed, key: key) }
put(payload(width: 192), in: &mixed, key: 3)
precondition(mixed.count == 3 && mixed.pixelBytes == 208896 && mixed.maskBytes == 52224)
precondition(mixed.value(for: 0) == nil)

// Mutating a caller's original and a returned copy must not mutate cached bytes.
var original = payload(width: 24)
var cow = cache()
put(original, in: &cow, key: 1)
original.rgba[0] = 99
original.mask[0] = 1
var returned = cow.value(for: 1)!
precondition(returned.rgba[0] == 7 && returned.mask[0] == 0)
returned.rgba[0] = 88
returned.mask[0] = 1
let retained = cow.value(for: 1)!
precondition(retained.rgba[0] == 7 && retained.mask[0] == 0)
var copied = cow
copied.removeAll { _ in true }
precondition(copied.count == 0 && copied.pixelBytes == 0 && copied.maskBytes == 0)
precondition(cow.count == 1 && cow.pixelBytes == 1536 && cow.maskBytes == 384)

var extreme = StudyFrameCache<Int, Int>(maximumCount: 4, maximumPixelBytes: Int.max, maximumMaskBytes: Int.max)
precondition(extreme.insert(1, for: 1, pixelBytes: Int.max - 1, maskBytes: Int.max - 1))
precondition(extreme.insert(2, for: 2, pixelBytes: 1, maskBytes: 1))
precondition(extreme.insert(3, for: 3, pixelBytes: 1, maskBytes: 1))
precondition(extreme.count == 2 && extreme.pixelBytes == 2 && extreme.maskBytes == 2)
precondition(!extreme.insert(4, for: 2, pixelBytes: -1, maskBytes: 0))
precondition(extreme.value(for: 2) == 2)
print("PASS: actual StudyFrameCache source; 4-frame, independent payload budgets, LRU eviction, overflow-safe costs, payload and cache copy-on-write")
print("resources small=4/6144/1536 bust=4/221184/55296 sphere=2/196608/49152 mixed=3/208896/52224")
