"""Independent bounded enumeration of the fc69ed1 panel interval accounting.

This checks the declared engineering bands, not GPU roundoff or parity.
"""
import hashlib
import json
import math
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
SHA = "fc69ed19499e1b99f2f51ee0ac12cf43842fb5ab"
SOURCE = subprocess.check_output(["git", "show", f"{SHA}:Sources/LightingCore/StudyFloat32Eligibility.swift"], cwd=ROOT / "APP1")
A = 32 * 2.0 ** -23


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def unit(a):
    n = math.sqrt(dot(a, a))
    return tuple(x / n for x in a)


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def basis(origin):
    f = unit(tuple(-x for x in origin))
    r0 = unit((f[2], 0.0, -f[0])) if math.hypot(f[0], f[2]) > 1e-12 else (1.0, 0.0, 0.0)
    return f, tuple(-x for x in r0), unit(cross(f, r0))


def check_case(origin, focal, width):
    f, r, u = basis(origin)
    hw, hh = 18 / focal, 12 / focal
    rb = tuple(abs(f[i]) + abs(r[i]) * hw + abs(u[i]) * hh for i in range(3))
    re = tuple(x * A for x in rb)
    h = origin[1] + .22
    assert h > .01 - 1e-14
    he = (abs(origin[1]) + .22) * A
    constraints = [(-f[1], -r[1], -u[1], re[1])]
    for axis in (0, 2):
        for sign in (-1, 1):
            offset = 3 - sign * origin[axis]
            oe = (3 + abs(origin[axis])) * A
            n = [0.0, -offset, 0.0]
            n[axis] = -sign * h
            margin = abs(offset)*re[1] + rb[1]*oe + re[1]*oe + h*re[axis] + rb[axis]*he + re[axis]*he
            constraints.append((dot(n, f), dot(n, r), dot(n, u), margin))

    def interval_count(py, inner):
        low, high = -hw, hw
        for c, x, y, margin in constraints:
            minimum = margin if inner else -margin
            constant = c + y * py
            if x == 0:
                if constant < minimum:
                    return 0
            else:
                crossing = (minimum - constant) / x
                if x > 0:
                    low = max(low, crossing)
                else:
                    high = min(high, crossing)
                if low > high:
                    return 0
        pad = 32 * sys.float_info.epsilon * width
        first = max(0, math.ceil(width * (low / hw + 1) / 2 - .5 + (pad if inner else -pad)))
        last = min(width-1, math.floor(width * (high / hw + 1) / 2 - .5 + (-pad if inner else pad)))
        return max(0, last - first + 1)

    shell = pixels = 0
    for y in range(width * 2 // 3):
        py = (1 - 2 * (y + .5) / (width * 2 // 3)) * hh
        brute_outer = brute_inner = 0
        for x in range(width):
            px = (2 * (x + .5) / width - 1) * hw
            q = tuple(f[i] + r[i]*px + u[i]*py for i in range(3))
            values = [-q[1]]
            for axis in (0, 2):
                for sign in (-1, 1):
                    values.append((-q[1]) * (3 - sign * origin[axis]) - sign*h*q[axis])
            outer = all(v >= -c[3] for v, c in zip(values, constraints))
            inner = all(v >= c[3] for v, c in zip(values, constraints))
            brute_outer += outer
            brute_inner += inner
            direct_hit = False
            if q[1] < 0:
                p = tuple(origin[i] + h * q[i] / -q[1] for i in range(3))
                direct_hit = abs(p[0]) <= 3 and abs(p[2]) <= 3
            # Exact homogeneous geometry must agree outside the declared shell.
            assert not inner or direct_hit, (origin, focal, width, x, y, "inner outside panel")
            assert outer or not direct_hit, (origin, focal, width, x, y, "panel outside outer")
            pixels += 1
        counted_outer = interval_count(py, False)
        counted_inner = interval_count(py, True)
        assert counted_outer >= brute_outer, (origin, width, y, "outer undercount", counted_outer, brute_outer)
        assert counted_inner <= brute_inner, (origin, width, y, "inner overcount", counted_inner, brute_inner)
        assert counted_inner <= counted_outer
        shell += counted_outer - counted_inner
    return shell, pixels


rng = random.Random(530053)
cases = []
for path in sorted((ROOT / "campaign/probes/044/fixtures").glob("*.scene.json")):
    scene = json.loads(path.read_text())
    origin = tuple(scene["camera"][a] - scene["subject"][a] for a in ("x", "y", "z"))
    width = int(path.name.split("-")[2])
    cases.append((origin, scene["cameraLens"]["focalLengthMillimeters"], width, "original044"))
for width in (24, 27, 51, 96, 189, 192):
    for distance in (1.0, 2.0, 3.0):
        cases.append(((0.0, distance, 0.0), 14.0, width, "separated-overhead"))
    for epsilon in (-1e-7, -1e-8, 0, 1e-8, 1e-7):
        distance = 3 / ((1 - 1 / width) * 18 / 14) - .22 + epsilon
        cases.append(((0.0, distance, 0.0), 14.0, width, "overhead-edge"))
    cases.append(((1.2, 1.5, 2.3), 14.0, width, "wide-rotated"))
    for yaw in (0.0, .7, math.pi/2, -2.1):
        cases.append(((math.sin(yaw)*19.9, -.209999999, math.cos(yaw)*19.9), 14.0, width, "near-panel-height"))
for _ in range(70):
    d = rng.uniform(.270001, 20)
    sy = rng.uniform(max(-.2099999 / d, -.8), 1)
    yaw = rng.uniform(-math.pi, math.pi)
    horizontal = math.sqrt(1 - sy*sy)
    origin = (d*horizontal*math.sin(yaw), d*sy, d*horizontal*math.cos(yaw))
    cases.append((origin, rng.uniform(14, 200), rng.choice((24, 27, 51, 96, 189, 192)), "random"))

results = []
pixels = 0
for origin, focal, width, category in cases:
    shell, count = check_case(origin, focal, width)
    pixels += count
    results.append({"category": category, "origin": origin, "focal": focal, "width": width, "panel_shell": shell})
assert all(r["panel_shell"] > r["width"]*(r["width"]*2//3)//510 for r in results if r["category"] in ("original044", "overhead-edge"))
assert all(r["panel_shell"] <= r["width"]*(r["width"]*2//3)//510 for r in results if r["category"] in ("separated-overhead", "wide-rotated"))
summary = {
    "input_revision": SHA,
    "eligibility_sha256": hashlib.sha256(SOURCE).hexdigest(),
    "method": "Python Double enumeration of direct ray/plane geometry versus row intervals under the declared bands; no Swift or GPU execution",
    "seed": 530053,
    "cases": len(results),
    "pixels_checked": pixels,
    "interval_undercounts": 0,
    "geometry_outside_declared_band_mismatches": 0,
    "results": results,
}
Path(__file__).with_name("math-result.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2))
