import Foundation

let folder = URL(fileURLWithPath: "/workspace/scratch/4633a14a0d5b/campaign/probes/044/fixtures")
for width in [24, 48, 192] {
    let focal = 14.0
    let slope = (1 - 1 / Double(width)) * 18 / focal
    let exactDistance = 3 / slope - 0.22
    for epsilon in [-1e-7, -1e-8, 0.0, 1e-8, 1e-7] {
        let name = "panel-width-\(width)-epsilon-\(epsilon)"
        let scene = LightingScene(subject: .init(x: 0, y: 0, z: 0),
            camera: .init(x: 0, y: exactDistance + epsilon, z: 0), lights: [],
            cameraLens: .init(focalLengthMillimeters: focal))
        let input = try StudyComputeInput(scene: scene, width: width)
        let image = try ReferenceStudyRenderer.render(scene: scene, width: width)
        var data = Data()
        func append(_ value: UInt32) {
            var little = value.littleEndian
            withUnsafeBytes(of: &little) { data.append(contentsOf: $0) }
        }
        for value in [input.width, input.height, input.parameters.count, input.samples.count,
                      input.areas.count, image.unsupportedPixels] { append(UInt32(value)) }
        for row in input.parameters + input.samples + input.areas {
            for value in [row.x, row.y, row.z, row.w] { append(value.bitPattern) }
        }
        var reference = [UInt8](image.rgba)
        for (pixel, flag) in image.unsupportedPixelMask.enumerated() {
            reference[4 * pixel + 3] = flag == 1 ? 0 : 255
        }
        data.append(contentsOf: reference)
        try data.write(to: folder.appendingPathComponent(name + ".bin"))
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(scene).write(to: folder.appendingPathComponent(name + ".scene.json"))
        print("\(name): cameraY=\(scene.camera.y) eligible=\(StudyFloat32Eligibility.supports(scene, width: width)) unsupported=\(image.unsupportedPixels)")
    }
}
