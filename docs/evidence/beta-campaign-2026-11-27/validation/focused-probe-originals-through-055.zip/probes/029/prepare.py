from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/workspace/scratch/4633a14a0d5b')
repo = root / 'APP1'
out = root / 'campaign/probes/029'
revision = 'f1d75d56f62f0687d4eb3a9188c45e82eb83e347'
names = [
    'Scene', 'SceneCodec', 'LightingProjectDocument', 'ProjectLibrary',
    'SceneFileStore', 'StudioOptics', 'CameraFraming', 'RoomPlacement',
    'StudioNumericInput', 'Colorimetry', 'SurfacePhotometry'
]
files = []
for name in names:
    path = f'Sources/LightingCore/{name}.swift'
    data = subprocess.check_output(['git', 'show', f'{revision}:{path}'], cwd=repo)
    (out / 'sources' / f'{name}.swift').write_bytes(data)
    files.append({'path': path, 'sha256': hashlib.sha256(data).hexdigest()})
(out / 'source-manifest.json').write_text(json.dumps({'revision': revision, 'files': files}, indent=2) + '\n')
print(f'Snapshotted {len(files)} complete production Swift files at {revision}')
