from pathlib import Path
import json
import subprocess
import time

out = Path(__file__).resolve().parent
compiler = '/workspace/scratch/4633a14a0d5b/toolchain/swift-6.4.3-RELEASE-debian13/usr/bin/swiftc'
commands = []
def run(name, command):
    start = time.monotonic()
    result = subprocess.run(command, cwd=out, capture_output=True, text=True)
    elapsed = time.monotonic() - start
    (out / f'{name}.log').write_text(result.stdout + result.stderr)
    commands.append({'name': name, 'command': command, 'exit': result.returncode, 'elapsed_seconds': elapsed})
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(f'{name}: exit={result.returncode}, seconds={elapsed:.3f}', flush=True)
    if result.returncode:
        print(result.stdout + result.stderr)
        raise SystemExit(result.returncode)

run('toolchain', [compiler, '--version'])
run('compile-bounded', ['timeout', '45s', compiler, '-swift-version', '5', '-module-cache-path', 'module-cache',
                        *[str(path.relative_to(out)) for path in sorted((out / 'sources').glob('*.swift'))],
                        'main.swift', '-o', 'scene_probe'])
run('probe', ['timeout', '20s', './scene_probe'])
print((out / 'probe.log').read_text())
