import Foundation

let light = #"{"id":"00000000-0000-4000-8000-000000000001","name":"Key","position":{"x":-1.5,"y":2.1,"z":1.2},"candela":900,"kelvin":5600,"optics":{"kind":"rectangle","widthMeters":0.6,"heightMeters":0.9}}"#
func scene(version: String = "5", x: String = "0", lights: String = "[]", extras: String = "") -> String {
    #"{"schemaVersion":"# + version + #", "subject":{"x":0,"y":1.5,"z":0},"camera":{"x":"# + x + #", "y":1.5,"z":3},"lights":"# + lights + extras + "}"
}
func document(_ scene: String, extras: String = "") -> Data {
    Data((#"{"schemaVersion":1,"name":"Probe","scene":"# + scene + extras + "}").utf8)
}
var passed = 0
var failed = 0
func check(_ name: String, accepted: Bool, _ operation: () throws -> Void) {
    do {
        try operation()
        if accepted { passed += 1; print("PASS \(name): accepted") }
        else { failed += 1; print("FAIL \(name): unexpectedly accepted") }
    } catch {
        if accepted { failed += 1; print("FAIL \(name): unexpectedly rejected \(error)") }
        else { passed += 1; print("PASS \(name): rejected \(String(describing: type(of: error)))") }
    }
}
func decodeCheck(_ name: String, _ input: String, accepted: Bool) {
    check(name, accepted: accepted) { _ = try LightingProjectDocument.decode(document(input)) }
}

for version in 1...5 {
    check("migration-v\(version)", accepted: true) {
        let result = try LightingProjectDocument.decode(document(scene(version: String(version))))
        precondition(result.scene.schemaVersion == 5)
        precondition(result.scene.camera == Position(x: 0, y: 1.5, z: 3))
    }
}
for token in ["0", "6", "-1", "9223372036854775808", "1.25", "1e999"] {
    decodeCheck("scene-version-\(token)", scene(version: token), accepted: false)
}
for token in ["1e309", "-1e309", "NaN", "Infinity", "\"NaN\"", "\"Infinity\"", "1e308", "-1e308", "100.0001"] {
    decodeCheck("coordinate-\(token)", scene(x: token), accepted: false)
}
for token in ["-100", "100", "5e-324", "-5e-324"] {
    decodeCheck("finite-coordinate-\(token)", scene(x: token), accepted: true)
}
for token in ["\"disk\"", "\"Rectangle\"", "null", "1", "false"] {
    let replaced = light.replacingOccurrences(of: #""kind":"rectangle""#, with: #""kind":"# + token)
    decodeCheck("emitter-kind-\(token)", scene(lights: "[" + replaced + "]"), accepted: false)
}
decodeCheck("valid-rectangle", scene(lights: "[" + light + "]"), accepted: true)
decodeCheck("v1-with-optics", scene(version: "1", lights: "[" + light + "]"), accepted: false)
decodeCheck("v2-with-lens", scene(version: "2", extras: #", "cameraLens":{"focalLengthMillimeters":50}"#), accepted: false)
decodeCheck("v3-with-preview", scene(version: "3", extras: #", "previewSettings":{"whiteBalanceKelvin":5600,"exposureStops":0}"#), accepted: false)
decodeCheck("v4-with-room", scene(version: "4", extras: #", "placementRoom":{"widthMeters":6,"depthMeters":7,"subjectX":3,"subjectZ":2,"yawDegrees":0}"#), accepted: false)
decodeCheck("v4-with-roll", scene(version: "4", lights: "[" + light.replacingOccurrences(of: #""heightMeters":0.9"#, with: #""heightMeters":0.9,"rollDegrees":0"#) + "]"), accepted: false)

let uniqueLights = (0..<13).map { index in light.replacingOccurrences(of: "000000000001", with: String(format: "%012d", index + 1)) }
decodeCheck("twelve-lights", scene(lights: "[" + uniqueLights.prefix(12).joined(separator: ",") + "]"), accepted: true)
decodeCheck("thirteen-lights", scene(lights: "[" + uniqueLights.joined(separator: ",") + "]"), accepted: false)
decodeCheck("ten-thousand-lights", scene(lights: "[" + Array(repeating: light, count: 10_000).joined(separator: ",") + "]"), accepted: false)

decodeCheck("unknown-scene-field", scene(extras: #", "metadata":{"a":1}"#), accepted: true)
check("unknown-envelope-field", accepted: false) {
    _ = try LightingProjectDocument.decode(document(scene(), extras: #", "unexpected":true"#))
}
for depth in [64, 4096] {
    let nested = String(repeating: "[", count: depth) + "0" + String(repeating: "]", count: depth)
    decodeCheck("unknown-depth-\(depth)", scene(extras: #", "metadata":"# + nested), accepted: depth == 64)
}
let wide = (0..<50_000).map { #""key"# + String($0) + #"":0"# }.joined(separator: ",")
decodeCheck("unknown-fifty-thousand-keys", scene(extras: #", "metadata":{"# + wide + "}"), accepted: true)
decodeCheck("unknown-duplicate-key", scene(extras: #", "metadata":{"key":1,"\u006bey":2}"#), accepted: false)
check("over-byte-limit", accepted: false) {
    _ = try LightingProjectDocument.decode(Data(repeating: 32, count: LightingProjectDocument.maximumBytes + 1))
}
check("sixty-five-library-projects", accepted: false) {
    let projects = (1...65).map { index in
        #"{"id":"00000000-0000-4000-8000-"# + String(format: "%012d", index) + #"","name":"Probe","scene":"# + scene() + #", "isArchived":false}"#
    }.joined(separator: ",")
    let bytes = Data((#"{"schemaVersion":1,"activeID":"00000000-0000-4000-8000-000000000001","projects":["# + projects + "]}").utf8)
    _ = try JSONDecoder().decode(ProjectLibrary.self, from: bytes).validated()
}
print("SUMMARY passed=\(passed) failed=\(failed)")
if failed != 0 { exit(1) }
