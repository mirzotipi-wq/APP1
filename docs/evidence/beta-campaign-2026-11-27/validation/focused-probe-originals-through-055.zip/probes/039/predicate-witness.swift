// Standalone Linux predicate witness; this is not Apple native execution.
// Predicate body extracted verbatim (except indentation) from the changed source.
// Source SHA256: f3860ea28bdd6d89952b18f2f6d4a1feb7fdbc9591047d2df0beed7cbad6432e
func predicate(_ bytes: [UInt8]) -> Bool {
    let allPixelsAreUniformAndOpaque: Bool = stride(from: 0, to: bytes.count, by: 4).allSatisfy {
        (offset: Int) -> Bool in
        let red: UInt8 = bytes[offset]
        let green: UInt8 = bytes[offset + 1]
        let blue: UInt8 = bytes[offset + 2]
        let alpha: UInt8 = bytes[offset + 3]
        let redMatches: Bool = red == bytes[0]
        let greenMatches: Bool = green == bytes[1]
        let blueMatches: Bool = blue == bytes[2]
        let isOpaque: Bool = alpha == UInt8(255)
        return redMatches && greenMatches && blueMatches && isOpaque
    }
    return allPixelsAreUniformAndOpaque
}

var checks = 0
func expect(_ actual: Bool, _ expected: Bool, _ label: String) {
    precondition(actual == expected, label)
    checks += 1
}

let pixel: [UInt8] = [128, 128, 128, 255]
let pixelCount = 128 * 128
let uniform: [UInt8] = Array(repeating: pixel, count: pixelCount).flatMap { $0 }
expect(predicate(uniform), true, "Every authored gray pixel is identical and opaque")
expect(predicate(pixel), true, "One identical opaque pixel")
let rounded: [UInt8] = Array(repeating: [UInt8(127), 128, 129, 255], count: pixelCount).flatMap { $0 }
expect(predicate(rounded), true, "Per-channel equality preserves the existing color-rounding allowance")
expect(predicate([]), true, "The existing empty-stride semantics remain unchanged")

for pixelIndex in [0, pixelCount / 2, pixelCount - 1] {
    for channel in 0..<4 {
        var changed = uniform
        changed[pixelIndex * 4 + channel] = channel == 3 ? 254 : 129
        expect(predicate(changed), false, "A changed byte at pixel \(pixelIndex), channel \(channel) must fail")
    }
}
print("PASS: \(checks) fixed expected-result checks (4 positive, 12 negative); 16,384-pixel fixture; all four channels at first/middle/last pixels.")
