import Foundation

let tinyWidth = Double(1).nextUp
let room = ManualRoom(widthMeters: 4, depthMeters: 4, subjectX: 0, subjectZ: 2)
func fixture(shift: Double, width: Double) -> LightingScene {
    LightingScene(subject: .init(x: shift, y: 1.5, z: 0),
                  camera: .init(x: shift, y: 1.5, z: 1), lights: [
        .init(name: "Edge", position: .init(x: shift + 0.5, y: 1.5, z: 0),
              candela: 900, kelvin: 5600,
              optics: .init(kind: .rectangle, aimTarget: .init(x: shift + 0.5, y: 1.5, z: 1),
                            widthMeters: width, heightMeters: 1))
    ], placementRoom: room)
}
print("Expected analytic left overhang: \(0.5 - tinyWidth / 2)")
for width in [1.0, tinyWidth, 1.000000000001] {
    for shift in [0.0, 50.0, 99.0] {
        let scene = try fixture(shift: shift, width: width).validated()
        let plan = try RoomPlacementPlan(scene: scene, room: room)
        let face = plan.modifierFootprints[0]
        print("width=\(width) shift=\(shift) centerX=\(plan.points[2].xFromLeft) minX=\(face.corners.map(\.xFromLeft).min()!) clearance=\(face.minimumWallClearanceMeters!) crossed=\(face.crossedWalls.map(\.rawValue)) inside=\(String(describing: face.isInsideRoom))")
        if width == tinyWidth {
            let notes = plan.textSummary(locale: Locale(identifier: "en_US_POSIX"))
            print("  notes-clear=\(notes.contains("Emitting-face projection within room outline.")) notes-crossing=\(notes.contains("Emitting-face projection crosses left wall boundaries."))")
            let export = try LightingPlan(scene: scene, title: "Probe")
            print("  export-clear=\(export.roomPlacementText!.contains("Emitting-face projection within room outline."))")
        }
    }
}
