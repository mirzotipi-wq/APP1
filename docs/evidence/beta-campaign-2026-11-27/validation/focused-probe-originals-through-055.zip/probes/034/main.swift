import Foundation

var assertions = 0
func require(_ value: Bool, _ label: String) {
    assertions += 1
    precondition(value, label)
}
func direction(_ x: Double, _ y: Double, _ z: Double) -> UnitDirection {
    UnitDirection(x: x, y: y, z: z)!
}
let origin = Position(x: 0, y: 0, z: 0)
func rectangle(_ w: Double, _ h: Double, _ cd: Double = 1000) -> LambertianRectangle {
    LambertianRectangle(center: origin, right: direction(1, 0, 0), up: direction(0, 1, 0),
                        widthMeters: w, heightMeters: h, onAxisCandela: cd)!
}
func parallelReference(_ w: Double, _ h: Double, _ d: Double) -> Double {
    let a = w / 2, b = h / 2
    let da = sqrt(d * d + a * a), db = sqrt(d * d + b * b)
    return 2000 / (w * h) * (a / da * atan(b / da) + b / db * atan(a / db))
}
// Independent composite Simpson integration on the exactly clipped vertical
// slices x + slope*y > cut. No polygon clipping or Gaussian rule is reused.
func grazingReference(_ cut: Double, _ slope: Double) -> Double {
    let d = 0.25, w = 1.0, h = 0.6, n = 320
    let normalLength = sqrt(1 + slope * slope + (cut / d) * (cut / d))
    let x0 = max(-w / 2, cut - slope * h / 2), x1 = w / 2
    let dx = (x1 - x0) / Double(n)
    func weight(_ i: Int) -> Double { i == 0 || i == n ? 1 : (i % 2 == 0 ? 2 : 4) }
    var sum = 0.0
    for i in 0...n {
        let x = x0 + Double(i) * dx
        let y0 = slope == 0 ? -h / 2 : max(-h / 2, (cut - x) / slope)
        let y1 = h / 2
        if y0 >= y1 { continue }
        let dy = (y1 - y0) / Double(n)
        var slice = 0.0
        for j in 0...n {
            let y = y0 + Double(j) * dy
            let r2 = x * x + y * y + d * d
            let projection = max(0, (x + slope * y - cut) / normalLength)
            slice += weight(j) * d * projection / (r2 * r2)
        }
        sum += weight(i) * slice * dy / 3
    }
    return sum * dx / 3 * 1000 / (w * h)
}
func expectError(_ expected: LightOutputAdjustmentError, _ body: () throws -> StudioLight) {
    do { _ = try body(); require(false, "Missing error \(expected)") }
    catch { require(error as? LightOutputAdjustmentError == expected, "Wrong error \(error)") }
}

var pointMaximumAbsoluteError = 0.0
for degrees in [0.0, 30, 60, 90, 120, 180] {
    let angle = degrees * .pi / 180
    let actual = Photometry.pointIlluminance(candela: 400, source: .init(x: 0, y: 0, z: 2),
        receiver: origin, receiverNormal: direction(sin(angle), 0, cos(angle)))!
    let error = abs(actual - 100 * max(0, cos(angle)))
    pointMaximumAbsoluteError = max(pointMaximumAbsoluteError, error)
    require(error < 1e-9, "Point cosine")
}
let atOne = Photometry.pointIlluminance(candela: 400, source: .init(x: 0, y: 0, z: 1),
    receiver: origin, receiverNormal: direction(0, 0, 1))!
require(atOne == 400, "Point inverse-square")
require(Photometry.pointIlluminance(candela: 400, source: origin, receiver: origin,
    receiverNormal: direction(0, 0, 1)) == nil, "Point coincidence")

var parallel: [[String: Double]] = []
for (w, h, d) in [(1.0, 1.0, 0.25), (1, 0.6, 0.5), (1, 0.6, 1), (0.3, 1.5, 0.4),
                   (2, 0.5, 1), (0.05, 0.05, 2), (4, 0.05, 1), (0.05, 4, 1), (4, 4, 1)] {
    let actual = Photometry.rectangularIlluminance(emitter: rectangle(w, h),
        receiver: .init(x: 0, y: 0, z: d), receiverNormal: direction(0, 0, -1))!
    let expected = parallelReference(w, h, d)
    let error = abs(actual / expected - 1)
    require(error < 0.01, "Parallel analytic")
    parallel.append(["width": w, "height": h, "depth": d, "lux": actual, "relativeError": error])
}
var grazing: [[String: Double]] = []
for slope in [0.0, 1.0] {
    for cut in slope == 0 ? [0.45, 0.48, 0.499, 0.49999] : [0.6, 0.79, 0.799, 0.79999] {
        let actual = Photometry.rectangularIlluminance(emitter: rectangle(1, 0.6),
            receiver: .init(x: 0, y: 0, z: 0.25), receiverNormal: direction(1, slope, cut / 0.25))!
        let expected = grazingReference(cut, slope)
        let error = abs(actual / expected - 1)
        require(actual > 0 && error < 0.002, "Grazing independent Simpson")
        grazing.append(["slope": slope, "cut": cut, "lux": actual, "reference": expected, "relativeError": error])
    }
}
for size in [0.05, 0.6, 4.0] {
    let depth = max(0.05, size / 4)
    let e = rectangle(size, size)
    require(Photometry.rectangularIlluminance(emitter: e,
        receiver: .init(x: 0, y: 0, z: depth), receiverNormal: direction(0, 0, -1)) != nil, "Exact supported depth")
    require(Photometry.rectangularIlluminance(emitter: e,
        receiver: .init(x: 0, y: 0, z: depth.nextDown), receiverNormal: direction(0, 0, -1)) == nil, "Below supported depth")
    require(Photometry.rectangularIlluminance(emitter: e,
        receiver: .init(x: 0, y: 0, z: -depth), receiverNormal: direction(0, 0, 1)) == 0, "Emitter backface")
}

var adjustment: [[String: Any]] = []
for kind in EmitterKind.allCases {
    let source = StudioLight(name: "Guard fixture", position: .init(x: 0, y: 0, z: 3),
        candela: 0, kelvin: 5600, optics: .init(kind: kind, widthMeters: 0.1, heightMeters: 0.1))
    let scene = LightingScene(subject: origin, camera: .init(x: 0, y: 0, z: 4), lights: [source])
    var maximum = source; maximum.candela = 100_000
    let maximumLux = StudioPhotometry.illuminance(for: maximum, in: scene)!
    for target in [0, 12.5, maximumLux.nextDown, maximumLux] {
        let adjusted = try LightOutputAdjustment.light(source, targetingLux: target, in: scene)
        let achieved = StudioPhotometry.illuminance(for: adjusted, in: scene)!
        var expected = source; expected.candela = adjusted.candela
        require(adjusted == expected, "Only candela changes")
        require(target == 0 ? achieved == 0 : abs(achieved / target - 1) <= 1e-9, "Forward achieved target")
        adjustment.append(["kind": kind.rawValue, "target": target, "achieved": achieved, "candela": adjusted.candela])
    }
    expectError(.outputOutOfRange) { try LightOutputAdjustment.light(source, targetingLux: maximumLux.nextUp, in: scene) }
    for invalid in [-1.0, Double.nan, Double.infinity] {
        expectError(.invalidTargetLux) { try LightOutputAdjustment.light(source, targetingLux: invalid, in: scene) }
    }
    var near = source; near.position = origin
    require(try LightOutputAdjustment.light(near, targetingLux: 0, in: scene).candela == 0, "Zero permits unsupported geometry")
    expectError(.unsupportedGeometry) { try LightOutputAdjustment.light(near, targetingLux: 1, in: scene) }
    var invalid = source; invalid.name = " "
    expectError(.invalidLight) { try LightOutputAdjustment.light(invalid, targetingLux: 0, in: scene) }
    var coincidentCamera = scene; coincidentCamera.camera = origin
    expectError(.unsupportedGeometry) { try LightOutputAdjustment.light(source, targetingLux: 1, in: coincidentCamera) }
    var invalidScene = scene; invalidScene.lights.append(source)
    expectError(.unsupportedGeometry) { try LightOutputAdjustment.light(source, targetingLux: 0, in: invalidScene) }
}
let tinySource = StudioLight(name: "Tiny", position: .init(x: 0, y: 0, z: 3), candela: 400,
    kelvin: 5600, optics: .init(kind: .rectangle, widthMeters: 0.1, heightMeters: 0.1))
let tinyScene = LightingScene(subject: origin, camera: .init(x: 0, y: 0, z: 4), lights: [tinySource])
let tinyAdjusted = try LightOutputAdjustment.light(tinySource, targetingLux: .leastNonzeroMagnitude, in: tinyScene)
require(StudioPhotometry.illuminance(for: tinyAdjusted, in: tinyScene) == Double.leastNonzeroMagnitude,
    "Representable subnormal rectangle target")
var exactTiny = tinySource; exactTiny.candela = 499 * 1e-320
let exactTarget = StudioPhotometry.illuminance(for: exactTiny, in: tinyScene)!
require(try LightOutputAdjustment.light(exactTiny, targetingLux: exactTarget, in: tinyScene) == exactTiny,
    "Exact existing tiny source retained")
let output: [String: Any] = ["assertions": assertions, "pointMaximumAbsoluteError": pointMaximumAbsoluteError,
    "parallel": parallel, "grazing": grazing, "adjustment": adjustment,
    "tinyCandela": tinyAdjusted.candela, "tinyLux": Double.leastNonzeroMagnitude]
let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
print(String(decoding: data, as: UTF8.self))
