import Foundation

var comparisons = 0
func check(_ ok: Bool, _ message: String) {
    comparisons += 1
    if !ok { fatalError(message) }
}
func near(_ actual: Position, _ expected: Position, _ message: String) {
    check(actual.distance(to: expected) < 2e-11, message)
}
func corners(_ light: StudioLight, _ subject: Position) -> [Position] {
    let f = StudioPhotometry.frame(for: light, subject: subject)!
    let w = light.effectiveOptics.widthMeters / 2
    let h = light.effectiveOptics.heightMeters / 2
    return [(-1.0,-1.0), (1.0,-1.0), (1.0,1.0), (-1.0,1.0)].map { a,b in
        Position(x: light.position.x + a*w*f.right.x + b*h*f.up.x,
                 y: light.position.y + a*w*f.right.y + b*h*f.up.y,
                 z: light.position.z + a*w*f.right.z + b*h*f.up.z)
    }
}
func sameCornerSet(_ a: [Position], _ b: [Position], _ label: String) {
    for p in a { check(b.contains { $0.distance(to:p) < 2e-11 }, label) }
}
let subject = Position(x: 2, y: 1.5, z: -3)
let destination = Position(x: 10, y: 2.5, z: 5)
let lightPosition = Position(x: 3, y: 3, z: -2)
let axes: [(Double,Double,Double)] = [(0,-1,0),(0,1,0),(1,0,0),(0,0,1),(0.3,-1,0.7)]
var scenes = 0
for (ax,ay,az) in axes {
    for roll in [-180.0,-90,0,37,90,180] {
        for degrees in [-270.0,-90,0,36.86989764584402,90,180,720] {
            for (cx,cz) in [(0.0,3.0),(3.0,4.0)] {
                let light = StudioLight(name: "Probe", position: lightPosition, candela: 900, kelvin: 5600,
                    optics: .init(kind:.rectangle, aimTarget:.init(x:lightPosition.x+ax*2,y:lightPosition.y+ay*2,z:lightPosition.z+az*2),
                                  widthMeters:1.2,heightMeters:0.7,rollDegrees:roll))
                let scene = LightingScene(subject:subject,camera:.init(x:subject.x+cx,y:2.5,z:subject.z+cz),lights:[light])
                let sourceCorners = corners(light,subject)
                let frame = StudioPhotometry.frame(for:light,subject:subject)!
                near(.init(x:frame.right.y*frame.up.z-frame.right.z*frame.up.y,
                           y:frame.right.z*frame.up.x-frame.right.x*frame.up.z,
                           z:frame.right.x*frame.up.y-frame.right.y*frame.up.x),
                     .init(x:frame.normal.x,y:frame.normal.y,z:frame.normal.z),"Emitter handedness")
                let radians = degrees * .pi / 180, c = cos(radians), s = sin(radians)
                for mirror in [false,true] {
                    let moved = try SceneTransform.arranged(scene,subjectAt:destination,rotatingLightsByDegrees:degrees,mirroringLights:mirror)
                    let denominator = cx*cx+cz*cz
                    let dx = (cx*cx-cz*cz)/denominator, cross = 2*cx*cz/denominator
                    func independent(_ p:Position)->Position {
                        let px = p.x-subject.x,pz = p.z-subject.z
                        let rx = c*px+s*pz, rz = -s*px+c*pz
                        return .init(x:destination.x+(mirror ? dx*rx+cross*rz : rx),y:destination.y+p.y-subject.y,
                                     z:destination.z+(mirror ? cross*rx-dx*rz : rz))
                    }
                    near(moved.lights[0].position,independent(light.position),"Arranged center")
                    near(moved.lights[0].optics!.aimTarget!,independent(light.optics!.aimTarget!),"Arranged aim")
                    near(moved.camera,.init(x:destination.x+cx,y:3.5,z:destination.z+cz),"Camera translation")
                    sameCornerSet(corners(moved.lights[0],moved.subject),sourceCorners.map(independent),"Arranged corners")
                    check(moved.lights[0].id == light.id,"Stable light UUID")
                    check(moved.lights[0].candela == light.candela && moved.lights[0].kelvin == light.kelvin,"Stable photometry")
                }
                let rotated = try SceneTransform.rotatingLights(scene,byDegrees:degrees)
                let unrotated = try SceneTransform.rotatingLights(rotated,byDegrees:-degrees)
                sameCornerSet(corners(unrotated.lights[0],unrotated.subject),sourceCorners,"Yaw inverse")
                let reflected = try SceneTransform.mirroringLights(scene)
                let unreflected = try SceneTransform.mirroringLights(reflected)
                sameCornerSet(corners(unreflected.lights[0],unreflected.subject),sourceCorners,"Reflection involution")
                let offset = Position(x:8,y:1,z:8)
                let translated = try SceneTransform.translated(scene,by:offset)
                let untranslated = try SceneTransform.translated(translated,by:.init(x:-8,y:-1,z:-8))
                sameCornerSet(corners(untranslated.lights[0],untranslated.subject),sourceCorners,"Translation inverse")
                let cf = CameraFraming(scene:scene)!, tf = CameraFraming(scene:translated)!
                let cp = cf.project(scene.subject)!, tp = tf.project(translated.subject)!
                check(abs(cp.x-tp.x)<2e-11 && abs(cp.y-tp.y)<2e-11 && abs(cp.depthMeters-tp.depthMeters)<2e-11,"Camera projection translation")
                near(.init(x:cf.right.y*cf.up.z-cf.right.z*cf.up.y,
                           y:cf.right.z*cf.up.x-cf.right.x*cf.up.z,
                           z:cf.right.x*cf.up.y-cf.right.y*cf.up.x),
                     .init(x:-cf.forward.x,y:-cf.forward.y,z:-cf.forward.z),"Camera -Z basis")
                let origin = Position(x:5,y:0.25,z:-7)
                let ar = try ARPlacementLayout(scene:scene,origin:origin,yawDegrees:degrees)
                for p in [scene.subject,scene.camera,light.position,light.optics!.aimTarget!] + sourceCorners {
                    let world = ar.transform(position:p)!
                    let wx = world.x-origin.x,wz = world.z-origin.z
                    near(.init(x:subject.x+c*wx-s*wz,y:world.y-origin.y,z:subject.z+s*wx+c*wz),p,"AR inverse and floor offset")
                }
                check(abs(ar.items[2].position.distance(to:ar.items[0].position)-light.position.distance(to:scene.subject))<2e-11,"AR unit scale")
                scenes += 1
            }
        }
    }
}
print("PASS bounded math/source probe: \(scenes) scenes, \(comparisons) comparisons")
let boundarySubject = Position(x:-99.8,y:1.5,z:0)
let boundaryScene = LightingScene(subject:boundarySubject,camera:.init(x:-98,y:1.5,z:3),lights:[
    .init(name:"Valid boundary",position:.init(x:100,y:2,z:0),candela:900,kelvin:5600)])
_ = try boundaryScene.validated()
let unchanged = try SceneTransform.arranged(boundaryScene,subjectAt:boundarySubject)
print("SceneTransform identity retained X:",unchanged.lights[0].position.x)
do {
    _ = try ARPlacementLayout(scene:boundaryScene,origin:.init(x:boundarySubject.x,y:0,z:0),yawDegrees:0)
    fatalError("Expected AR identity defect did not reproduce")
} catch let error as ARPlacementError {
    print("REPRODUCED AR identity rejection:",error,"computed X",boundarySubject.x+(100-boundarySubject.x),"expected X",100.0)
}
