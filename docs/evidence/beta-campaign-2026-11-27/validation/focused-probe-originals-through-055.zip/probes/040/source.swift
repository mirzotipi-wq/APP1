import Foundation

public struct Position: Codable, Equatable, Sendable {
    public static let coordinateRange: ClosedRange<Double> = -100...100
    public var x: Double
    public var y: Double
    public var z: Double
    public init(x: Double, y: Double, z: Double) {
        self.x = x; self.y = y; self.z = z
    }
    public var isValid: Bool {
        [x, y, z].allSatisfy { $0.isFinite && Self.coordinateRange.contains($0) }
    }
    public func distance(to other: Position) -> Double {
        let dx = x - other.x, dy = y - other.y, dz = z - other.z
        return (dx * dx + dy * dy + dz * dz).squareRoot()
    }
}

public struct StudioLight: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var name: String
    public var position: Position
    /// On-axis luminous intensity, not electrical watts.
    public var candela: Double
    public var kelvin: Double
    /// Nil preserves the legacy isotropic point source.
    public var optics: LightOptics?
    public init(id: UUID = UUID(), name: String, position: Position, candela: Double, kelvin: Double, optics: LightOptics? = nil) {
        self.id = id; self.name = name; self.position = position
        self.candela = candela; self.kelvin = kelvin; self.optics = optics
    }
    public var isValid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && name.count <= 80 &&
        position.isValid && candela.isFinite && (0...100_000).contains(candela) &&
        kelvin.isFinite && (1_000...20_000).contains(kelvin) && (optics?.isValid ?? true)
    }
}

public enum SceneError: Error, Equatable {
    case unsupportedVersion, invalidScene, invalidLight, duplicateLight
}

public struct LightingScene: Codable, Equatable, Sendable {
    public static let currentSchemaVersion = 5
    public var schemaVersion: Int = currentSchemaVersion
    public var subject: Position
    public var camera: Position
    /// Nil uses the default 50 mm full-frame perspective.
    public var cameraLens: CameraLens?
    public var lights: [StudioLight]
    /// Nil retains the default diagnostic card balance and exposure.
    public var previewSettings: PreviewSettings?
    /// Nil means no measured room has been saved with this scene.
    public var placementRoom: ManualRoom?

    public init(subject: Position, camera: Position, lights: [StudioLight], cameraLens: CameraLens? = nil, previewSettings: PreviewSettings? = nil, placementRoom: ManualRoom? = nil) {
        self.subject = subject; self.camera = camera; self.lights = lights; self.cameraLens = cameraLens; self.previewSettings = previewSettings
        self.placementRoom = placementRoom
    }

    public func validated() throws -> Self {
        guard (1...Self.currentSchemaVersion).contains(schemaVersion) else { throw SceneError.unsupportedVersion }
        guard lights.count <= 12 else { throw SceneError.invalidScene }
        // Version 1 never contained optics; reject ambiguous mislabeled files.
        guard schemaVersion != 1 || lights.allSatisfy({ $0.optics == nil }) else { throw SceneError.invalidScene }
        // Version 2 adds light optics, version 3 adds a camera lens.
        guard schemaVersion >= 3 || cameraLens == nil else { throw SceneError.invalidScene }
        guard schemaVersion >= 4 || previewSettings == nil else { throw SceneError.invalidScene }
        // Version 5 adds measured rooms and rectangular-emitter roll.
        guard schemaVersion >= 5 || (placementRoom == nil && lights.allSatisfy({ $0.optics?.rollDegrees == nil })) else {
            throw SceneError.invalidScene
        }
        guard subject.isValid, camera.isValid, (cameraLens?.isValid ?? true), (previewSettings?.isValid ?? true),
              (placementRoom?.isValid ?? true) else { throw SceneError.invalidScene }
        guard lights.allSatisfy({ $0.isValid }) else { throw SceneError.invalidLight }
        guard Set(lights.map(\.id)).count == lights.count else { throw SceneError.duplicateLight }
        var migrated = self
        migrated.schemaVersion = Self.currentSchemaVersion
        return migrated
    }

    public static func portrait() -> Self {
        .init(subject: .init(x: 0, y: 1.5, z: 0),
              camera: .init(x: 0, y: 1.5, z: 3),
              lights: [
                .init(name: "Key", position: .init(x: -1.5, y: 2.1, z: 1.2), candela: 900, kelvin: 5600),
                .init(name: "Fill", position: .init(x: 1.5, y: 1.7, z: 1.5), candela: 300, kelvin: 5600),
                .init(name: "Rim", position: .init(x: 0.8, y: 2.2, z: -1.2), candela: 450, kelvin: 3200)
              ])
    }
}

public enum Photometry {
    /// Ideal point source, normal incidence. No occlusion, falloff pattern, modifier or near-field model.
    public static func normalIlluminance(candela: Double, distanceMeters: Double) -> Double? {
        guard candela.isFinite, (0...100_000).contains(candela),
              distanceMeters.isFinite, distanceMeters >= 0.05 else { return nil }
        return candela / (distanceMeters * distanceMeters)
    }
}

import Foundation

/// An ideal rectilinear full-frame camera. Focal length is actual millimeters,
/// not a zoom factor; distortion, focus breathing and depth of field are excluded.
public struct CameraLens: Codable, Equatable, Sendable {
    public static let sensorWidthMillimeters = 36.0
    public static let sensorHeightMillimeters = 24.0
    public static let focalLengthRange: ClosedRange<Double> = 14...200
    public var focalLengthMillimeters: Double

    public init(focalLengthMillimeters: Double = 50) {
        self.focalLengthMillimeters = focalLengthMillimeters
    }

    public var isValid: Bool {
        focalLengthMillimeters.isFinite && Self.focalLengthRange.contains(focalLengthMillimeters)
    }
}

extension LightingScene {
    public var effectiveCameraLens: CameraLens { cameraLens ?? .init() }
}

/// Coordinates on the ideal sensor: +x image right, +y image up, [-1, 1]
/// across the image. Values outside that interval are off-frame, not clamped.
public struct CameraProjection: Equatable, Sendable {
    public let x: Double
    public let y: Double
    public let depthMeters: Double
    public var isInsideFrame: Bool { abs(x) <= 1 && abs(y) <= 1 }
}

/// A camera aimed at the subject center. The world is right-handed; camera
/// forward is local -Z, so camera right is the negative of emitter-frame right.
public struct CameraFraming: Equatable, Sendable {
    public static let minimumDepthMeters = 0.05
    public static let aspectRatio = CameraLens.sensorWidthMillimeters / CameraLens.sensorHeightMillimeters
    public let position: Position
    public let target: Position
    public let lens: CameraLens
    public let right: UnitDirection
    public let up: UnitDirection
    public let forward: UnitDirection
    public let subjectDistanceMeters: Double

    public init?(scene: LightingScene) {
        let lens = scene.effectiveCameraLens
        let distance = scene.camera.distance(to: scene.subject)
        guard lens.isValid, distance >= Self.minimumDepthMeters,
              let frame = EmitterFrame(source: scene.camera, target: scene.subject),
              let right = UnitDirection(x: -frame.right.x, y: -frame.right.y, z: -frame.right.z) else { return nil }
        self.position = scene.camera; self.target = scene.subject; self.lens = lens
        self.right = right; self.up = frame.up; self.forward = frame.normal
        self.subjectDistanceMeters = distance
    }

    public var horizontalFieldOfViewDegrees: Double {
        2 * atan(CameraLens.sensorWidthMillimeters / (2 * lens.focalLengthMillimeters)) * 180 / .pi
    }
    public var verticalFieldOfViewDegrees: Double {
        2 * atan(CameraLens.sensorHeightMillimeters / (2 * lens.focalLengthMillimeters)) * 180 / .pi
    }
    /// Width and height of the subject plane perpendicular to the optical axis.
    public var subjectPlaneWidthMeters: Double {
        subjectDistanceMeters * CameraLens.sensorWidthMillimeters / lens.focalLengthMillimeters
    }
    public var subjectPlaneHeightMeters: Double {
        subjectDistanceMeters * CameraLens.sensorHeightMillimeters / lens.focalLengthMillimeters
    }

    public func project(_ world: Position) -> CameraProjection? {
        guard world.isValid else { return nil }
        let dx = world.x - position.x, dy = world.y - position.y, dz = world.z - position.z
        func dot(_ direction: UnitDirection) -> Double { dx * direction.x + dy * direction.y + dz * direction.z }
        let depth = dot(forward)
        guard depth >= Self.minimumDepthMeters else { return nil }
        return CameraProjection(x: 2 * lens.focalLengthMillimeters * dot(right) / (CameraLens.sensorWidthMillimeters * depth),
                                y: 2 * lens.focalLengthMillimeters * dot(up) / (CameraLens.sensorHeightMillimeters * depth),
                                depthMeters: depth)
    }
}

public struct PreviewSettings: Codable, Equatable, Sendable {
    public static let whiteBalanceRange: ClosedRange<Double> = 2000...10000
    public static let exposureRange: ClosedRange<Double> = -6...6
    public var whiteBalanceKelvin: Double
    public var exposureStops: Double

    public init(whiteBalanceKelvin: Double = 5600, exposureStops: Double = 0) {
        self.whiteBalanceKelvin = whiteBalanceKelvin; self.exposureStops = exposureStops
    }
    public var isValid: Bool {
        whiteBalanceKelvin.isFinite && Self.whiteBalanceRange.contains(whiteBalanceKelvin) &&
        exposureStops.isFinite && Self.exposureRange.contains(exposureStops)
    }
}
public struct ManualRoom: Codable, Equatable, Sendable {
    public static let dimensionRange: ClosedRange<Double> = 1...30
    public var widthMeters: Double
    public var depthMeters: Double
    /// Nil means the ceiling height has not been measured.
    public var ceilingHeightMeters: Double?
    public var subjectX: Double
    public var subjectZ: Double
    public var yawDegrees: Double

    public init(widthMeters: Double = 6, depthMeters: Double = 7,
                subjectX: Double = 3, subjectZ: Double = 2, yawDegrees: Double = 0,
                ceilingHeightMeters: Double? = nil) {
        self.widthMeters = widthMeters; self.depthMeters = depthMeters
        self.ceilingHeightMeters = ceilingHeightMeters
        self.subjectX = subjectX; self.subjectZ = subjectZ; self.yawDegrees = yawDegrees
    }

    /// Resizing is independent of the subject's location. The editor must
    /// require an explicit subject move before accepting a smaller room.
    public var widthEditRange: ClosedRange<Double> { dimensionRangePreserving(subjectX) }
    public var depthEditRange: ClosedRange<Double> { dimensionRangePreserving(subjectZ) }

    private func dimensionRangePreserving(_ offset: Double) -> ClosedRange<Double> {
        guard offset.isFinite, offset >= 0, offset <= Self.dimensionRange.upperBound else {
            return Self.dimensionRange
        }
        return max(Self.dimensionRange.lowerBound, offset)...Self.dimensionRange.upperBound
    }

    /// Rotate relative to the current placement, preserving dimensions and
    /// subject offsets. Canonical output is in (-180, 180], matching the UI's
    /// slider range. Invalid input leaves the entire room unchanged.
    @discardableResult
    public mutating func rotate(byDegrees degrees: Double) -> Bool {
        guard isValid, degrees.isFinite else { return false }
        // Reduce the delta before addition so even a very large finite input
        // cannot overflow or lose the bounded starting orientation.
        var angle = (yawDegrees + degrees.truncatingRemainder(dividingBy: 360))
            .truncatingRemainder(dividingBy: 360)
        if angle > 180 { angle -= 360 }
        if angle <= -180 { angle += 360 }
        yawDegrees = angle == 0 ? 0 : angle
        return true
    }

    public var isValid: Bool {
        widthMeters.isFinite && depthMeters.isFinite &&
        Self.dimensionRange.contains(widthMeters) && Self.dimensionRange.contains(depthMeters) &&
        (ceilingHeightMeters.map { $0.isFinite && Self.dimensionRange.contains($0) } ?? true) &&
        subjectX.isFinite && subjectZ.isFinite && subjectX >= 0 && subjectX <= widthMeters &&
        subjectZ >= 0 && subjectZ <= depthMeters &&
        yawDegrees.isFinite && (-360...360).contains(yawDegrees)
    }
}
public struct UnitDirection: Equatable, Sendable {
    public let x: Double
    public let y: Double
    public let z: Double

    public init?(x: Double, y: Double, z: Double) {
        guard x.isFinite, y.isFinite, z.isFinite else { return nil }
        let scale = max(abs(x), max(abs(y), abs(z)))
        guard scale > 0 else { return nil }
        let a = x / scale, b = y / scale, c = z / scale
        let length = (a * a + b * b + c * c).squareRoot()
        self.x = a / length; self.y = b / length; self.z = c / length
    }

    fileprivate var vector: SIMD3<Double> { .init(x, y, z) }
}
import Foundation

public enum EmitterKind: String, Codable, CaseIterable, Sendable {
    case point, directional, rectangle

    public var title: String {
        switch self {
        case .point: return "Bare point"
        case .directional: return "Directional"
        case .rectangle: return "Rectangular softbox"
        }
    }
    public var isAimed: Bool { self != .point }
}

/// Ideal emitter geometry, not a measured modifier or equipment profile.
/// Nil aimTarget follows the subject. A manual target is an absolute world position in meters.
public struct LightOptics: Codable, Equatable, Sendable {
    public static let dimensionRange: ClosedRange<Double> = 0.05...4
    public static let rollRange: ClosedRange<Double> = -180...180
    public var kind: EmitterKind
    public var aimTarget: Position?
    public var widthMeters: Double
    public var heightMeters: Double
    /// Rotation about the emitting normal. Nil preserves the legacy world-up orientation.
    public var rollDegrees: Double?

    public init(kind: EmitterKind = .point, aimTarget: Position? = nil,
                widthMeters: Double = 0.6, heightMeters: Double = 0.9,
                rollDegrees: Double? = nil) {
        self.kind = kind; self.aimTarget = aimTarget
        self.widthMeters = widthMeters; self.heightMeters = heightMeters
        self.rollDegrees = rollDegrees
    }

    public var effectiveRollDegrees: Double { rollDegrees ?? 0 }

    public var isValid: Bool {
        (aimTarget?.isValid ?? true) && widthMeters.isFinite && heightMeters.isFinite &&
        Self.dimensionRange.contains(widthMeters) && Self.dimensionRange.contains(heightMeters) &&
        effectiveRollDegrees.isFinite && Self.rollRange.contains(effectiveRollDegrees)
    }
}

extension StudioLight {
    public var effectiveOptics: LightOptics { optics ?? .init() }
    public func target(subject: Position) -> Position { effectiveOptics.aimTarget ?? subject }
}

/// Right-handed world-space basis; right × up = emitting normal.
/// Zero roll follows world up, with a deterministic basis at a vertical aim.
/// Positive roll turns right toward up around the emitting normal (the right-hand rule).
public struct EmitterFrame: Equatable, Sendable {
    public let right: UnitDirection
    public let up: UnitDirection
    public let normal: UnitDirection

    public init?(source: Position, target: Position, rollDegrees: Double = 0) {
        guard source.isValid, target.isValid, rollDegrees.isFinite,
              LightOptics.rollRange.contains(rollDegrees),
              let n = UnitDirection(x: target.x - source.x, y: target.y - source.y, z: target.z - source.z) else { return nil }
        let horizontal = hypot(n.x, n.z)
        let r = horizontal > 1e-12
            ? UnitDirection(x: n.z, y: 0, z: -n.x)
            : UnitDirection(x: 1, y: 0, z: 0)
        guard let r, let u = UnitDirection(x: n.y * r.z - n.z * r.y,
                                           y: n.z * r.x - n.x * r.z,
                                           z: n.x * r.y - n.y * r.x) else { return nil }
        // Keep legacy sample coordinates exactly unchanged when no roll is requested.
        if rollDegrees == 0 {
            self.right = r; self.up = u; self.normal = n
            return
        }
        // Exact cardinal coefficients keep mathematical wall/floor/ceiling
        // contact from becoming a trigonometric overhang. Do not snap other
        // angles or physical coordinates: real overhangs must remain outside.
        let c: Double
        let s: Double
        switch rollDegrees {
        case 90: c = 0; s = 1
        case -90: c = 0; s = -1
        case -180, 180: c = -1; s = 0
        default:
            let radians = rollDegrees * .pi / 180
            c = cos(radians); s = sin(radians)
        }
        guard let rolledRight = UnitDirection(x: c * r.x + s * u.x,
                                              y: c * r.y + s * u.y,
                                              z: c * r.z + s * u.z),
              let rolledUp = UnitDirection(x: -s * r.x + c * u.x,
                                           y: -s * r.y + c * u.y,
                                           z: -s * r.z + c * u.z) else { return nil }
        self.right = rolledRight; self.up = rolledUp; self.normal = n
    }
}


public enum StudioPhotometry {
public static func frame(for light: StudioLight, subject: Position) -> EmitterFrame? {
        guard light.isValid, light.effectiveOptics.kind.isAimed else { return nil }
        return EmitterFrame(source: light.position, target: light.target(subject: subject),
                            rollDegrees: light.effectiveOptics.effectiveRollDegrees)
    }
}
import Foundation

public enum SceneTransformError: Error, Equatable, LocalizedError {
    case invalidTransform, undefinedCameraDirection, outsideSupportedScene

    public var errorDescription: String? {
        switch self {
        case .invalidTransform: return "Enter finite position or rotation values."
        case .undefinedCameraDirection: return "Move the camera horizontally away from the subject before mirroring the lights."
        case .outsideSupportedScene: return "This move would place part of the setup outside the supported scene. Nothing was moved."
        }
    }
}

/// Atomic transforms preserve source identity, photometric settings and room context.
public enum SceneTransform {
    /// Rotates lights about the original subject, optionally mirrors them across
    /// the camera's center plane, then moves the whole setup to the destination.
    /// Only the input and completed arrangement must fit the supported scene;
    /// an intermediate rotation or reflection may temporarily leave its bounds.
    public static func arranged(_ source: LightingScene, subjectAt destination: Position,
                                rotatingLightsByDegrees angle: Double = 0,
                                mirroringLights mirror: Bool = false) throws -> LightingScene {
        guard destination.x.isFinite, destination.y.isFinite, destination.z.isFinite,
              angle.isFinite else { throw SceneTransformError.invalidTransform }
        var scene = try source.validated()
        let center = scene.subject
        let degrees = angle.truncatingRemainder(dividingBy: 360)
        let (c, s) = rotationComponents(degrees: degrees)
        var diagonal = 1.0, cross = 0.0
        if mirror {
            let dx = scene.camera.x - center.x, dz = scene.camera.z - center.z
            guard hypot(dx, dz) > 1e-9 else { throw SceneTransformError.undefinedCameraDirection }
            // Exact axis and diagonal planes remain signed coordinate swaps.
            if dx == 0 { diagonal = -1 }
            else if dz == 0 { diagonal = 1 }
            else if dx == dz { diagonal = 0; cross = 1 }
            else if dx == -dz { diagonal = 0; cross = -1 }
            else {
                let squaredDistance = dx * dx + dz * dz
                diagonal = (dx * dx - dz * dz) / squaredDistance
                cross = 2 * (dx * dz) / squaredDistance
            }
        }
        func shifted(_ p: Position) -> Position {
            .init(x: affineSum([destination.x, p.x, -center.x]),
                  y: affineSum([destination.y, p.y, -center.y]),
                  z: affineSum([destination.z, p.z, -center.z]))
        }
        func arrangedPosition(_ p: Position) -> Position {
            // Carry the original coordinate terms through the linear operations.
            // Rounding a displacement, intermediate world position or translation
            // first can turn a valid final boundary point into an outside value.
            let x = [p.x, -center.x], z = [p.z, -center.z]
            var needsExactProducts = false
            let rotatedX = scaledTerms(x, by: c, needsExact: &needsExactProducts)
                + scaledTerms(z, by: s, needsExact: &needsExactProducts)
            let rotatedZ = scaledTerms(x, by: -s, needsExact: &needsExactProducts)
                + scaledTerms(z, by: c, needsExact: &needsExactProducts)
            let finalX = mirror
                ? scaledTerms(rotatedX, by: diagonal, needsExact: &needsExactProducts)
                    + scaledTerms(rotatedZ, by: cross, needsExact: &needsExactProducts) : rotatedX
            let finalZ = mirror
                ? scaledTerms(rotatedX, by: cross, needsExact: &needsExactProducts)
                    + scaledTerms(rotatedZ, by: -diagonal, needsExact: &needsExactProducts) : rotatedZ
            func exactCoordinate(_ destination: Double, first: Double, second: Double) -> Double {
                // Expand the original expression, including both linear maps.
                // Its coefficients are the computed Doubles, not ideal real trig.
                var products = [[destination]]
                products += x.map { [$0, c, first] }
                products += z.map { [$0, s, first] }
                products += x.map { [$0, -s, second] }
                products += z.map { [$0, c, second] }
                return exactProductSum(products)
            }
            let horizontalX = needsExactProducts
                ? exactCoordinate(destination.x, first: mirror ? diagonal : 1, second: mirror ? cross : 0)
                : affineSum([destination.x] + finalX)
            let horizontalZ = needsExactProducts
                ? exactCoordinate(destination.z, first: mirror ? cross : 0, second: mirror ? -diagonal : 1)
                : affineSum([destination.z] + finalZ)
            return .init(x: horizontalX,
                         y: affineSum([destination.y, p.y, -center.y]),
                         z: horizontalZ)
        }
        scene.camera = shifted(scene.camera)
        scene.lights = scene.lights.map { light in
            var next = light
            next.position = arrangedPosition(light.position)
            if let target = light.optics?.aimTarget { next.optics?.aimTarget = arrangedPosition(target) }
            if mirror, let roll = next.optics?.rollDegrees { next.optics?.rollDegrees = -roll }
            if degrees != 0 || mirror {
                Self.adjustVerticalRoll(from: light, to: &next, subject: center,
                                        nextSubject: destination) { direction in
                    let x = c * direction.x + s * direction.z
                    let z = -s * direction.x + c * direction.z
                    guard mirror else { return .init(x: x, y: direction.y, z: z) }
                    // Reflection reverses handedness, so reverse the width axis
                    // as in the standalone mirror without changing the rectangle.
                    return .init(x: -(diagonal * x + cross * z), y: -direction.y,
                                 z: -(cross * x - diagonal * z))
                }
            }
            return next
        }
        scene.subject = destination
        return try validatedResult(scene)
    }

    public static func translated(_ source: LightingScene, by offset: Position) throws -> LightingScene {
        guard offset.x.isFinite, offset.y.isFinite, offset.z.isFinite else {
            throw SceneTransformError.invalidTransform
        }
        var scene = try source.validated()
        translate(&scene, by: offset)
        return try validatedResult(scene)
    }

    private static func translate(_ scene: inout LightingScene, by offset: Position) {
        func shifted(_ p: Position) -> Position {
            .init(x: p.x + offset.x, y: p.y + offset.y, z: p.z + offset.z)
        }
        scene.subject = shifted(scene.subject)
        scene.camera = shifted(scene.camera)
        scene.lights = scene.lights.map { light in
            var next = light
            next.position = shifted(light.position)
            if let target = next.optics?.aimTarget { next.optics?.aimTarget = shifted(target) }
            return next
        }
    }

    /// Rotates lights and their explicit aims about the subject's vertical axis.
    /// The camera and measured subject position stay fixed.
    public static func rotatingLights(_ source: LightingScene, byDegrees angle: Double) throws -> LightingScene {
        guard angle.isFinite else { throw SceneTransformError.invalidTransform }
        var scene = try source.validated()
        rotateLights(&scene, byDegrees: angle)
        return try validatedResult(scene)
    }

    private static func rotateLights(_ scene: inout LightingScene, byDegrees angle: Double) {
        let degrees = angle.truncatingRemainder(dividingBy: 360)
        guard degrees != 0 else { return }
        let (c, s) = rotationComponents(degrees: degrees)
        let center = scene.subject
        func rotated(_ p: Position) -> Position {
            // Retain the original coordinate terms until the completed sum;
            // rounding a displacement first can reject a valid boundary point.
            let x = [p.x, -center.x], z = [p.z, -center.z]
            func coordinate(_ origin: Double, _ first: Double, _ second: Double) -> Double {
                var needsExact = false
                let terms = scaledTerms(x, by: first, needsExact: &needsExact)
                    + scaledTerms(z, by: second, needsExact: &needsExact)
                if needsExact {
                    return exactProductSum([[origin]] + x.map { [$0, first] }
                        + z.map { [$0, second] })
                }
                return affineSum([origin] + terms)
            }
            return .init(x: coordinate(center.x, c, s), y: p.y,
                         z: coordinate(center.z, -s, c))
        }
        scene.lights = scene.lights.map { light in
            var next = light
            next.position = rotated(light.position)
            if let target = next.optics?.aimTarget { next.optics?.aimTarget = rotated(target) }
            Self.adjustVerticalRoll(from: light, to: &next, subject: center) { direction in
                .init(x: c * direction.x + s * direction.z, y: direction.y,
                      z: -s * direction.x + c * direction.z)
            }
            return next
        }
    }

    private static func rotationComponents(degrees: Double) -> (Double, Double) {
        // Exact quarter turns must not push an on-boundary coordinate outside
        // the supported range through a small trigonometric residual.
        switch degrees {
        case 0: return (1, 0)
        case 90, -270: return (0, 1)
        case -90, 270: return (0, -1)
        case 180, -180: return (-1, 0)
        default:
            let radians = degrees * .pi / 180
            return (cos(radians), sin(radians))
        }
    }

    /// Reflects lighting across the camera's vertical center plane.
    public static func mirroringLights(_ source: LightingScene) throws -> LightingScene {
        var scene = try source.validated()
        try mirrorLights(&scene)
        return try validatedResult(scene)
    }

    private static func mirrorLights(_ scene: inout LightingScene) throws {
        let center = scene.subject
        let dx = scene.camera.x - center.x, dz = scene.camera.z - center.z
        let horizontalDistance = hypot(dx, dz)
        guard horizontalDistance > 1e-9 else { throw SceneTransformError.undefinedCameraDirection }
        // The reflection plane is vertical even when the camera is tilted.
        // The unnormalized form also keeps axis-aligned and diagonal camera
        // planes exact, avoiding square-root roundoff at the scene boundary.
        let squaredDistance = dx * dx + dz * dz
        let diagonal = (dx * dx - dz * dz) / squaredDistance
        let cross = 2 * (dx * dz) / squaredDistance
        func reflectedDirection(_ p: Position) -> Position {
            .init(x: diagonal * p.x + cross * p.z, y: p.y,
                  z: cross * p.x - diagonal * p.z)
        }
        func mirrored(_ p: Position) -> Position {
            // Use exact axis/diagonal formulas only for exact camera directions.
            // They avoid cancelling the source against its displacement and
            // preserve an axis-aligned plane's unchanged coordinate verbatim.
            if dx == 0 {
                return .init(x: 2 * center.x - p.x, y: p.y, z: p.z)
            }
            if dz == 0 {
                return .init(x: p.x, y: p.y, z: 2 * center.z - p.z)
            }
            if dx == dz {
                return .init(x: affineSum([p.z, center.x, -center.z]), y: p.y,
                             z: affineSum([p.x, center.z, -center.x]))
            }
            if dx == -dz {
                return .init(x: affineSum([-p.z, center.x, center.z]), y: p.y,
                             z: affineSum([-p.x, center.z, center.x]))
            }
            // Retain the original terms and product residuals until the final
            // coordinate. Rounded offsets or coefficient differences can move
            // a valid boundary point outside, or hide a true outside result.
            let x = [p.x, -center.x], z = [p.z, -center.z]
            func coordinate(_ origin: Double, _ first: Double, _ second: Double) -> Double {
                var needsExact = false
                let terms = scaledTerms(x, by: first, needsExact: &needsExact)
                    + scaledTerms(z, by: second, needsExact: &needsExact)
                if needsExact {
                    return exactProductSum([[origin]] + x.map { [$0, first] }
                        + z.map { [$0, second] })
                }
                return affineSum([origin] + terms)
            }
            return .init(x: coordinate(center.x, diagonal, cross), y: p.y,
                         z: coordinate(center.z, cross, -diagonal))
        }
        scene.lights = scene.lights.map { light in
            var next = light
            next.position = mirrored(light.position)
            if let target = next.optics?.aimTarget { next.optics?.aimTarget = mirrored(target) }
            if let roll = next.optics?.rollDegrees { next.optics?.rollDegrees = -roll }
            Self.adjustVerticalRoll(from: light, to: &next, subject: center) { direction in
                let reflected = reflectedDirection(direction)
                // A reflection reverses handedness; negating the width axis
                // restores the emitter normal without changing its rectangle.
                return .init(x: -reflected.x, y: -reflected.y, z: -reflected.z)
            }
            return next
        }
    }

    /// Keep representable product residuals alongside the original terms. A
    /// product with bits below 2^-1074 needs the integer fallback: even FMA cannot
    /// retain its whole residual. Signed coordinate swaps stay on the fast path.
    private static func scaledTerms(_ terms: [Double], by factor: Double,
                                    needsExact: inout Bool) -> [Double] {
        if factor == 0 { return [] }
        if factor == 1 { return terms }
        if factor == -1 { return terms.map { -$0 } }
        let factorExponent = binaryFactor(factor).exponent
        return terms.flatMap { term -> [Double] in
            if term != 0, binaryFactor(term).exponent + factorExponent < -1074 {
                needsExact = true
            }
            let product = term * factor
            let residual = (-product).addingProduct(term, factor)
            return [residual, product]
        }
    }

    /// Exact finite binary decomposition; a nonzero significand is odd, so its
    /// exponent identifies the lowest set bit without counting padding zeros.
    private static func binaryFactor(_ value: Double) -> (significand: UInt64, exponent: Int, negative: Bool) {
        let bits = value.bitPattern
        let encodedExponent = Int((bits >> 52) & 0x7ff)
        var significand = bits & 0x000f_ffff_ffff_ffff
        if encodedExponent != 0 { significand |= 1 << 52 }
        guard significand != 0 else { return (0, 0, false) }
        let trailing = significand.trailingZeroBitCount
        significand >>= trailing
        return (significand, (encodedExponent == 0 ? -1074 : encodedExponent - 1075) + trailing,
                bits >> 63 != 0)
    }

    /// Rare underflow path for an arrangement coordinate: at most nine terms,
    /// with at most three binary64 factors each. Products reach down to 2^-3222.
    /// Finite destinations and bounded scene/coefficient inputs need at most 67
    /// UInt64 limbs, including four carry bits. Only the final result is rounded,
    /// to nearest-even on the normal or subnormal binary64 lattice.
    private static func exactProductSum(_ terms: [[Double]]) -> Double {
        precondition(terms.count <= 9 && terms.allSatisfy { $0.count <= 3 })
        var products: [(words: [UInt64], exponent: Int, negative: Bool)] = []
        for factors in terms {
            var words: [UInt64] = [1]
            var exponent = 0, negative = false, isZero = false
            for factor in factors {
                precondition(factor.isFinite)
                let part = binaryFactor(factor)
                if part.significand == 0 { isZero = true; break }
                exponent += part.exponent
                negative = negative != part.negative
                var carry: UInt64 = 0
                for index in words.indices {
                    let multiplied = words[index].multipliedFullWidth(by: part.significand)
                    let (low, overflow) = multiplied.low.addingReportingOverflow(carry)
                    words[index] = low
                    carry = multiplied.high + (overflow ? 1 : 0)
                }
                if carry != 0 { words.append(carry) }
            }
            if !isZero { products.append((words, exponent, negative)) }
        }
        guard let origin = products.map({ $0.exponent }).min() else { return 0 }
        let highest = products.map {
            $0.exponent + 64 * $0.words.count - $0.words.last!.leadingZeroBitCount
        }.max()!
        let wordCount = (highest - origin + 4 + 63) / 64
        precondition((1...67).contains(wordCount), "Arrangement accumulator capacity exceeded")
        var positive = [UInt64](repeating: 0, count: wordCount)
        var negative = positive
        func add(_ value: UInt64, at start: Int, to target: inout [UInt64]) {
            var carry = value, index = start
            while carry != 0 {
                precondition(target.indices.contains(index), "Arrangement accumulator overflow")
                let (sum, overflow) = target[index].addingReportingOverflow(carry)
                target[index] = sum
                carry = overflow ? 1 : 0
                index += 1
            }
        }
        for product in products {
            let shift = product.exponent - origin
            let offset = shift / 64, bits = shift % 64
            for (index, word) in product.words.enumerated() {
                if product.negative {
                    add(word << bits, at: offset + index, to: &negative)
                    if bits != 0 { add(word >> (64 - bits), at: offset + index + 1, to: &negative) }
                } else {
                    add(word << bits, at: offset + index, to: &positive)
                    if bits != 0 { add(word >> (64 - bits), at: offset + index + 1, to: &positive) }
                }
            }
        }
        guard let difference = positive.indices.reversed().first(where: { positive[$0] != negative[$0] })
        else { return 0 }
        let isNegative = negative[difference] > positive[difference]
        var magnitude = isNegative ? negative : positive
        let smaller = isNegative ? positive : negative
        var borrow: UInt64 = 0
        for index in magnitude.indices {
            let (difference, firstBorrow) = magnitude[index].subtractingReportingOverflow(smaller[index])
            let (value, secondBorrow) = difference.subtractingReportingOverflow(borrow)
            magnitude[index] = value
            borrow = firstBorrow || secondBorrow ? 1 : 0
        }
        precondition(borrow == 0)
        let topWord = magnitude.indices.reversed().first { magnitude[$0] != 0 }!
        let topBit = topWord * 64 + 63 - magnitude[topWord].leadingZeroBitCount
        let discarded = max(0, max(topBit - 52, -1074 - origin))
        func word(at index: Int) -> UInt64 { magnitude.indices.contains(index) ? magnitude[index] : 0 }
        func bit(at index: Int) -> Bool { word(at: index / 64) & (1 << (index % 64)) != 0 }
        func hasBits(below count: Int) -> Bool {
            let wholeWords = count / 64, remaining = count % 64
            if magnitude.prefix(wholeWords).contains(where: { $0 != 0 }) { return true }
            return remaining != 0 && word(at: wholeWords) & ((1 << remaining) - 1) != 0
        }
        let offset = discarded / 64, bits = discarded % 64
        var rounded = word(at: offset) >> bits
        if bits != 0 { rounded |= word(at: offset + 1) << (64 - bits) }
        precondition(rounded < 1 << 53)
        if discarded > 0, bit(at: discarded - 1),
           hasBits(below: discarded - 1) || rounded & 1 != 0 {
            rounded += 1
        }
        // This integer is exactly representable; the scaling is also exact after
        // the explicit rounding above, including a carry into the normal range.
        return Double(sign: isNegative ? .minus : .plus, exponent: origin + discarded,
                      significand: Double(rounded))
    }

    /// Sum the affine terms once, retaining every addition residual. Even a
    /// tiny remaining term can decide which side of a halfway result is correct.
    private static func affineSum(_ terms: [Double]) -> Double {
        func sum(_ a: Double, _ b: Double) -> (value: Double, residual: Double) {
            let value = a + b
            let part = value - a
            return (value, (a - (value - part)) + (b - part))
        }
        var partials: [Double] = []
        for var term in terms {
            var count = 0
            for partial in partials {
                let combined = sum(term, partial)
                if combined.residual != 0 {
                    partials[count] = combined.residual
                    count += 1
                }
                term = combined.value
            }
            partials.removeSubrange(count..<partials.count)
            if term != 0 { partials.append(term) }
        }
        guard var result = partials.popLast() else { return 0 }
        var residual = 0.0
        while let partial = partials.popLast() {
            let combined = sum(result, partial)
            result = combined.value
            residual = combined.residual
            if residual != 0 { break }
        }
        // At a halfway result, a remaining term with the residual's sign
        // selects the adjacent value. The exact-step check distinguishes
        // this tie from a residual that must leave the rounded sum alone.
        if let remaining = partials.last,
           (residual > 0 && remaining > 0) || (residual < 0 && remaining < 0) {
            let step = 2 * residual
            let adjacent = result + step
            if adjacent - result == step { result = adjacent }
        }
        return result
    }

    private static func validatedResult(_ scene: LightingScene) throws -> LightingScene {
        guard let validated = try? scene.validated() else { throw SceneTransformError.outsideSupportedScene }
        return validated
    }

    /// World-up frames rotate covariantly except at their vertical fallback.
    /// Reconstruct only that case, preserving entered rolls elsewhere.
    private static func adjustVerticalRoll(from light: StudioLight, to next: inout StudioLight,
                                           subject: Position, nextSubject: Position? = nil,
                                           transform: (Position) -> Position) {
        guard light.effectiveOptics.kind == .rectangle,
              let original = transformFrame(source: light.position, target: light.target(subject: subject),
                                            rollDegrees: light.effectiveOptics.effectiveRollDegrees),
              let baseline = transformFrame(source: next.position,
                                            target: next.target(subject: nextSubject ?? subject)),
              hypot(original.normal.x, original.normal.z) <= 1e-12 ||
                hypot(baseline.normal.x, baseline.normal.z) <= 1e-12 else { return }
        let right = transform(.init(x: original.right.x, y: original.right.y, z: original.right.z))
        let cosine = right.x * baseline.right.x + right.y * baseline.right.y + right.z * baseline.right.z
        let sine = right.x * baseline.up.x + right.y * baseline.up.y + right.z * baseline.up.z
        let roll = atan2(sine, cosine) * 180 / .pi
        if roll != 0 || next.optics?.rollDegrees != nil { next.optics?.rollDegrees = roll }
    }

    /// Emitter orientation depends on direction, not world position. Intermediate
    /// arrangement coordinates may be outside the scene, so rebase only that case
    /// into a bounded direction before asking the shared frame for its basis.
    private static func transformFrame(source: Position, target: Position,
                                       rollDegrees: Double = 0) -> EmitterFrame? {
        if source.isValid, target.isValid {
            return EmitterFrame(source: source, target: target, rollDegrees: rollDegrees)
        }
        let x = target.x - source.x, y = target.y - source.y, z = target.z - source.z
        let scale = max(abs(x), max(abs(y), abs(z)))
        guard scale.isFinite, scale > 0 else { return nil }
        return EmitterFrame(source: .init(x: 0, y: 0, z: 0),
                            target: .init(x: x / scale, y: y / scale, z: z / scale),
                            rollDegrees: rollDegrees)
    }
}

import Foundation

public enum ARPlacementError: Error, Equatable, Sendable, LocalizedError {
    case invalidOrigin
    case invalidYaw
    case outsideSupportedScene

    public var errorDescription: String? {
        switch self {
        case .invalidOrigin:
            return "The floor anchor is outside the supported scene coordinates. Choose another floor position."
        case .invalidYaw:
            return "Enter a finite rotation for the setup."
        case .outsideSupportedScene:
            return "This placement would put part of the setup outside the supported scene coordinates. Move the anchor or adjust the setup."
        }
    }
}

/// A marker in the anchor's world coordinate system. All positions and
/// distances are in meters and describe the authored rig, not measured
/// equipment or an estimate of AR tracking accuracy.
public struct ARPlacementItem: Identifiable, Equatable, Sendable {
    public enum Role: String, Equatable, Sendable { case subject, camera, light }

    public let id: String
    public let role: Role
    public let name: String
    /// The original light ID; subject and camera do not have source UUIDs.
    public let sourceID: UUID?
    public let position: Position
    /// The vertical projection onto the plane through the floor anchor.
    public let floorPosition: Position
    /// Signed authored height above the anchor's floor plane.
    public let heightAboveFloorMeters: Double
    public let horizontalDistanceFromSubjectMeters: Double
    public let distanceFromSubjectMeters: Double
}

/// The ideal rectangular emitting face, including authored aim and roll.
/// Corners follow the perimeter in local (-right,-up), (+right,-up),
/// (+right,+up), (-right,+up) order. An undefined aim produces no corners.
/// These bounds do not include a stand, housing, cables or safety clearance.
public struct ARPlacementModifierFace: Identifiable, Equatable, Sendable {
    public let id: UUID
    public let name: String
    public let corners: [Position]
    public var isAvailable: Bool { corners.count == 4 }
}

/// Deterministic rigid placement at 1:1 scale in meters, independent of ARKit.
/// The subject's authored X/Z maps onto the floor anchor's X/Z. Authored Y
/// remains height above that anchor, so subject height is never subtracted.
/// Positive yaw rotates scene +Z toward world +X around the vertical axis.
///
/// Both source and placed geometry must fit Position.coordinateRange. This
/// mathematical bound is not a claim that AR tracking supports that distance;
/// device tracking suitability belongs to the native session adapter.
public struct ARPlacementLayout: Equatable, Sendable {
    public let origin: Position
    /// Canonical orientation in (-180, 180].
    public let yawDegrees: Double
    /// Stable order: subject, camera, then lights in authored scene order.
    public let items: [ARPlacementItem]
    public let modifierFaces: [ARPlacementModifierFace]
    public var unavailableModifierIDs: [UUID] {
        modifierFaces.filter { !$0.isAvailable }.map(\.id)
    }

    private let sourceSubject: Position
    private let cosine: Double
    private let sine: Double

    public init(scene: LightingScene, origin: Position, yawDegrees: Double = 0) throws {
        let scene = try scene.validated()
        guard origin.isValid else { throw ARPlacementError.invalidOrigin }
        guard yawDegrees.isFinite else { throw ARPlacementError.invalidYaw }

        var angle = yawDegrees.truncatingRemainder(dividingBy: 360)
        if angle > 180 { angle -= 360 }
        if angle <= -180 { angle += 360 }
        if angle == 0 { angle = 0 }

        // Exact quarter turns preserve exact coordinate boundaries rather
        // than rejecting a valid placement for a trigonometric residual.
        let c: Double, s: Double
        switch angle {
        case 0: c = 1; s = 0
        case 90: c = 0; s = 1
        case 180: c = -1; s = 0
        case -90: c = 0; s = -1
        default:
            let radians = angle * .pi / 180
            c = cos(radians); s = sin(radians)
        }

        func placed(_ position: Position) throws -> Position {
            guard let result = Self.transformed(position, subject: scene.subject,
                                                origin: origin, cosine: c, sine: s) else {
                throw ARPlacementError.outsideSupportedScene
            }
            return result
        }

        func item(id: String, role: ARPlacementItem.Role, name: String,
                  sourceID: UUID? = nil, position: Position) throws -> ARPlacementItem {
            let worldPosition = try placed(position)
            return .init(id: id, role: role, name: name, sourceID: sourceID,
                         position: worldPosition,
                         floorPosition: .init(x: worldPosition.x, y: origin.y, z: worldPosition.z),
                         heightAboveFloorMeters: position.y,
                         horizontalDistanceFromSubjectMeters:
                            hypot(position.x - scene.subject.x, position.z - scene.subject.z),
                         distanceFromSubjectMeters: position.distance(to: scene.subject))
        }

        var markers = [
            try item(id: "subject", role: .subject, name: "Subject", position: scene.subject),
            try item(id: "camera", role: .camera, name: "Camera", position: scene.camera)
        ]
        var faces: [ARPlacementModifierFace] = []
        for light in scene.lights {
            markers.append(try item(id: light.id.uuidString, role: .light, name: light.name,
                                    sourceID: light.id, position: light.position))
            let optics = light.effectiveOptics
            // Explicit targets are scene geometry even if the current emitter
            // kind does not use its stored target. Never silently drop bounds.
            if let target = optics.aimTarget { _ = try placed(target) }
            guard optics.kind == .rectangle else { continue }
            guard let frame = StudioPhotometry.frame(for: light, subject: scene.subject) else {
                faces.append(.init(id: light.id, name: light.name, corners: []))
                continue
            }
            let signs: [(Double, Double)] = [(-1, -1), (1, -1), (1, 1), (-1, 1)]
            let corners = try signs.map { horizontal, vertical -> Position in
                let rightOffset = horizontal * optics.widthMeters / 2
                let upOffset = vertical * optics.heightMeters / 2
                let source = Position(
                    x: light.position.x + rightOffset * frame.right.x + upOffset * frame.up.x,
                    y: light.position.y + rightOffset * frame.right.y + upOffset * frame.up.y,
                    z: light.position.z + rightOffset * frame.right.z + upOffset * frame.up.z
                )
                return try placed(source)
            }
            faces.append(.init(id: light.id, name: light.name, corners: corners))
        }

        self.origin = origin
        self.yawDegrees = angle
        self.items = markers
        self.modifierFaces = faces
        self.sourceSubject = scene.subject
        self.cosine = c
        self.sine = s
    }

    /// Applies the same subject-relative rigid transform to another authored
    /// point. Invalid source coordinates or out-of-bounds results return nil;
    /// no coordinates are clamped and no scale adjustment is made.
    public func transform(position: Position) -> Position? {
        Self.transformed(position, subject: sourceSubject, origin: origin,
                         cosine: cosine, sine: sine)
    }

    private static func transformed(_ position: Position, subject: Position,
                                    origin: Position, cosine: Double, sine: Double) -> Position? {
        guard position.isValid else { return nil }
        let x = position.x - subject.x, z = position.z - subject.z
        let result = Position(x: origin.x + cosine * x + sine * z,
                              y: origin.y + position.y,
                              z: origin.z - sine * x + cosine * z)
        return result.isValid ? result : nil
    }
}
