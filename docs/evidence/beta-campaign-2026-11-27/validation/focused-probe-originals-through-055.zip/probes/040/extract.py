from pathlib import Path
import subprocess
repo=Path('/workspace/scratch/4633a14a0d5b/APP1')
root=Path('/workspace/scratch/4633a14a0d5b/campaign/probes/040')
sha='61540d0cf76002b4d2efca966685a1f21541f5a2'
def source(name):
    return subprocess.check_output(['git','show',f'{sha}:Sources/LightingCore/{name}.swift'],cwd=repo,text=True)
def decl(text,token):
    start=text.index(token); opening=text.index('{',start); depth=1; end=opening+1
    while depth:
        if text[end]=='{': depth+=1
        elif text[end]=='}': depth-=1
        end+=1
    return text[start:end]
optics=source('StudioOptics')
parts=[source('Scene'),source('CameraFraming'),
       decl(source('Colorimetry'),'public struct PreviewSettings'),
       decl(source('RoomPlacement'),'public struct ManualRoom'),
       decl(source('SurfacePhotometry'),'public struct UnitDirection'),
       optics[:optics.index('/// Estimates illuminance')],
       'public enum StudioPhotometry {\n'+decl(optics,'public static func frame(')+'\n}',
       source('SceneTransform'),source('ARPlacementLayout')]
(root/'source.swift').write_text('\n'.join(parts))
print(f'Pinned actual-source declaration extraction: {sha}; {sum(p.count(chr(10))+1 for p in parts)} lines')
