import Foundation

// Actual-source filter probe only. These framed chunks are NOT decodable PNGs.
let signature = Data([137, 80, 78, 71, 13, 10, 26, 10])
func be32(_ n: UInt32) -> Data {
    Data([UInt8(truncatingIfNeeded: n >> 24), UInt8(truncatingIfNeeded: n >> 16),
          UInt8(truncatingIfNeeded: n >> 8), UInt8(truncatingIfNeeded: n)])
}
func chunk(_ name: String, _ payload: Data = Data(), crc: UInt32 = 0) -> Data {
    be32(UInt32(payload.count)) + Data(name.utf8) + payload + be32(crc)
}
let header = chunk("IHDR", Data(repeating: 0, count: 13), crc: 0x12345678)
let pixels = chunk("IDAT", Data([1, 2, 3]), crc: 0x87654321)
let end = chunk("IEND", crc: 0xabcdef01)
let framed = signature + header + pixels + end
var checks = 0
func require(_ condition: Bool, _ name: String) {
    if !condition { fatalError("FAIL \(name)") }
    checks += 1
    print("PASS \(name)")
}
func rejected(_ data: Data, _ expected: ReferencePNG.Failure, _ name: String, limit: Int = 32 * 1024 * 1024) {
    do {
        _ = try ReferencePNG.metadataFree(data, maximumBytes: limit)
        fatalError("FAIL accepted \(name)")
    } catch let error as ReferencePNG.Failure {
        require(String(describing: error) == String(describing: expected), name)
    } catch { fatalError("FAIL unexpected \(name): \(error)") }
}

require(try ReferencePNG.metadataFree(framed) == framed, "documented non-decoder boundary: invalid CRC, zero dimensions/bit depth, invalid zlib preserved")
require(try ReferencePNG.metadataFree(framed, maximumBytes: framed.count) == framed, "inclusive byte limit")
require(try ReferencePNG.metadataFree(framed, maximumBytes: Int.max) == framed, "Int.max caller limit remains arithmetic-safe")
rejected(framed, .tooLarge, "one byte above caller ceiling", limit: framed.count - 1)
rejected(Data(), .tooLarge, "negative ceiling rejects before copy", limit: -1)
rejected(Data(), .malformed, "empty input at zero ceiling", limit: 0)
rejected(Data([137, 80, 78]), .malformed, "truncated signature")
rejected(Data(repeating: 0, count: 8), .malformed, "invalid signature")
rejected(signature + header + pixels + Data(end.dropLast()), .malformed, "truncated CRC framing")
rejected(signature + header + pixels + end + Data([0]), .malformed, "trailing byte after IEND")
rejected(signature + pixels + end, .malformed, "IHDR must be first")
rejected(signature + header + header + pixels + end, .malformed, "duplicate IHDR")
rejected(signature + chunk("IHDR", Data(repeating: 0, count: 12)) + pixels + end, .malformed, "wrong IHDR length")
rejected(signature + header + end, .malformed, "missing nonempty IDAT")
rejected(signature + header + chunk("IDAT") + end, .malformed, "only empty IDAT")
rejected(signature + header + pixels, .malformed, "missing IEND")
rejected(signature + header + pixels + chunk("IEND", Data([1])), .malformed, "nonempty IEND")
rejected(signature + header + chunk("ABCD") + pixels + end, .unsupportedCriticalChunk, "unknown critical chunk")
rejected(signature + header + chunk("a1Cd") + pixels + end, .malformed, "nonletter chunk code")
for n: UInt32 in [0x7fffffff, 0x80000000, 0xffffffff] {
    rejected(signature + header + be32(n) + Data("IDAT".utf8) + Data(repeating: 0, count: 4),
             .malformed, "claimed length \(n) rejected before addition/slice")
}
let privatePayload = Data("private source text and location".utf8)
let metadata = ["eXIf", "tEXt", "zTXt", "iTXt", "tIME", "pHYs", "acTL", "fcTL", "fdAT", "vpAg"]
let privateChunks = metadata.reduce(Data()) { $0 + chunk($1, privatePayload) }
require(try ReferencePNG.metadataFree(signature + header + privateChunks + pixels + end) == framed,
        "all nonallowlisted ancillary chunks stripped")
let retainedColor = ["sRGB", "gAMA", "cHRM", "iCCP", "tRNS", "PLTE"].reduce(Data()) {
    $0 + chunk($1, Data([42]), crc: 0x8badf00d)
}
let colorFramed = signature + header + retainedColor + pixels + end
require(try ReferencePNG.metadataFree(colorFramed) == colorFramed, "retained color/structural bytes and original CRCs exact")
let misordered = signature + header + pixels + chunk("PLTE") + chunk("PLTE") + pixels + end
require(try ReferencePNG.metadataFree(misordered) == misordered, "documented non-decoder boundary: PLTE ordering/duplication and separated IDAT preserved")
var manyChunks = signature + header
for _ in 0..<4096 { manyChunks += chunk("vpAg") }
manyChunks += pixels + end
require(try ReferencePNG.metadataFree(manyChunks) == framed, "4096 zero-length ancillary chunks progress and strip")
let sliced = (Data([0, 0, 0]) + framed).dropFirst(3)
require(try ReferencePNG.metadataFree(sliced) == framed, "nonzero-start Data view safely normalized")
print("TOTAL \(checks) checks; filter-only, no ImageIO or permission acceptance claimed")
