import Foundation

public struct Position: Codable, Equatable, Sendable {
    public static let coordinateRange: ClosedRange<Double> = -100...100
    public var x: Double
    public var y: Double
    public var z: Double
    public init(x: Double, y: Double, z: Double) {
        self.x = x; self.y = y; self.z = z
    }
    public var isValid: Bool {
        [x, y, z].allSatisfy { $0.isFinite && Self.coordinateRange.contains($0) }
    }
    public func distance(to other: Position) -> Double {
        let dx = x - other.x, dy = y - other.y, dz = z - other.z
        return (dx * dx + dy * dy + dz * dz).squareRoot()
    }
}

public struct UnitDirection: Equatable, Sendable {
    public let x: Double
    public let y: Double
    public let z: Double

    public init?(x: Double, y: Double, z: Double) {
        guard x.isFinite, y.isFinite, z.isFinite else { return nil }
        let scale = max(abs(x), max(abs(y), abs(z)))
        guard scale > 0 else { return nil }
        let a = x / scale, b = y / scale, c = z / scale
        let length = (a * a + b * b + c * c).squareRoot()
        self.x = a / length; self.y = b / length; self.z = c / length
    }

    fileprivate var vector: SIMD3<Double> { .init(x, y, z) }
}

public enum EmitterKind: String, Codable, CaseIterable, Sendable {
    case point, directional, rectangle

    public var title: String {
        switch self {
        case .point: return "Bare point"
        case .directional: return "Directional"
        case .rectangle: return "Rectangular softbox"
        }
    }
    public var isAimed: Bool { self != .point }
}

public struct LightOptics: Codable, Equatable, Sendable {
    public static let dimensionRange: ClosedRange<Double> = 0.05...4
    public static let rollRange: ClosedRange<Double> = -180...180
    public var kind: EmitterKind
    public var aimTarget: Position?
    public var widthMeters: Double
    public var heightMeters: Double
    /// Rotation about the emitting normal. Nil preserves the legacy world-up orientation.
    public var rollDegrees: Double?

    public init(kind: EmitterKind = .point, aimTarget: Position? = nil,
                widthMeters: Double = 0.6, heightMeters: Double = 0.9,
                rollDegrees: Double? = nil) {
        self.kind = kind; self.aimTarget = aimTarget
        self.widthMeters = widthMeters; self.heightMeters = heightMeters
        self.rollDegrees = rollDegrees
    }

    public var effectiveRollDegrees: Double { rollDegrees ?? 0 }

    public var isValid: Bool {
        (aimTarget?.isValid ?? true) && widthMeters.isFinite && heightMeters.isFinite &&
        Self.dimensionRange.contains(widthMeters) && Self.dimensionRange.contains(heightMeters) &&
        effectiveRollDegrees.isFinite && Self.rollRange.contains(effectiveRollDegrees)
    }
}

public struct EmitterFrame: Equatable, Sendable {
    public let right: UnitDirection
    public let up: UnitDirection
    public let normal: UnitDirection

    public init?(source: Position, target: Position, rollDegrees: Double = 0) {
        guard source.isValid, target.isValid, rollDegrees.isFinite,
              LightOptics.rollRange.contains(rollDegrees),
              let n = UnitDirection(x: target.x - source.x, y: target.y - source.y, z: target.z - source.z) else { return nil }
        let horizontal = hypot(n.x, n.z)
        let r = horizontal > 1e-12
            ? UnitDirection(x: n.z, y: 0, z: -n.x)
            : UnitDirection(x: 1, y: 0, z: 0)
        guard let r, let u = UnitDirection(x: n.y * r.z - n.z * r.y,
                                           y: n.z * r.x - n.x * r.z,
                                           z: n.x * r.y - n.y * r.x) else { return nil }
        // Keep legacy sample coordinates exactly unchanged when no roll is requested.
        if rollDegrees == 0 {
            self.right = r; self.up = u; self.normal = n
            return
        }
        // Exact cardinal coefficients keep mathematical wall/floor/ceiling
        // contact from becoming a trigonometric overhang. Do not snap other
        // angles or physical coordinates: real overhangs must remain outside.
        let c: Double
        let s: Double
        switch rollDegrees {
        case 90: c = 0; s = 1
        case -90: c = 0; s = -1
        case -180, 180: c = -1; s = 0
        default:
            let radians = rollDegrees * .pi / 180
            c = cos(radians); s = sin(radians)
        }
        guard let rolledRight = UnitDirection(x: c * r.x + s * u.x,
                                              y: c * r.y + s * u.y,
                                              z: c * r.z + s * u.z),
              let rolledUp = UnitDirection(x: -s * r.x + c * u.x,
                                           y: -s * r.y + c * u.y,
                                           z: -s * r.z + c * u.z) else { return nil }
        self.right = rolledRight; self.up = rolledUp; self.normal = n
    }
}

// Harness carrier only: CameraFraming reads exactly these three scene fields.
public struct LightingScene { public var subject: Position; public var camera: Position; public var cameraLens: CameraLens? }


import Foundation

/// An ideal rectilinear full-frame camera. Focal length is actual millimeters,
/// not a zoom factor; distortion, focus breathing and depth of field are excluded.
public struct CameraLens: Codable, Equatable, Sendable {
    public static let sensorWidthMillimeters = 36.0
    public static let sensorHeightMillimeters = 24.0
    public static let focalLengthRange: ClosedRange<Double> = 14...200
    public var focalLengthMillimeters: Double

    public init(focalLengthMillimeters: Double = 50) {
        self.focalLengthMillimeters = focalLengthMillimeters
    }

    public var isValid: Bool {
        focalLengthMillimeters.isFinite && Self.focalLengthRange.contains(focalLengthMillimeters)
    }
}

extension LightingScene {
    public var effectiveCameraLens: CameraLens { cameraLens ?? .init() }
}

/// Coordinates on the ideal sensor: +x image right, +y image up, [-1, 1]
/// across the image. Values outside that interval are off-frame, not clamped.
public struct CameraProjection: Equatable, Sendable {
    public let x: Double
    public let y: Double
    public let depthMeters: Double
    public var isInsideFrame: Bool { abs(x) <= 1 && abs(y) <= 1 }
}

/// A camera aimed at the subject center. The world is right-handed; camera
/// forward is local -Z, so camera right is the negative of emitter-frame right.
public struct CameraFraming: Equatable, Sendable {
    public static let minimumDepthMeters = 0.05
    public static let aspectRatio = CameraLens.sensorWidthMillimeters / CameraLens.sensorHeightMillimeters
    public let position: Position
    public let target: Position
    public let lens: CameraLens
    public let right: UnitDirection
    public let up: UnitDirection
    public let forward: UnitDirection
    public let subjectDistanceMeters: Double

    public init?(scene: LightingScene) {
        let lens = scene.effectiveCameraLens
        let distance = scene.camera.distance(to: scene.subject)
        guard lens.isValid, distance >= Self.minimumDepthMeters,
              let frame = EmitterFrame(source: scene.camera, target: scene.subject),
              let right = UnitDirection(x: -frame.right.x, y: -frame.right.y, z: -frame.right.z) else { return nil }
        self.position = scene.camera; self.target = scene.subject; self.lens = lens
        self.right = right; self.up = frame.up; self.forward = frame.normal
        self.subjectDistanceMeters = distance
    }

    public var horizontalFieldOfViewDegrees: Double {
        2 * atan(CameraLens.sensorWidthMillimeters / (2 * lens.focalLengthMillimeters)) * 180 / .pi
    }
    public var verticalFieldOfViewDegrees: Double {
        2 * atan(CameraLens.sensorHeightMillimeters / (2 * lens.focalLengthMillimeters)) * 180 / .pi
    }
    /// Width and height of the subject plane perpendicular to the optical axis.
    public var subjectPlaneWidthMeters: Double {
        subjectDistanceMeters * CameraLens.sensorWidthMillimeters / lens.focalLengthMillimeters
    }
    public var subjectPlaneHeightMeters: Double {
        subjectDistanceMeters * CameraLens.sensorHeightMillimeters / lens.focalLengthMillimeters
    }

    public func project(_ world: Position) -> CameraProjection? {
        guard world.isValid else { return nil }
        let dx = world.x - position.x, dy = world.y - position.y, dz = world.z - position.z
        func dot(_ direction: UnitDirection) -> Double { dx * direction.x + dy * direction.y + dz * direction.z }
        let depth = dot(forward)
        guard depth >= Self.minimumDepthMeters else { return nil }
        return CameraProjection(x: 2 * lens.focalLengthMillimeters * dot(right) / (CameraLens.sensorWidthMillimeters * depth),
                                y: 2 * lens.focalLengthMillimeters * dot(up) / (CameraLens.sensorHeightMillimeters * depth),
                                depthMeters: depth)
    }
}



func vec(_ d: UnitDirection) -> SIMD3<Double> { .init(d.x,d.y,d.z) }
func vec(_ p: Position) -> SIMD3<Double> { .init(p.x,p.y,p.z) }
func dot(_ a: SIMD3<Double>, _ b: SIMD3<Double>) -> Double { a.x*b.x + a.y*b.y + a.z*b.z }
func point(_ p: SIMD3<Double>) -> Position { .init(x:p.x,y:p.y,z:p.z) }
let poses: [(Position,Position)] = [
    (.init(x:0,y:0,z:3),.init(x:0,y:0,z:0)),
    (.init(x:3,y:0,z:0),.init(x:0,y:0,z:0)),
    (.init(x:0,y:3,z:0),.init(x:0,y:0,z:0)),
    (.init(x:0,y:-3,z:0),.init(x:0,y:0,z:0)),
    (.init(x:1e-13,y:3,z:0),.init(x:0,y:0,z:0)),
    (.init(x:-3e-12,y:3,z:0),.init(x:0,y:0,z:0)),
    (.init(x:3.01e-12,y:3,z:1e-14),.init(x:0,y:0,z:0)),
    (.init(x:98,y:97,z:96),.init(x:95,y:96,z:94)),
    (.init(x:-100,y:-100,z:-100),.init(x:100,y:100,z:100)),
    (.init(x:0,y:0,z:0),.init(x:0,y:0,z:-0.05))]
var checked = 0, skipped = 0, maxResidual = 0.0, maxOrthogonality = 0.0
for (origin,target) in poses {
    for focal in [14.0,24,50,85,200] {
        let c = CameraFraming(scene:.init(subject:target,camera:origin,cameraLens:.init(focalLengthMillimeters:focal)))!
        let f=vec(c.forward), r=vec(c.right), u=vec(c.up), o=vec(origin)
        maxOrthogonality=max(maxOrthogonality,max(abs(dot(f,r)),max(abs(dot(f,u)),abs(dot(r,u)))))
        precondition(c.subjectPlaneWidthMeters.isFinite && c.subjectPlaneHeightMeters.isFinite)
        for x in [-1.0,-0.5,0,0.5,1] { for y in [-1.0,-0.5,0,0.5,1] { for depth in [0.051,0.5,3.0] {
            let raw=f+r*(x*36/(2*focal))+u*(y*24/(2*focal))
            let ray=raw/sqrt(dot(raw,raw))
            let p=point(o+ray*(depth/dot(ray,f)))
            if !p.isValid { skipped += 1; continue }
            let projection=c.project(p)!
            precondition(projection.x.isFinite && projection.y.isFinite && projection.depthMeters.isFinite)
            let error=max(abs(projection.x-x),abs(projection.y-y))
            maxResidual=max(maxResidual,error)
            precondition(error < 1e-9)
            checked += 1
        } } }
        if let back = c.project(point(o-f*0.1)) { fatalError("behind accepted \(back)") }
    }
}
let origin=Position(x:0,y:0,z:0)
for z in [0.0,0.01,0.049999999999] { precondition(CameraFraming(scene:.init(subject:origin,camera:.init(x:0,y:0,z:z),cameraLens:nil)) == nil) }
for focal in [13.99,200.01,Double.nan,Double.infinity] { precondition(CameraFraming(scene:.init(subject:origin,camera:.init(x:0,y:0,z:3),cameraLens:.init(focalLengthMillimeters:focal))) == nil) }
let near=CameraFraming(scene:.init(subject:.init(x:0,y:0,z:-0.05),camera:origin,cameraLens:nil))!
precondition(near.project(.init(x:0,y:0,z:-0.05)) != nil)
precondition(near.project(.init(x:Double.nan,y:0,z:-1)) == nil)
print("inverse_checked=\(checked) outside_position_domain_skipped=\(skipped) max_sensor_residual=\(maxResidual) max_basis_dot=\(maxOrthogonality)")
var nearCases=0, rejectedCenter=0
var witness=""
for i in 1...2000 {
    let raw=SIMD3<Double>(sin(Double(i)*0.73),cos(Double(i)*1.13),sin(Double(i)*1.91))
    let p=point(raw*(0.05/sqrt(dot(raw,raw))))
    guard let c=CameraFraming(scene:.init(subject:origin,camera:p,cameraLens:nil)) else { continue }
    nearCases += 1
    if c.project(origin) == nil {
        rejectedCenter += 1
        if witness.isEmpty { witness="camera=\(p) distance=\(c.subjectDistanceMeters) depth=\(dot(-vec(p),vec(c.forward)))" }
    }
}
print("minimum_depth_boundary_accepted_cameras=\(nearCases) center_rejected=\(rejectedCenter) first_witness=\(witness)")
