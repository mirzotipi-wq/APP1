set -euo pipefail
{
  sw_vers
  uname -a
  swift --version
  xcodebuild -version
  xcodebuild -showsdks
  git rev-parse HEAD
} | tee macos-environment.log
[ "$(uname -m)" = "$EXPECTED_RUNNER_ARCH" ] || { echo "::error::Expected the configured $EXPECTED_RUNNER_ARCH runner"; exit 1; }
[ "$(xcrun --sdk iphonesimulator --show-sdk-version)" = 26.5 ] || { echo "::error::Expected the iOS 26.5 simulator SDK"; exit 1; }
