set -euo pipefail
command -v xcodegen || brew install xcodegen
xcodegen --version | tee xcodegen-version.log
xcodegen generate
