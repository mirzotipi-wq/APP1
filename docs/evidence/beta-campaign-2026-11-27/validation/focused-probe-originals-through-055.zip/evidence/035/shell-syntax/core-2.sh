set -euo pipefail
python3 scripts/agent_cycle.py check
python3 scripts/agent_cycle.py next
python3 -m unittest discover -s scripts/tests -p 'test_*.py'
python3 scripts/native_test_shards.py check
python3 scripts/verify_app_icon.py | tee icon-source.log
python3 scripts/verify_privacy_manifest.py | tee privacy-source.log
# Syntax only: Linux cannot type-check Apple SDK APIs.
swiftc -frontend -parse App/*.swift UITests/*.swift NativeTests/*.swift 2>&1 | tee native-syntax.log
