mkdir -p artifacts
python3 - <<'PY' > artifacts/ui-host-before-tests.log 2>&1
import datetime, json, os, subprocess, time
print("phase=before-ui-tests", flush=True)
print("utc=" + datetime.datetime.now(datetime.timezone.utc).isoformat(), flush=True)
commands = [
    ("virtual_memory", ["/usr/bin/vm_stat"]),
    ("swap_and_memory", ["/usr/sbin/sysctl", "vm.swapusage", "hw.memsize"]),
    ("process_cpu_rss", ["/bin/ps", "-A", "-r", "-o", "pid=,ppid=,pcpu=,rss=,comm="]),
    ("workspace_and_temp_disk", ["/bin/df", "-k", os.environ["GITHUB_WORKSPACE"], os.environ["RUNNER_TEMP"]]),
]
for label, arguments in commands:
    print("\ncommand=" + label + " argv=" + json.dumps(arguments), flush=True)
    started = time.monotonic()
    try:
        result = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, errors="replace", timeout=5, check=False)
        output = result.stdout
        status = "success" if result.returncode == 0 else "failed"
        return_code = result.returncode
    except subprocess.TimeoutExpired as error:
        output = error.stdout or ""
        if isinstance(output, bytes):
            output = output.decode("utf-8", errors="replace")
        status, return_code = "timed_out", None
    except OSError as error:
        output = str(error)
        status, return_code = "unavailable", None
    print(output[:65536], flush=True)
    print(json.dumps({"status": status, "return_code": return_code,
                      "elapsed_seconds": round(time.monotonic() - started, 3),
                      "timeout_seconds": 5, "output_truncated": len(output) > 65536}), flush=True)
PY
