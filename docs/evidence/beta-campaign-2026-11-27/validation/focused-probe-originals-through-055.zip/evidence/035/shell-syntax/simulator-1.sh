set -euo pipefail
{
  sw_vers
  uname -a
  swift --version
  xcodebuild -version
  xcodebuild -showsdks
  git rev-parse HEAD
} | tee macos-environment.log
[ "$(uname -m)" = x86_64 ] || { echo "::error::Expected the standard Intel runner"; exit 1; }
[ "$(xcrun --sdk iphonesimulator --show-sdk-version)" = 26.5 ] || { echo "::error::Expected the iOS 26.5 simulator SDK"; exit 1; }
swift test --jobs 2 2>&1 | tee macos-core-tests.log
