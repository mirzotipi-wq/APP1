set -euo pipefail
mkdir -p artifacts
# Preserve any original bundle before checking finalization. A timed-out
# command must retain its raw evidence without passing this required gate.
if [ -d NativeTests.xcresult ]; then
  ditto -c -k --keepParent NativeTests.xcresult artifacts/native-results.zip || {
    native_archive_exit_code=$?
    printf 'archive_failed=true\n' >> "$GITHUB_OUTPUT"
    echo "::error::XCTest archive failed; preserve the original bundle separately"
    exit "$native_archive_exit_code"
  }
fi
if [ ! -f NativeTests.xcresult/Info.plist ]; then
  echo "::error::No finalized XCTest result bundle; see native-tests.log and any preserved raw bundle"
  exit 1
fi
mkdir -p artifacts/native-attachments
xcrun xcresulttool export attachments --path NativeTests.xcresult --output-path artifacts/native-attachments
