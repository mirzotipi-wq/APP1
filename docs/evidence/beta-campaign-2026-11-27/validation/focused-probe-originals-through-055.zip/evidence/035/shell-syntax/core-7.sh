set -euo pipefail
python3 scripts/probe_library_recovery_failure.py --timeout-seconds 300 \
  --output "$RUNNER_TEMP/library-recovery-linux" 2>&1 | tee "$RUNNER_TEMP/library-recovery-linux.log"
