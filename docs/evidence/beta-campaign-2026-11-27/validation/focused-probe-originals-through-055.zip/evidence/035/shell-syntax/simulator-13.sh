python3 scripts/native_test_shards.py verify-log unit native-tests.log \
  --report native-method-accounting.json
