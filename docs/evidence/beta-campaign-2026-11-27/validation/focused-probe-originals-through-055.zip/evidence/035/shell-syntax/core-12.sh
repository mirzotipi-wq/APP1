set -euo pipefail
swiftc -O Sources/LightingCore/*.swift scripts/precision-boundary.swift -o "$RUNNER_TEMP/prepare-precision-boundary"
"$RUNNER_TEMP/prepare-precision-boundary" "$RUNNER_TEMP/precision-boundary"
"$RUNNER_TEMP/verify-kernel-host" --maximum-channel-error 1 \
  "$RUNNER_TEMP"/precision-boundary/area-camera-*.bin \
  "$RUNNER_TEMP"/precision-boundary/world-translation-*.bin | tee study-precision.log
