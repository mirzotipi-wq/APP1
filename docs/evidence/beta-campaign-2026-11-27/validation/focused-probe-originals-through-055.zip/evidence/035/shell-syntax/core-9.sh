set -euo pipefail
swiftc -O Sources/LightingCore/*.swift scripts/render-study-fixtures.swift -o "$RUNNER_TEMP/render-study"
"$RUNNER_TEMP/render-study" study-artifacts | tee study-render.log
sha256sum study-artifacts/*.ppm | tee study-image-sha256.txt
