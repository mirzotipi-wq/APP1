set -euo pipefail
swiftc -O Sources/LightingCore/*.swift scripts/benchmark-study.swift -o "$RUNNER_TEMP/benchmark-study"
"$RUNNER_TEMP/benchmark-study" --samples 7 --revision "$GITHUB_SHA" > study-benchmark.json
python3 - <<'PY'
import json, math
report = json.load(open("study-benchmark.json"))
assert report["optimizedBuild"] is True
assert report["measuredSamplesPerWorkload"] >= 7
assert len(report["frames"]) == 8
assert len(report["cancellation"]) == 12
assert len(report["visibility"]) == 4
assert all(f["unsupportedPixels"] == 0 for f in report["frames"])
assert all(c["cancelled"] is True for c in report["cancellation"])
for workload in report["frames"] + report["visibility"]:
    samples = workload["timing"]["samplesMilliseconds"]
    assert len(samples) >= 7 and all(math.isfinite(x) and x >= 0 for x in samples)
print("Eight deterministic frames, twelve observed cancellations and four visibility workloads passed.")
print("Host timings are diagnostics; no physical-device frame-rate, memory or thermal claim.")
print("KEYFILL_BENCHMARK " + json.dumps(report, separators=(",", ":")), flush=True)
PY
