set -euo pipefail
echo "Simulator warm-up outcome: $SIMULATOR_WARMUP_OUTCOME (diagnostic only)"
selectors=$(python3 scripts/native_test_shards.py "$TEST_SHARD")
tests=()
while IFS= read -r selector; do
  tests+=("$selector")
done <<< "$selectors"
[ "${#tests[@]}" -gt 0 ]
if [ "$TEST_SHARD" = "studio-export" ] || [ "$TEST_SHARD" = "studio-optics" ]; then
  printf 'STUDIO_TRACE_START=%s\n' "$(date -u '+%Y-%m-%d %H:%M:%S%z')" >> "$GITHUB_ENV"
  record_studio_trace_end() {
    studio_test_exit_code=$?
    set +e
    # Include the final fractional second without changing the test exit status.
    printf 'STUDIO_TRACE_END=%s\nSTUDIO_TRACE_TEST_EXIT_CODE=%s\n' \
      "$(date -u -v+1S '+%Y-%m-%d %H:%M:%S%z')" "$studio_test_exit_code" >> "$GITHUB_ENV"
    exit "$studio_test_exit_code"
  }
  trap record_studio_trace_end EXIT
fi
xcodebuild -project KeyAndFill.xcodeproj -scheme KeyAndFill -configuration Debug \
  -destination "id=$SIMULATOR_ID" -derivedDataPath "$RUNNER_TEMP/keyfill-build" \
  -parallel-testing-enabled NO -resultBundlePath NativeTests.xcresult \
  CODE_SIGNING_ALLOWED=NO "${tests[@]}" test-without-building 2>&1 | tee native-tests.log
