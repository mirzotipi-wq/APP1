set -euo pipefail
python3 scripts/run_atomic_library_write_probe.py --with-commit-interruption \
  --output "$RUNNER_TEMP/atomic-library-write-linux" 2>&1 | tee "$RUNNER_TEMP/atomic-library-write-linux.log"
