set -euo pipefail
bash scripts/ensure-metal-toolchain.sh 2>&1 | tee metal-toolchain.log
