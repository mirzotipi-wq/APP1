set -euo pipefail
python3 scripts/run_atomic_library_write_probe.py \
  --swiftc "$(xcrun --find swiftc)" \
  --output "$RUNNER_TEMP/atomic-library-write-macos" 2>&1 | tee "$RUNNER_TEMP/atomic-library-write-macos.log"
