set -euo pipefail
mkdir -p artifacts
# The EXIT trap observes the shell; GitHub records the test-step outcome.
printf 'simulator=%s\nstart=%s\nend=%s\ngithub_test_step_outcome=%s\nobserved_shell_exit_code=%s\n' \
  "${SIMULATOR_ID:-}" "${STUDIO_TRACE_START:-}" "${STUDIO_TRACE_END:-}" \
  "${UI_TEST_STEP_OUTCOME:-unavailable}" \
  "${STUDIO_TRACE_TEST_EXIT_CODE:-unavailable}" > artifacts/studio-slider-trace-status.txt
if [ -z "${SIMULATOR_ID:-}" ] || [ -z "${STUDIO_TRACE_START:-}" ] || [ -z "${STUDIO_TRACE_END:-}" ]; then
  printf 'collection=unavailable\n' >> artifacts/studio-slider-trace-status.txt
  echo "::warning::Studio slider log collection needs a simulator and both test timestamps."
  exit 1
fi
if xcrun simctl spawn "$SIMULATOR_ID" log show \
  --start "$STUDIO_TRACE_START" --end "$STUDIO_TRACE_END" \
  --predicate 'process = "KeyAndFill" AND subsystem = "com.example.keyandfill" AND category = "StudioSliderTrace" AND message CONTAINS "StudioSliderTrace "' \
  > artifacts/studio-slider-trace.log 2> artifacts/studio-slider-trace-stderr.log; then
  printf 'collection=completed\ncollection_exit_code=0\n' >> artifacts/studio-slider-trace-status.txt
else
  studio_collection_exit_code=$?
  printf 'collection=failed\ncollection_exit_code=%s\n' "$studio_collection_exit_code" >> artifacts/studio-slider-trace-status.txt
  echo "::warning::Studio slider log collection failed; the test outcome is unchanged."
  cat artifacts/studio-slider-trace-stderr.log >&2
  exit "$studio_collection_exit_code"
fi
