set -euo pipefail
swift test --configuration release --jobs 2 2>&1 | tee core-release-tests.log
