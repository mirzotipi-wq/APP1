set -euo pipefail
xcodebuild -project KeyAndFill.xcodeproj -scheme KeyAndFill -configuration Debug \
  -destination "id=$SIMULATOR_ID" -derivedDataPath "$RUNNER_TEMP/keyfill-build" \
  CODE_SIGNING_ALLOWED=NO build-for-testing 2>&1 | tee native-ui-build.log
