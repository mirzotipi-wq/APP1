xcrun simctl list devices available -j > simulators.json
python3 - <<'PY'
import json, os
data = json.load(open("simulators.json"))
runtime = "com.apple.CoreSimulator.SimRuntime.iOS-26-5"
devices = data["devices"].get(runtime, [])
device = next((d for d in devices if d.get("isAvailable") and d["name"] == "iPhone 17 Pro"), None)
if device is None:
    raise SystemExit("Required iPhone 17 Pro / iOS 26.5 simulator is unavailable")
print({"runtime": runtime, "device": device})
with open(os.environ["GITHUB_ENV"], "a") as f:
    f.write("SIMULATOR_ID=" + device["udid"] + "\n")
PY
