set -euo pipefail
selectors=$(python3 scripts/native_test_shards.py unit)
tests=()
while IFS= read -r selector; do
  tests+=("$selector")
done <<< "$selectors"
[ "${#tests[@]}" -gt 0 ]
xcodebuild -project KeyAndFill.xcodeproj -scheme KeyAndFill -configuration Debug \
  -destination "id=$SIMULATOR_ID" -derivedDataPath "$RUNNER_TEMP/keyfill-build" \
  CODE_SIGNING_ALLOWED=NO "${tests[@]}" build-for-testing 2>&1 | tee build.log
python3 scripts/verify_app_icon.py --bundle "$RUNNER_TEMP/keyfill-build/Build/Products/Debug-iphonesimulator/KeyAndFill.app" | tee icon-debug.log
python3 scripts/verify_privacy_manifest.py --bundle "$RUNNER_TEMP/keyfill-build/Build/Products/Debug-iphonesimulator/KeyAndFill.app" | tee privacy-debug.log
mkdir -p artifacts
ditto -c -k --keepParent "$RUNNER_TEMP/keyfill-build/Build/Products/Debug-iphonesimulator/KeyAndFill.app" artifacts/KeyAndFill-simulator.zip
