set -euo pipefail
swift test --jobs 2 2>&1 | tee core-tests.log
