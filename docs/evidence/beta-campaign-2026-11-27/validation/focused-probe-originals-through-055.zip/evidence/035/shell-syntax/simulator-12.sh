set -euo pipefail
native_phase=selection
record_native_exit() {
  native_exit_code=$?
  set +e
  printf 'Native shell exit: utc=%s phase=%s status=%s\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$native_phase" "$native_exit_code"
  exit "$native_exit_code"
}
trap record_native_exit EXIT
echo "Simulator warm-up outcome: $SIMULATOR_WARMUP_OUTCOME (diagnostic only)"
selectors=$(python3 scripts/native_test_shards.py "$TEST_SHARD")
tests=()
while IFS= read -r selector; do
  tests+=("$selector")
done <<< "$selectors"
[ "${#tests[@]}" -gt 0 ]
native_phase=xcodebuild
printf 'Native command start: utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
xcodebuild -project KeyAndFill.xcodeproj -scheme KeyAndFill -configuration Debug \
  -destination "id=$SIMULATOR_ID" -derivedDataPath "$RUNNER_TEMP/keyfill-build" \
  -parallel-testing-enabled NO -resultBundlePath NativeTests.xcresult \
  CODE_SIGNING_ALLOWED=NO "${tests[@]}" test-without-building 2>&1 | tee native-tests.log
native_phase=metal-checks
printf 'Native command exit: utc=%s status=0\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
python3 - <<'PY'
from pathlib import Path
import re
log = Path("native-tests.log").read_text(encoding="utf-8", errors="replace")
required_metal = {
    "testMetalMatchesCPUOnAvailableDevice",
    "testNearFieldRoutingDoesNotPermanentlyDowngradeValidatedMetal",
    "testCancelledInitialParityValidationCanRetryMetalOnSameEngine",
}
skipped = re.findall(r"Test Case '-\[([^\]]+)\]' skipped", log)
if skipped:
    raise SystemExit(f"Incomplete native execution: skipped={skipped}")
for method in sorted(required_metal):
    pattern = r"Test Case '-\[KeyAndFillTests\.StudyRendererTests " + re.escape(method) + r"\]' (passed|failed|skipped)\b"
    outcomes = re.findall(pattern, log)
    if outcomes != ["passed"]:
        raise SystemExit(f"Required Metal test {method}: expected one pass; observed {outcomes}")
print("Required Metal methods executed and passed; no native methods skipped.")
PY
native_phase=complete
