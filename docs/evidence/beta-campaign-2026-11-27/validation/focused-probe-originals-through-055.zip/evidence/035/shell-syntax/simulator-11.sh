set -euo pipefail
python3 scripts/boot_simulator.py --udid "$SIMULATOR_ID" \
  --runtime com.apple.CoreSimulator.SimRuntime.iOS-26-5 \
  --device-type com.apple.CoreSimulator.SimDeviceType.iPhone-17-Pro \
  --output simulator-startup 2>&1 | tee simulator-boot.log
