set -euo pipefail
xcodebuild -project KeyAndFill.xcodeproj -scheme KeyAndFill -configuration Release \
  -destination "id=$SIMULATOR_ID" -derivedDataPath "$RUNNER_TEMP/keyfill-build" \
  CODE_SIGNING_ALLOWED=NO build 2>&1 | tee release-build.log
python3 scripts/verify_app_icon.py --bundle "$RUNNER_TEMP/keyfill-build/Build/Products/Release-iphonesimulator/KeyAndFill.app" | tee icon-release.log
python3 scripts/verify_privacy_manifest.py --bundle "$RUNNER_TEMP/keyfill-build/Build/Products/Release-iphonesimulator/KeyAndFill.app" | tee privacy-release.log
mkdir -p artifacts
ditto -c -k --keepParent "$RUNNER_TEMP/keyfill-build/Build/Products/Release-iphonesimulator/KeyAndFill.app" artifacts/KeyAndFill-simulator-release.zip
