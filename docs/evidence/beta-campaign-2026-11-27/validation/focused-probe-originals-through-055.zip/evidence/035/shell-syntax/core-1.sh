set -euo pipefail
{
  uname -a
  cat /etc/os-release
  swift --version
  python3 --version
  git rev-parse HEAD
} | tee core-environment.log
