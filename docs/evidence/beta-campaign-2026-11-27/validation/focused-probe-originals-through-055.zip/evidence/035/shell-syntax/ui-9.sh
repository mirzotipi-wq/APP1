python3 scripts/native_test_shards.py verify-log "$TEST_SHARD" native-tests.log \
  --report native-method-accounting.json
