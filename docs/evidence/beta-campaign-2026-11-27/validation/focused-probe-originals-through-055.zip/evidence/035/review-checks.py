"""Worker035: read-only receipt review, CI metadata validation, no compilation."""
import copy
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

import yaml

ROOT = Path('/workspace/scratch/4633a14a0d5b')
REVIEWED = ROOT / 'worktrees/030'
OWNED = ROOT / 'worktrees/035'
ORIGINAL = ROOT / 'campaign/evidence/030'
OUTPUT = ROOT / 'campaign/evidence/035'
sys.path.insert(0, str(REVIEWED / 'scripts'))
import probe_library_recovery_failure as recovery
import probe_library_commit_interruption as fault


def read_json(path):
    return json.loads(path.read_text())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    result = {'reviewedCommit': '92649ef4d8161214d11fabfd8104db354383060e',
              'workflowBase': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=OWNED, text=True).strip(),
              'status': 'failed', 'checks': {}}
    checks = result['checks']
    initial = ORIGINAL / 'initial'
    manifest = read_json(initial / 'compile-manifest.json')
    receipt = read_json(initial / 'result.json')
    assert receipt['status'] == 'passed'
    assert sha256(initial / 'compile-manifest.json') == receipt['compileManifestSHA256']
    assert manifest['sourceSHA256'] == recovery.source_hashes(REVIEWED)
    assert manifest['diagnosticSHA256'] == recovery.diagnostic_hashes(REVIEWED)
    assert manifest['sourceSHA256'] == manifest['sourceSHA256AfterCompilation']
    assert manifest['diagnosticSHA256'] == manifest['diagnosticSHA256AfterCompilation']
    for name, digest in manifest['binarySHA256'].items():
        assert sha256(initial / 'build' / name) == digest
    for key in ('sourcesUnchangedDuringProbe', 'diagnosticsUnchangedDuringProbe',
                'binariesUnchangedDuringProbe', 'ownedChildrenReaped',
                'parentResourceSignalAndGroupUnchanged'):
        assert receipt[key] is True
    checks['originalManifestAndAllRetainedBinarySourceHashesMatch'] = True
    result['originalReceiptBaseRevision'] = receipt['baseRevision']
    result['originalCompileManifestSHA256'] = sha256(initial / 'compile-manifest.json')
    result['originalModes'] = {}
    for mode in recovery.MODES:
        directory = initial / mode
        scenario = read_json(directory / 'scenario-result.json')
        assert scenario['status'] == 'passed' and all(scenario['checks'].values())
        injection = scenario['injection']
        events = [json.loads(line) for line in (directory / 'hook-witness.jsonl').read_text().splitlines()]
        assert events == injection['events'] and events
        for event in events:
            fault.validate_event(event, mode, directory / 'library/projects.json',
                                 SimpleNamespace(pid=injection['processGroupID']))
        assert scenario['beforeSources'] == scenario['afterFailureSources']
        originals = recovery.original_bytes(directory)
        for name in recovery.SOURCE_FILES:
            assert (directory / ('before-' + name)).read_bytes() == originals[name]
            assert (directory / ('after-failure-' + name)).read_bytes() == originals[name]
        if mode == 'before-rename':
            assert (directory / 'staged-at-hook.json').read_bytes() == (directory / 'candidate.json').read_bytes()
            assert injection['atHookSources'] == scenario['beforeSources']
            assert injection['observedStop']['signal'] == signal.SIGSTOP
            assert injection['returnCode'] == -signal.SIGKILL
        else:
            assert injection['observed']['errorCase'] == 'recoveryWriteFailed'
            assert injection['observed']['status'] == 'recovery_write_failed'
            assert injection['returnCode'] == 0
            assert all(event['returnedErrno'] == 5 and event['realRenameCalled'] is False for event in events)
        assert (directory / 'library/projects.json').read_bytes() == (directory / 'candidate.json').read_bytes()
        assert (directory / 'library/portrait.json').read_bytes() == originals['portrait.json']
        for store, count in [('library', 2), ('control', 1)]:
            archives = list((directory / store / 'Recovery').iterdir())
            assert len(archives) == count
            for archive in archives:
                assert sorted(path.name for path in archive.iterdir()) == sorted(recovery.SOURCE_FILES)
                for name in recovery.SOURCE_FILES:
                    assert (archive / name).read_bytes() == originals[name]
        pids = [phase['processGroupID'] for phase in scenario['phases']] + [injection['processGroupID']]
        assert len(pids) == len(set(pids))
        assert all(phase['returnCode'] == 0 and phase['observed']['processID'] == phase['processGroupID']
                   for phase in scenario['phases'])
        result['originalModes'][mode] = {'checks': len(scenario['checks']), 'distinctChildPIDs': pids,
                                         'hookCount': len(events)}
    checks['originalWitnessesSourcesArchivesRetriesAndSeparateReopenProcessesVerified'] = True
    negative = read_json(ORIGINAL / 'missing-hook/negative-control-result.json')
    assert negative['status'] == 'passed' and all(negative['checks'].values())
    assert negative['injection']['status'] == 'failed' and negative['injection']['hookWitnessed'] is False
    assert negative['injection']['observed']['status'] == 'unexpected_recovery_success'
    assert (ORIGINAL / 'missing-hook/hook-witness.jsonl').read_bytes() == b''
    assert (ORIGINAL / 'missing-hook/library/projects.json').read_bytes() == (ORIGINAL / 'missing-hook/candidate.json').read_bytes()
    checks['originalMissingHookCannotPassDespiteSuccessfulRecovery'] = True

    workflow = OWNED / '.github/workflows/ios-prototype.yml'
    baseline = subprocess.check_output(['git', 'show', 'ab6db65:.github/workflows/ios-prototype.yml'], cwd=OWNED, text=True)
    original_yaml = yaml.load(baseline, Loader=yaml.BaseLoader)
    updated_yaml = yaml.load(workflow.read_text(), Loader=yaml.BaseLoader)
    steps = updated_yaml['jobs']['core']['steps']
    probe = next(step for step in steps if step.get('name') == 'Verify recovery commit failure and retry on Linux')
    upload = next(step for step in steps if step.get('name') == 'Upload Linux library recovery evidence')
    assert probe['timeout-minutes'] == '6' and 'if' not in probe and 'continue-on-error' not in probe
    assert 'set -euo pipefail' in probe['run'] and '--timeout-seconds 300' in probe['run']
    assert 'probe_library_recovery_failure.py' in probe['run']
    assert upload['if'] == 'always()' and upload['uses'] == 'actions/upload-artifact@v4'
    assert upload['with']['path'].splitlines() == ['${{ runner.temp }}/library-recovery-linux.log',
                                                  '${{ runner.temp }}/library-recovery-linux/',
                                                  '!${{ runner.temp }}/library-recovery-linux/build/**']
    unchanged = copy.deepcopy(updated_yaml)
    unchanged['jobs']['core']['steps'] = [step for step in steps if step not in (probe, upload)]
    assert unchanged == original_yaml
    shell_directory = OUTPUT / 'shell-syntax'
    shell_directory.mkdir(exist_ok=False)
    shell_count = 0
    for job_name, job in updated_yaml['jobs'].items():
        for index, step in enumerate(job.get('steps', [])):
            if 'run' in step:
                path = shell_directory / f'{job_name}-{index}.sh'
                path.write_text(step['run'])
                subprocess.run(['bash', '-n', str(path)], check=True, timeout=10)
                shell_count += 1
    checks['yamlLoadsAndOnlyTwoRequiredCoreStepsAdded'] = True
    checks['allOtherJobsAndNativeTimeoutsUnchanged'] = True
    checks['receiptRetentionExcludesOnlyReproducibleBuildOutputs'] = True
    result['bashSyntaxBlocksPassed'] = shell_count
    result['workflowSHA256'] = sha256(workflow)

    # Replay the reviewed code against original hash-verified binaries, without
    # compiling or modifying worker030's original receipts or repository.
    replay = OUTPUT / 'replay'
    replay.mkdir(exist_ok=False)
    environment, removed = fault.clean_environment()
    helper = initial / 'build/library-recovery-probe'
    interposer = initial / 'build/probe-library-commit-interposer.so'
    before = (resource.getrlimit(resource.RLIMIT_FSIZE), signal.getsignal(signal.SIGXFSZ), os.getpgrp())
    deadline = time.monotonic() + 60
    result['replayedModes'] = []
    try:
        for mode in recovery.MODES:
            observed = recovery.run_scenario(helper, interposer, replay, mode, environment, deadline)
            assert observed['status'] == 'passed' and all(observed['checks'].values())
            result['replayedModes'].append({'mode': mode, 'status': observed['status'], 'checks': len(observed['checks'])})
    finally:
        for child in list(fault.ACTIVE_CHILDREN.values()):
            fault.kill_owned_group(child)
    assert not fault.ACTIVE_CHILDREN
    assert before == (resource.getrlimit(resource.RLIMIT_FSIZE), signal.getsignal(signal.SIGXFSZ), os.getpgrp())
    checks['freshWitnessedReplayPassedWithoutRecompilation'] = True
    checks['replayChildrenReapedAndParentStateUnchanged'] = True
    result['replayRemovedInheritedEnvironmentKeys'] = removed
    result['status'] = 'passed'
    (OUTPUT / 'review-validation.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
