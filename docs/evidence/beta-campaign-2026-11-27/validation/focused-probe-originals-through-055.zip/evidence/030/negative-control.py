"""Exercise the real recovery helper without a rename hook; success must fail the diagnostic."""
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time

repository = Path('/workspace/scratch/4633a14a0d5b/worktrees/030')
sys.path.insert(0, str(repository / 'scripts'))
import probe_library_recovery_failure as probe
import probe_library_commit_interruption as fault

base = Path('/workspace/scratch/4633a14a0d5b/campaign/evidence/030')
output = base / 'missing-hook'
output.mkdir(exist_ok=False)
(output / 'temporary').mkdir()
helper = base / 'initial/build/library-recovery-probe'
manifest = json.loads((base / 'initial/compile-manifest.json').read_text())
assert manifest['binarySHA256'][helper.name] == fault.sha256(helper)
assert manifest['sourceSHA256'] == probe.source_hashes(repository)
assert manifest['diagnosticSHA256'] == probe.diagnostic_hashes(repository)
unrelated_library = Path('/lib/x86_64-linux-gnu/libm.so.6').resolve(strict=True)
environment, removed = fault.clean_environment()
environment['TMPDIR'] = str(output / 'temporary')
before = (resource.getrlimit(resource.RLIMIT_FSIZE), signal.getsignal(signal.SIGXFSZ), os.getpgrp())
deadline = time.monotonic() + 60
phases = []
try:
    for phase, status in [('setup', 'setup_complete'), ('control', 'control_recovered')]:
        observation = fault.run_phase(helper, output, phase, environment, deadline)
        phases.append(observation)
        fault.require_phase(observation, status)
    observation = probe.run_injection(helper, unrelated_library, output, 'rename-eio', environment, deadline)
    checks = {
        'missingHookRejected': observation['status'] == 'failed' and observation['hookWitnessed'] is False,
        'rawWitnessEmpty': (output / 'hook-witness.jsonl').read_bytes() == b'',
        'actualUnrestrictedRecoverySucceeded': observation.get('observed', {}).get('status') == 'unexpected_recovery_success',
        'exactReplacementSaved': fault.bounded_read(output / 'library/projects.json') == fault.bounded_read(output / 'candidate.json'),
        'ownedChildReaped': observation.get('ownedGroupCleanupComplete') is True and not fault.ACTIVE_CHILDREN,
        'parentLimitsSignalsGroupUnchanged': before == (resource.getrlimit(resource.RLIMIT_FSIZE), signal.getsignal(signal.SIGXFSZ), os.getpgrp()),
    }
    report = {'status': 'passed' if all(checks.values()) else 'failed', 'checks': checks,
              'phases': phases, 'injection': observation, 'unrelatedPreload': str(unrelated_library),
              'unrelatedPreloadSHA256': fault.sha256(unrelated_library),
              'helperSHA256': fault.sha256(helper), 'removedInheritedEnvironmentKeys': removed}
    fault.write_json(output / 'negative-control-result.json', report)
    print(json.dumps({'status': report['status'], 'checks': checks}, indent=2))
    assert all(checks.values()), 'Missing-hook negative control failed'
finally:
    for child in list(fault.ACTIVE_CHILDREN.values()):
        fault.kill_owned_group(child)
