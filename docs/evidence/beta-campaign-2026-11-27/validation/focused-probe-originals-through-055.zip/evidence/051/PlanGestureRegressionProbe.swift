import Foundation
import LightingCore

/// The fixture and expectations are identical for both revisions. These three
/// adapters only bridge the deliberate API change. The old begin is its actual
/// zero-motion sample; baseline tokens are ignored because that API has none.
@MainActor
private struct Gesture {
    let id: UUID
    let generation: UUID
    let token: UUID

    init(_ session: StudioSession) {
        id = session.selection!
        generation = session.generation
        #if REPAIRED_API
        token = session.beginPlanDrag(id, scale: 100, from: generation)!
        #else
        _ = session.dragLight(id, translationX: 0, translationZ: 0, scale: 100, from: generation)
        precondition(session.planDrag != nil)
        token = UUID()
        #endif
    }

    func move(_ session: StudioSession, _ translation: Double) -> Bool {
        #if REPAIRED_API
        session.dragLight(id, token: token, translationX: translation, translationZ: 0,
                          scale: 100, from: generation)
        #else
        session.dragLight(id, translationX: translation, translationZ: 0, scale: 100, from: generation)
        #endif
    }

    func end(_ session: StudioSession) {
        #if REPAIRED_API
        session.finishPlanDrag(token: token, lightID: id, generation: generation)
        #else
        session.finishPlanDrag(lightID: id, generation: generation)
        #endif
    }
}

@main @MainActor
struct PlanGestureRegressionProbe {
    private static var failures = 0
    private static var checks = 0

    private static func expect(_ condition: Bool, _ label: String) {
        checks += 1
        if !condition { failures += 1 }
        print("\(condition ? "PASS" : "FAIL") \(label)")
    }

    private static func history(_ session: StudioSession, _ states: [LightingScene], _ label: String) {
        let generation = session.generation
        expect(!session.history.isEditing, "\(label): transaction ended")
        for (index, state) in states.dropLast().reversed().enumerated() {
            expect(session.undo(from: generation) && session.scene == state,
                   "\(label): exact undo snapshot \(index + 1)")
        }
        expect(!session.undo(from: generation), "\(label): no extra undo")
        for (index, state) in states.dropFirst().enumerated() {
            expect(session.redo(from: generation) && session.scene == state,
                   "\(label): exact redo snapshot \(index + 1)")
        }
        expect(!session.redo(from: generation), "\(label): no extra redo")
    }

    static func main() async throws {
        for boundary in ["finish", "replacement", "control", "save", "height", "same-light gesture"] {
            let session = StudioSession(execute: { request in
                if case .load = request.operation { return nil }
                var library = try request.expected ?? ProjectLibrary(name: "Saved", scene: request.scene)
                try library.updateActiveScene(request.scene)
                return library
            })
            try await session.beginLibraryOperation(.load, from: session.generation).value
            if boundary == "save" {
                try await session.beginLibraryOperation(.save, from: session.generation).value
            }
            let original = session.scene
            let gesture = Gesture(session)
            precondition(gesture.move(session, 20))
            let dragged = session.scene
            var states = [original, dragged]
            let control = session.editOwner("height")
            var fresh: Gesture?
            switch boundary {
            case "finish": session.finishPlanDrag()
            case "replacement":
                var renamed = dragged
                renamed.lights[0].name = "Renamed during drag"
                precondition(session.replace(renamed, from: gesture.generation))
                states.append(renamed)
            case "control":
                session.editChanged(true, owner: control, from: gesture.generation)
                precondition(session.apply(.lightValue(id: gesture.id, field: .y, value: 3),
                                           from: gesture.generation))
            case "save":
                try await session.beginLibraryOperation(.save, from: gesture.generation).value
                expect(session.generation == gesture.generation, "save: generation stayed unchanged")
            case "height":
                precondition(session.apply(.lightValue(id: gesture.id, field: .y, value: 4),
                                           from: gesture.generation))
                states.append(session.scene)
                expect(session.planDrag == nil && !session.history.isEditing,
                       "height: accepted command closes Plan transaction")
            default:
                gesture.end(session)
                fresh = Gesture(session)
                precondition(fresh!.move(session, 10))
            }

            let beforeLateChange = session.editor
            let beforeLateDrag = session.planDrag
            let accepted = gesture.move(session, boundary == "height" ? 30 : 20)
            expect(!accepted, "\(boundary): late cumulative value rejected")
            expect(session.editor == beforeLateChange && session.planDrag == beforeLateDrag,
                   "\(boundary): late value preserves scene/revision/history/active gesture")
            gesture.end(session)
            expect(session.editor == beforeLateChange && session.planDrag == beforeLateDrag,
                   "\(boundary): late end preserves active gesture/history")
            if boundary == "control" {
                expect(session.history.isEditing, "control: foreign control keeps its edit")
                precondition(session.apply(.lightValue(id: gesture.id, field: .y, value: 4),
                                           from: gesture.generation))
                session.editChanged(false, owner: control, from: gesture.generation)
                var expected = dragged
                expected.lights[0].position.y = 4
                states.append(expected)
            } else if boundary == "height" {
                expect(session.scene.lights[0].position.y == 4, "height: accepted y=4 remains present")
                session.finishPlanDrag()
            } else if let fresh {
                expect(session.history.isEditing, "same-light gesture: fresh token remains active")
                precondition(fresh.move(session, 30))
                fresh.end(session)
                var expected = dragged
                expected.lights[0].position.x += 0.3
                states.append(expected)
            }
            if boundary == "save" {
                expect(session.scene == session.saved, "save: stale callback does not dirty saved scene")
            }
            history(session, states, boundary)
        }
        print("RESULT: \(checks) checks; \(failures) failures")
        if failures > 0 { exit(1) }
    }
}
