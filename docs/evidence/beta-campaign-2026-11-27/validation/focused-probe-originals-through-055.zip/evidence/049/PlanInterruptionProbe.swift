import Foundation
import LightingCore

@main struct PlanInterruptionProbe {
    @MainActor static func main() async throws {
        let session = StudioSession(execute: { request in
            if case .load = request.operation { return nil }
            var library = try request.expected ?? ProjectLibrary(name: "Saved", scene: request.scene)
            try library.updateActiveScene(request.scene)
            return library
        })
        try await session.beginLibraryOperation(.load, from: session.generation).value
        let id = session.selection!
        let generation = session.generation
        precondition(session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: generation))
        let beforeBoundary = session.scene.lights[0].position.x
        var renamed = session.scene
        renamed.lights[0].name = "Renamed during drag"
        precondition(session.replace(renamed, from: generation))
        precondition(session.planDrag == nil)
        let lateAccepted = session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: generation)
        print("replacement boundary: late identical cumulative sample accepted=\(lateAccepted), xBefore=\(beforeBoundary), xAfter=\(session.scene.lights[0].position.x), expected=\(beforeBoundary)")
        session.finishPlanDrag(lightID: id, generation: generation)

        let differentControl = session.editOwner("height")
        precondition(session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: generation))
        session.editChanged(true, owner: differentControl, from: generation)
        precondition(session.apply(.lightValue(id: id, field: .y, value: 3), from: generation))
        let beforeRival = session.scene
        let lateRivalAccepted = session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: generation)
        print("control boundary: late sample accepted=\(lateRivalAccepted), xBefore=\(beforeRival.lights[0].position.x), xAfter=\(session.scene.lights[0].position.x), activePlan=\(session.planDrag != nil)")
        session.finishPlanDrag(lightID: id, generation: generation)

        try await session.beginLibraryOperation(.save, from: session.generation).value
        let savedGeneration = session.generation
        precondition(session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: savedGeneration))
        let beforeSave = session.scene
        try await session.beginLibraryOperation(.save, from: savedGeneration).value
        precondition(session.generation == savedGeneration)
        let lateSaveAccepted = session.dragLight(id, translationX: 20, translationZ: 0, scale: 100, from: savedGeneration)
        print("existing-project save: generationSame=\(session.generation == savedGeneration), late sample accepted=\(lateSaveAccepted), xBefore=\(beforeSave.lights[0].position.x), xAfter=\(session.scene.lights[0].position.x), dirty=\(session.scene != session.saved)")

        // A discrete height write can also be overwritten by the frozen whole
        // Position snapshot even though Plan moves only x and z.
        let isolated = StudioSession(execute: { _ in nil })
        try await isolated.beginLibraryOperation(.load, from: isolated.generation).value
        let isolatedID = isolated.selection!
        let initialHeight = isolated.scene.lights[0].position.y
        precondition(isolated.dragLight(isolatedID, translationX: 20, translationZ: 0, scale: 100, from: isolated.generation))
        precondition(isolated.apply(.lightValue(id: isolatedID, field: .y, value: 4), from: isolated.generation))
        precondition(isolated.dragLight(isolatedID, translationX: 30, translationZ: 0, scale: 100, from: isolated.generation))
        let lostHeight = isolated.scene.lights[0].position.y
        isolated.finishPlanDrag()
        precondition(isolated.undo(from: isolated.generation))
        let undoHeight = isolated.scene.lights[0].position.y
        precondition(!isolated.history.canUndo)
        precondition(isolated.redo(from: isolated.generation))
        print("height write during Plan: acceptedHeight=4, afterNextPlanHeight=\(lostHeight), initialHeight=\(initialHeight), undoHeight=\(undoHeight), redoHeight=\(isolated.scene.lights[0].position.y)")
    }
}
