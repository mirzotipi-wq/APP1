"""Existing worker087 followup: freshly reconcile source2fc core05 originals.
Adapted from retained worker087/core03 script, originally worker072 logic.
Prior receipts remain unchanged; every current test/math/byte assertion is rerun.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import re
import subprocess

BASE = Path("/workspace/scratch/4633a14a0d5b")
HERE = Path(__file__).resolve().parent
REPO = BASE / "APP1"
PRIOR = BASE / "campaign/evidence/published-core-03"
REV = "2fc7647314d3ae6fa22d95284e778c6c5badbe4a"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

artifact = read(HERE / "artifact-receipt.json")
observation = read(HERE / "github-observation.json")
assert observation["artifact"]["workflow_run"]["head_sha"] == REV
assert observation["artifact"]["id"] == artifact["artifactID"]
assert observation["artifact"]["digest"] == "sha256:" + sha(HERE / artifact["archiveFile"])
assert observation["job"]["id"] == 140575914429
assert observation["job"]["status"] == "completed"
assert observation["job"]["conclusion"] == "success"
assert all(s["status"] == "completed" and s["conclusion"] == "success" for s in observation["job"]["steps"])
assert all(sha(HERE / f["path"]) == f["sha256"] for f in artifact["files"])

source = read(HERE / "source-inventory.json")
assert source["sourceRevision"] == REV
darwin = [m for m in source["methodInventory"]["composition"]["methods"] if m["file"] == "NativeTests/StudioObservationTests.swift"]
darwin_source = subprocess.check_output(["git", "show", REV + ":NativeTests/StudioObservationTests.swift"], cwd=REPO, text=True)
assert darwin_source.startswith("#if canImport(Darwin)\n") and darwin_source.rstrip().endswith("#endif") and len(darwin) == 3
source["linuxMethodInventory"] = {
    name: [m for m in row["methods"] if m not in darwin]
    for name, row in source["methodInventory"].items()
}
source["conditionalMethodsExcludedOnLinux"] = {"reason": "The entire StudioObservationTests.swift file is guarded by #if canImport(Darwin). These three methods are not Linux runtime tests.", "methods": darwin}
write("source-inventory.json", source)

expected = {}
for target, methods in source["linuxMethodInventory"].items():
    for m in methods:
        name = m["class"] + "." + m["method"]
        assert name not in expected
        expected[name] = target
assert Counter(expected.values()) == {"composition": 86, "core": 502}

def parse_tests(filename, configuration):
    text = (HERE / filename).read_text()
    starts = Counter(re.findall(r"^Test Case '([^']+)' started at ", text, re.M))
    outcomes = re.findall(r"^Test Case '([^']+)' (passed|failed|skipped) \(([\d.]+) seconds\)", text, re.M)
    ends = Counter(name for name, outcome, duration in outcomes)
    assert len(starts) == 588 and sum(starts.values()) == 588
    assert starts == ends and set(starts) == set(expected)
    assert all(outcome == "passed" for name, outcome, duration in outcomes)
    summaries = re.findall(r"Test Suite 'All tests' (passed|failed) at ([^\n]+)\n\s*Executed (\d+) tests, with (\d+) failures \((\d+) unexpected\) in ([\d.]+)", text)
    assert [int(row[2]) for row in summaries] == [86, 502]
    assert all(row[0] == "passed" and row[3:5] == ("0", "0") for row in summaries)
    assert len(re.findall(r"Test Suite 'All tests' started at ", text)) == 2
    methods = [{"name": name, "target": expected[name], "outcome": outcome, "durationSeconds": float(duration)} for name, outcome, duration in outcomes]
    return {
        "configuration": configuration, "sourceLog": filename, "sourceLogSHA256": sha(HERE / filename),
        "started": sum(starts.values()), "passed": len(outcomes), "failed": 0, "skipped": 0, "incomplete": 0,
        "duplicateStarts": 0, "duplicateTerminalEvents": 0,
        "targetCounts": dict(Counter(expected[name] for name in starts)),
        "bundleSummaries": [{"outcome": row[0], "ended": row[1], "executed": int(row[2]), "failures": int(row[3]), "unexpectedFailures": int(row[4]), "durationSeconds": float(row[5])} for row in summaries],
        "methodInventorySHA256": hashlib.sha256(("\n".join(sorted(starts)) + "\n").encode()).hexdigest(),
        "methods": methods,
        "emptySwiftTestingRunsExcluded": len(re.findall(r"Test run with 0 tests in 0 suites passed", text)),
        "matchesPinnedSourceLinuxInventory": True,
    }

tests = {"debug": parse_tests("core-tests.log", "Debug"), "release": parse_tests("core-release-tests.log", "Release")}
assert tests["debug"]["methodInventorySHA256"] == tests["release"]["methodInventorySHA256"]
locale_methods = {m["class"] + "." + m["method"] for m in source["linuxMethodInventory"]["composition"] if m["class"] == "LightTargetLuxDraftTests"}
assert len(locale_methods) == 9
prior_tests = read(PRIOR / "reconciliation.json")["tests"]
for configuration in ("debug", "release"):
    current_names = {m["name"] for m in tests[configuration]["methods"]}
    prior_names = {m["name"] for m in prior_tests[configuration]["methods"]}
    assert current_names == prior_names and locale_methods <= current_names
    tests[configuration]["retainedLocaleRegressionMethods"] = sorted(locale_methods)
    tests[configuration]["allNineLocaleMethodsPassed"] = True
assert source["nativeInventory"]["count"] == 327
assert source["uiInventory"]["requiredCount"] == 44 and source["uiInventory"]["diagnosticCount"] == 2

console = (HERE / "core-job-console.log").read_text()
clean = re.sub(r"^\ufeff?\d{4}-\d\d-\d\dT\S+Z ", "", console, flags=re.M)
tooling = re.findall(r"^Ran (\d+) tests in ([\d.]+)s\n\nOK$", clean, re.M)
assert tooling == [("104", "21.486")]
assert "python3 -m unittest discover -s scripts/tests -p 'test_*.py'" in clean
recovery_step = next(x for x in observation["job"]["steps"] if x["number"] == 9)
assert recovery_step["name"] == "Verify recovery commit failure and retry on Linux"
assert recovery_step["status"] == "completed" and recovery_step["conclusion"] == "success"
recovery_artifact = next(x for x in observation["artifacts"] if x["name"] == "library-recovery-linux-evidence")
assert recovery_artifact["workflow_run"]["head_sha"] == REV and recovery_artifact["workflow_run"]["id"] == 46019722045
assert recovery_artifact["id"] == 15207742612 and recovery_artifact["size_in_bytes"] == 52526
recovery_rows = [json.loads(line) for line in clean.splitlines() if line.startswith('{"output": ') and '"probe": "project_library_recovery_commit_failure_linux"' in line]
assert len(recovery_rows) == 1 and recovery_rows[0]["status"] == "passed"
assert "python3 scripts/probe_library_recovery_failure.py --timeout-seconds 300" in clean
recovery_start = clean.index("python3 scripts/probe_library_recovery_failure.py --timeout-seconds 300")
recovery_end = clean.index("Artifact download URL: https://github.com/mirzotipi-wq/APP1/actions/runs/46019722045/artifacts/15207742612", recovery_start)
recovery_text = clean[recovery_start:recovery_end]
assert "With the provided path, there will be 111 files uploaded" in recovery_text
assert "SHA256 digest of uploaded artifact zip is " + recovery_artifact["digest"].removeprefix("sha256:") in recovery_text
assert "Final size is 52526 bytes. Artifact ID is 15207742612" in recovery_text
recovery_gate = {"sourceRevision": REV, "step": recovery_step, "consoleResult": recovery_rows[0], "artifactMetadata": recovery_artifact, "uploadReportedFileCount": 111, "metadataAndConsoleAgree": True, "currentOriginalRecoveryArtifactDownloaded": False, "currentRecoveryContentsIndependentlyReconciled": False, "reasonNotDownloaded": "Current scope verifies gate execution/status and upload metadata. No discrepancy in command, result, upload size, identity or digest warrants a deeper artifact audit.", "historicalDeepAudit": {"path": "campaign/evidence/076/reconciliation.json", "sha256": sha(BASE / "campaign/evidence/076/reconciliation.json"), "sourceRevision": "134f9adabe0203b1d6d8ed21abb6aaeb4e19d256", "appliesToCurrentRun": False}, "scope": "Current gate execution/status and upload receipts only; prior worker076 fault details are separate historical evidence."}
write("recovery-gate-status.json", recovery_gate)

tooling_receipt = {
    "count": 104, "outcome": "OK", "seconds": 21.486,
    "source": "core-job-console.log", "sourceSHA256": sha(HERE / "core-job-console.log"),
    "command": "python3 -m unittest discover -s scripts/tests -p 'test_*.py'",
    "evidenceExcerpt": "Ran 104 tests in 21.486s\n\nOK",
    "individualMethodNamesAvailable": False,
}
env = (HERE / "core-environment.log").read_text()
assert env.rstrip().endswith(REV)
assert "Swift version 6.4.3" in env and "Python 3.12.3" in env

def checksums(path):
    rows = [line.split(None, 1) for line in path.read_text().splitlines() if line]
    result = {Path(name).name: digest for digest, name in rows}
    assert len(result) == 12
    return result

baseline_path = REPO / "docs/evidence/branch-consolidation-2026-11-27/rendering/study-image-sha256.txt"
baseline = checksums(baseline_path)
current_hashes = checksums(HERE / "study-image-sha256.txt")
prior_receipt_path = PRIOR / "reconciliation.json"
prior_receipt = read(prior_receipt_path)
prior_artifact = read(PRIOR / "artifact-receipt.json")
prior_hashes = {Path(row["path"]).name: row["sha256"] for row in prior_artifact["files"] if "study-artifacts/" in row["path"]}
manifest = read(HERE / "study-artifacts/manifest.json")
assert manifest["syntheticOnly"] is True and manifest["softwareValidationPassed"] is True
assert manifest["expectedFixtureCount"] == len(manifest["fixtures"]) == 12
assert sha(HERE / "study-artifacts/manifest.json") == sha(PRIOR / "study-artifacts/manifest.json") == prior_hashes["manifest.json"]
prior_visual_path = BASE / "campaign/evidence/published-core-02/root-visual-review.json"
prior_visual = read(prior_visual_path)
assert prior_visual["sourceRevision"] == "134f9adabe0203b1d6d8ed21abb6aaeb4e19d256"
assert prior_visual["workflowRun"] == 45999974158 and prior_visual["actualImagesViewed"] == 12
assert prior_visual["reviewer"] == "root"
reviewed_pairs = {Path(x["image"]).stem: x for x in prior_visual["originals"]}
assert len(reviewed_pairs) == 12
prior_numerical_pairs = {x["name"]: x for x in prior_receipt["renderedImages"]["fixtures"]}
render = (HERE / "study-render.log").read_text()
images = []
payloads = {}
for row in manifest["fixtures"]:
    name = row["name"]
    ppm = HERE / "study-artifacts" / row["ppmFile"]
    scene = HERE / "study-artifacts" / row["sceneFile"]
    ppm_sha, scene_sha = sha(ppm), sha(scene)
    assert ppm_sha == current_hashes[ppm.name] == baseline[ppm.name] == prior_hashes[ppm.name] == sha(PRIOR / "study-artifacts" / ppm.name)
    assert scene_sha == prior_hashes[scene.name] == sha(PRIOR / "study-artifacts" / scene.name)
    assert ppm_sha == reviewed_pairs[name]["imageSHA256"] == prior_numerical_pairs[name]["ppmSHA256"]
    assert scene_sha == reviewed_pairs[name]["sceneSHA256"] == prior_numerical_pairs[name]["sceneJSONSHA256"]
    read(scene)
    data = ppm.read_bytes()
    header = re.match(rb"P6\n(\d+) (\d+)\n255\n", data)
    assert header
    width, height = map(int, header.groups())
    payloads[name] = data[header.end():]
    assert len(payloads[name]) == width * height * 3
    assert width == row["width"] == row["expectedWidth"]
    assert height == row["height"] == row["expectedHeight"]
    assert row["rgbaByteCount"] == width * height * 4
    assert row["unsupportedMaskByteCount"] == width * height
    assert row["unsupportedPixels"] == 0 and row["passed"] is True and row["validationErrors"] == []
    assert f"{name}: {width}×{height}, unsupported pixels 0" in render
    images.append({"name": name, "width": width, "height": height, "ppmSHA256": ppm_sha, "sceneJSONSHA256": scene_sha, "reportedUnsupportedPixels": 0, "matchesCurrentChecksumManifest": True, "matchesOriginalBaselinePPMHash": True, "matchesPriorPublishedBytesAndReceipt": True})
for row in manifest["fixtures"]:
    if "comparisonFixture" in row:
        a, b = payloads[row["name"]], payloads[row["comparisonFixture"]]
        assert len(a) == len(b)
        different = sum(a[i:i+3] != b[i:i+3] for i in range(0, len(a), 3))
        assert different == row["differentPixelsFromComparison"]
        next(x for x in images if x["name"] == row["name"])["recomputedDifferentPixels"] = different

pattern = re.compile(r"^.+/([^/]+)\.bin: mean=([^,]+), max=(\d+), >4 fraction=([^,]+), invalid=(\d+)/(\d+), invalid-mask-mismatches=(\d+)(?:, max-limit=(\d+))?, (PASS|FAIL)$")
def parse_kernel(filename, expected_count, strict):
    records = []
    for line in (HERE / filename).read_text().splitlines():
        if not line.strip(): continue
        m = pattern.fullmatch(line)
        assert m, line
        fixture, mean, maximum, fraction, cpu, shared, mismatch, limit, outcome = m.groups()
        record = {"fixture": fixture, "meanRGBChannelError": float(mean), "maximumChannelError": int(maximum), "fractionChannelsErrorAbove4": float(fraction), "cpuUnsupportedPixels": int(cpu), "sharedKernelUnsupportedPixels": int(shared), "invalidMaskMismatches": int(mismatch), "maximumChannelErrorLimit": int(limit) if limit else None, "outcome": outcome}
        assert math.isfinite(record["meanRGBChannelError"]) and record["meanRGBChannelError"] <= 1
        assert math.isfinite(record["fractionChannelsErrorAbove4"]) and record["fractionChannelsErrorAbove4"] <= 0.005
        assert int(cpu) == int(shared) and int(mismatch) == 0 and outcome == "PASS"
        if strict: assert int(limit) == 1 and int(maximum) <= 1
        records.append(record)
    assert len(records) == len({x["fixture"] for x in records}) == expected_count
    return {"sourceLog": filename, "sourceSHA256": sha(HERE / filename), "recordCount": len(records), "passed": len(records), "invalidMaskMismatchSum": sum(x["invalidMaskMismatches"] for x in records), "cpuUnsupportedPixelSum": sum(x["cpuUnsupportedPixels"] for x in records), "sharedKernelUnsupportedPixelSum": sum(x["sharedKernelUnsupportedPixels"] for x in records), "records": records}
parity = parse_kernel("study-kernel.log", 6, False)
precision = parse_kernel("study-precision.log", 8, True)
assert parity["cpuUnsupportedPixelSum"] == 84
assert precision["cpuUnsupportedPixelSum"] == 160

bench = read(HERE / "study-benchmark.json")
assert bench["sourceRevision"] == REV and bench["optimizedBuild"] is True and bench["measuredSamplesPerWorkload"] == 7
assert len(bench["frames"]) == 8 and len(bench["visibility"]) == 4 and len(bench["cancellation"]) == 12
bench_lines = [line.split("KEYFILL_BENCHMARK ", 1)[1] for line in clean.splitlines() if line.startswith("KEYFILL_BENCHMARK ")]
assert len(bench_lines) == 1 and json.loads(bench_lines[0]) == bench
timings = []
for row in bench["frames"] + bench["visibility"]:
    samples = row["timing"]["samplesMilliseconds"]
    assert len(samples) == 7 and all(math.isfinite(v) and v >= 0 for v in samples)
    ordered = sorted(samples)
    p50, p95 = ordered[math.ceil(0.5 * len(ordered)) - 1], ordered[math.ceil(0.95 * len(ordered)) - 1]
    assert p50 == row["timing"]["p50Milliseconds"] and p95 == row["timing"]["p95Milliseconds"]
    timings.append({"name": row["name"], "visibilityEnabled": row.get("visibilityEnabled"), "samples": samples, "recomputedP50Milliseconds": p50, "recomputedP95Milliseconds": p95})
prior_bench = read(PRIOR / "study-benchmark.json")
prior_frames = {x["name"]: x for x in prior_bench["frames"]}
for row in bench["frames"]:
    assert row["unsupportedPixels"] == 0
    assert row["width"] in (72,144) and row["height"] == row["width"] * 2 // 3
    assert row["rgbaFNV1a64"] == prior_frames[row["name"]]["rgbaFNV1a64"]
    assert math.isfinite(row["warmupMilliseconds"]) and row["warmupMilliseconds"] >= 0
groups = Counter()
for row in bench["cancellation"]:
    requested, before, observed, finished = (row[k] for k in ["requestedAfterMilliseconds", "precedingCheckAtMilliseconds", "observedAtMilliseconds", "finishedAfterMilliseconds"])
    assert row["cancelled"] is True
    assert all(math.isfinite(v) and v >= 0 for v in (requested, before, observed, finished))
    assert before <= requested <= observed <= finished
    assert math.isclose(row["deadlineToReturnMilliseconds"], finished - requested, rel_tol=0, abs_tol=1e-12)
    groups[(row["name"], requested)] += 1
assert groups == {("bust-area3-144",5):3,("bust-area3-144",25):3,("bust-area12-144",5):3,("bust-area12-144",25):3}
for row in bench["visibility"]:
    assert row["receivers"] == 34 and row["evaluationsPerSample"] == 1000
    assert math.isfinite(row["signalComponentSum"])
    prior = next(x for x in prior_bench["visibility"] if (x["name"],x["visibilityEnabled"]) == (row["name"],row["visibilityEnabled"]))
    assert row["signalComponentSum"] == prior["signalComponentSum"]

# Independently compare exact-source obligations with prior pinned f94 inventory.
prior_source = read(PRIOR / "source-inventory.json")
assert prior_source["sourceRevision"] == "f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5"
prior_inputs = {x["path"]: x for x in prior_source["inputs"]}
current_inputs = {x["path"]: x for x in source["inputs"]}
assert set(prior_inputs) == set(current_inputs)
core_input_paths = sorted(p for p in current_inputs if p.startswith(("Sources/", "Tests/")))
assert all(current_inputs[p] == prior_inputs[p] for p in core_input_paths)
composition_paths = ["App/LightTargetLuxDraft.swift", "App/ProjectLibraryOperation.swift", "App/ProjectStore.swift", "App/StudioSession.swift", "Package.swift"] + source["methodInventory"]["composition"]["files"]
assert all(current_inputs[p] == prior_inputs[p] for p in composition_paths)
changed_inputs = [{"path": p, "priorSHA256": prior_inputs[p]["sha256"], "currentSHA256": current_inputs[p]["sha256"]} for p in sorted(current_inputs) if current_inputs[p] != prior_inputs[p]]
prior_native = {m["class"] + "." + m["method"] for m in prior_source["nativeInventory"]["methods"]}
current_native = {m["class"] + "." + m["method"] for m in source["nativeInventory"]["methods"]}
assert len(current_native - prior_native) == 4 and not prior_native - current_native
assert all(m.startswith("StudioTextFieldTests.") for m in current_native - prior_native)
prior_ui = {m for s in prior_source["uiInventory"]["shards"].values() if not s["diagnostic"] for m in s["methods"]}
current_ui = {m for s in source["uiInventory"]["shards"].values() if not s["diagnostic"] for m in s["methods"]}
assert prior_ui == current_ui and len(current_ui) == 44
required_shards = {k: s for k, s in source["uiInventory"]["shards"].items() if not s["diagnostic"]}
assert len(required_shards) == 6
source_comparison = {"sourceRevision": REV, "priorSourceRevision": prior_source["sourceRevision"], "priorInventorySHA256": sha(PRIOR / "source-inventory.json"), "currentInventorySHA256": sha(HERE / "source-inventory.json"), "unchangedCoreAndTestInputs": core_input_paths, "unchangedPortableCompositionInputs": composition_paths, "changedInputs": changed_inputs, "newNativeSourceMethods": sorted(current_native - prior_native), "requiredUIMethodSetUnchanged": True, "requiredUIShardCounts": {k: len(v["methods"]) for k, v in required_shards.items()}, "runtimeClaim": False}
write("source-comparison.json", source_comparison)

# Current atomic/interruption and recovery status: console receipts, not deep ZIP audits.
atomic_step = next(x for x in observation["job"]["steps"] if x["number"] == 7)
assert atomic_step["name"] == "Verify atomic write failure and commit interruption on Linux"
assert atomic_step["status"] == "completed" and atomic_step["conclusion"] == "success"
atomic_artifact = next(x for x in observation["artifacts"] if x["name"] == "atomic-library-write-linux-evidence")
assert atomic_artifact["workflow_run"]["head_sha"] == REV and atomic_artifact["workflow_run"]["id"] == 46019722045
assert atomic_artifact["id"] == 15207937352 and atomic_artifact["size_in_bytes"] == 157197
assert atomic_artifact["digest"] == "sha256:37150509c1a67b02f752edbc655784a7d0fe84aac24bf1290a6df090633dc350"
assert recovery_artifact["digest"] == "sha256:ebb1712a18af94fd37aa0d2a6e89358574e32f6309315dcbc2de8233d1f036c9"
atomic_start = clean.index("python3 scripts/run_atomic_library_write_probe.py --with-commit-interruption")
atomic_end = clean.index("Artifact download URL: https://github.com/mirzotipi-wq/APP1/actions/runs/46019722045/artifacts/15207937352", atomic_start)
atomic_text = clean[atomic_start:atomic_end]
atomic_objects = []
for match in re.finditer(r"^\{", atomic_text, re.M):
    try:
        obj, length = json.JSONDecoder().raw_decode(atomic_text[match.start():])
    except ValueError:
        continue
    if "status" in obj:
        atomic_objects.append(obj)
assert len(atomic_objects) == 3
assert all(o["status"] == "passed" for o in atomic_objects)
assert {o["probe"] for o in atomic_objects if isinstance(o["probe"], str)} == {"project_library_atomic_write_EFBIG", "project_library_commit_boundaries_linux"}
assert all(o.get("sourceRevision", o.get("baseRevision")) == REV for o in atomic_objects)
assert "With the provided path, there will be 101 files uploaded" in atomic_text
assert "SHA256 digest of uploaded artifact zip is " + atomic_artifact["digest"].removeprefix("sha256:") in atomic_text
assert "Final size is 157197 bytes. Artifact ID is 15207937352" in atomic_text
assert "SHA256 digest of uploaded artifact zip is " + artifact["archiveSHA256"] in clean
assert "Final size is 115683 bytes. Artifact ID is 15207049101" in clean
failure_gates = {"sourceRevision": REV, "atomicAndInterruption": {"step": atomic_step, "artifactMetadata": atomic_artifact, "uploadReportedFileCount": 101, "consoleResults": atomic_objects, "metadataAndConsoleAgree": True, "separateArtifactDownloaded": False, "deepOriginalFaultEvidenceAuditPerformed": False}, "recovery": recovery_gate, "limits": "Current completed Linux step status, complete decoded console and matching upload receipts. Separate atomic/recovery ZIP contents were not downloaded or independently rehashed. Prior worker076 fault details remain source134 historical evidence."}
write("linux-failure-gates.json", failure_gates)

receipt = {
    "schemaVersion": 1, "worker": "087", "assignment": "followup-source2fc-core05", "sameWorkerIdentity": True, "canonicalTask": "/root/a087_current_core_ci",
    "createdAtUTC": datetime.now(timezone.utc).isoformat(), "sourceRevision": REV,
    "provenance": {"runID":46019722045,"jobID":140575914429,"jobConclusion":"success","artifactID":15207049101,"runURL":"https://github.com/mirzotipi-wq/APP1/actions/runs/46019722045","jobURL":"https://github.com/mirzotipi-wq/APP1/actions/runs/46019722045/job/140575914429","artifactReceipt":"artifact-receipt.json","archiveSHA256":artifact["archiveSHA256"],"authenticatedReadToolsUsed":True,"archiveDigestIndependentlyVerified":True},
    "environment":{"swift":"6.4.3 (swift-6.4.3-RELEASE)","python":"3.12.3","operatingSystem":bench["operatingSystem"],"architecture":bench["architecture"],"cpuModel":bench["cpuModel"],"reportedProcessors":bench["reportedProcessors"],"sourceRevisionMatchesEnvironmentAndBenchmark":True},
    "sourceInventory":{"path":"source-inventory.json","sha256":sha(HERE/"source-inventory.json"),"pinnedInputFiles":len(source["inputs"]),"compositionMethodsOnLinux":86,"domainMethodsOnLinux":502,"darwinOnlyMethodsNotExecuted":3,"nativeSourceMethods":327,"requiredUISourceMethods":44,"diagnosticUISourceMethods":2,"nativeAndUICountsAreInventoryOnly":True,"allNineLocaleMethodsPassedInBothConfigurations":True},
    "tests":tests,"totalPortableExecutions":1176,"distinctPortableMethods":588,"toolingTests":tooling_receipt,
    "renderedImages":{"count":12,"fixtures":images,"manifestSHA256":sha(HERE/"study-artifacts/manifest.json"),"baselineHashManifest":str(baseline_path.relative_to(BASE)),"baselineHashManifestSHA256":sha(baseline_path),"priorReceipt":str(prior_receipt_path.relative_to(BASE)),"priorReceiptSHA256":sha(prior_receipt_path),"allPPMHeadersPayloadLengthsDimensionsVerified":True,"allTwelveImagesAndScenesMatchPriorPublishedBytesAndReceipt":True,"allTenPixelDifferenceCountsRecomputed":True,"actualImageViewPerformedByWorker":False,"visualReview":"All current originals are byte-identical to retained f94 core03 originals and the twelve actually reviewed core02 images and scenes. No fresh viewing performed in this worker087 followup.","priorActualVisualReview":{"path":str(prior_visual_path.relative_to(BASE)),"sha256":sha(prior_visual_path),"reviewer":"root","actualImagesViewed":12,"sourceRevision":prior_visual["sourceRevision"]},"unsupportedPixelEvidence":"Original fixture manifest and render log report zero. No raw validity-mask artifact was uploaded."},
    "sharedFloat32Parity":parity,"strictPrecision":precision,"currentRecoveryGate":recovery_gate,"currentLinuxFailureGates":{"path":"linux-failure-gates.json","sha256":sha(HERE / "linux-failure-gates.json"),"bothStepsPassed":True},"sourceComparison":source_comparison,
    "benchmark":{"sourceJSON":"study-benchmark.json","sourceSHA256":sha(HERE/"study-benchmark.json"),"frameWorkloads":8,"visibilityWorkloads":4,"cancellationProbes":12,"timedSampleCount":84,"measuredSamplesPerTimedWorkload":7,"all24PercentileValuesMatchExactly":True,"nearestRankFormula":"sort(samples)[ceil(percentile * sampleCount) - 1]","consoleJSONMatchesArtifactExactly":True,"allEightFrameChecksumsMatchPriorPublishedRun":True,"allFourVisibilitySignalsMatchPriorPublishedRun":True,"timings":timings,"cancellationGroups":[{"name":k[0],"requestedAfterMilliseconds":k[1],"probes":v} for k,v in sorted(groups.items())],"totalWorkloadMilliseconds":bench["totalWorkloadMilliseconds"],"minimumDeadlineToReturnMilliseconds":min(x["deadlineToReturnMilliseconds"] for x in bench["cancellation"]),"maximumDeadlineToReturnMilliseconds":max(x["deadlineToReturnMilliseconds"] for x in bench["cancellation"]),"allCancellationTimelinesAndDeadlineDifferencesConsistent":True,"limitations":"Host diagnostics only. Current AMD EPYC 9V45 / Swift 6.4.3 and prior f94 Intel Xeon 6975P-C / Swift 6.4.2 timings are not a controlled regression comparison. No GPU, physical-device, sustained FPS, thermal, memory or UI-scheduling claim; callback checks are not pixel-evaluation counts."},
    "reconciliationMethod":{"derivedFrom":"campaign/evidence/published-core-03/reconcile.py","predecessorScriptSHA256":sha(PRIOR/"reconcile.py"),"freshOriginalDownloadAndIndependentExecution":True,"carriedForwardPasses":False},
    "verification":{"discrepancies":[],"allAssignedNumericalAndByteChecksPassed":True,"localLedgerStructureCheck":"Passed; this does not establish runtime results.","localLedgerNext":"M01, persistence_smoke remains outstanding.","newBuildsRun":False,"testsRerun":False,"nativeExecutionClaimed":False,"physicalValidationClaimed":False,"pushed":False,"repoFilesChanged":False,"descendantsCreated":False,"separateAtomicAndRecoveryArtifactsReviewed":False,"scope":"Only the completed core job at this exact source; no whole-workflow, Apple, milestone or release acceptance."},
}
write("reconciliation.json", receipt)
hash_paths = [HERE / row["path"] for row in artifact["files"]] + [HERE / name for name in ["published-05-core-original.zip","artifact-receipt.json","source-inventory.json","core-job-console.log","github-observation.json","prepare.py","reconcile.py","recovery-gate-status.json","source-comparison.json","linux-failure-gates.json","reconciliation.json"]]
write("retained-hashes.json",{"sourceRevision":REV,"files":[{"path":str(p.relative_to(HERE)),"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(hash_paths)]})
print(json.dumps({"sourceRevision":REV,"artifactSHA256":artifact["archiveSHA256"],"debug":tests["debug"]["passed"],"release":tests["release"]["passed"],"tooling":104,"imageAndScenePairs":12,"parity":parity["recordCount"],"precision":precision["recordCount"],"benchmarkCounts":{"frames":8,"cancellations":12,"visibility":4,"timedSamples":84},"reconciliationSHA256":sha(HERE/"reconciliation.json"),"retainedHashesSHA256":sha(HERE/"retained-hashes.json")},indent=2))

