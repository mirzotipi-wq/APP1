"""Verify/extract original artifact and inventory the exact published git objects."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "APP1"
REV = "2fc7647314d3ae6fa22d95284e778c6c5badbe4a"
RUN = 46019722045
JOB = 140575914429
ARTIFACT = 15207049101

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])

observation = json.loads((HERE / "github-observation.json").read_text())
observation["artifact"] = next(x for x in observation["artifacts"] if x["id"] == ARTIFACT)
observation["job"] = next(x for x in observation["jobs"] if x["id"] == JOB)
artifact = observation["artifact"]
assert artifact["workflow_run"]["head_sha"] == REV
assert artifact["workflow_run"]["id"] == RUN
archive = HERE / "published-05-core-original.zip"
archive_hash = sha(archive.read_bytes())
assert artifact["digest"] == "sha256:" + archive_hash
assert archive.stat().st_size == artifact["size_in_bytes"] == 115683
write("github-observation.json", observation)

with zipfile.ZipFile(archive) as z:
    infos = z.infolist()
    names = [i.filename for i in infos]
    assert 0 < len(infos) <= 1000 and len(set(names)) == len(names)
    assert sum(i.file_size for i in infos) <= 100_000_000
    for info in infos:
        name = info.filename
        pure = PurePosixPath(name)
        mode = info.external_attr >> 16
        assert name and "\\" not in name and "\0" not in name and not pure.is_absolute()
        assert all(p not in (".", "..", "") for p in name.rstrip("/").split("/"))
        assert not re.match(r"^[A-Za-z]:", name)
        assert name.rstrip("/") == str(pure)
        assert stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR)
        assert not info.flag_bits & 1 and info.file_size <= 20_000_000
        target = HERE / name
        assert target.resolve().is_relative_to(HERE.resolve()) and not target.exists()
    assert z.testzip() is None
    originals = []
    for info in infos:
        target = HERE / info.filename
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        data = z.read(info)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as f:
            f.write(data)
        originals.append({"path": info.filename, "bytes": len(data), "sha256": sha(data), "zipCRC32": f"{info.CRC:08x}"})
assert len(originals) == 36
write("artifact-receipt.json", {
    "sourceRevision": REV, "runID": RUN, "jobID": JOB, "artifactID": ARTIFACT,
    "archiveFile": archive.name, "archiveSHA256": archive_hash,
    "bytes": archive.stat().st_size, "expectedGitHubDigest": artifact["digest"].removeprefix("sha256:"),
    "digestMatches": True, "fileCount": len(originals), "files": originals,
    "safeZIPChecks": ["unique canonical relative paths", "no traversal, absolute paths, backslashes or drive prefixes", "no symlinks or special files", "no encrypted files", "bounded entry count and expanded bytes", "all CRC32 checks passed before extraction", "no destination overwrite"],
})

prefixes = [".github/workflows", "App", "Sources", "Tests", "NativeTests", "UITests", "scripts", "Package.swift", "project.yml"]
paths = git("ls-tree", "-r", "--name-only", REV, *prefixes).decode().splitlines()
blobs = {path: git("show", f"{REV}:{path}") for path in paths}
tree_rows = git("ls-tree", "-r", REV, *prefixes).decode().splitlines()
tree_entries = {}
for row in tree_rows:
    metadata, name = row.split("\t", 1)
    mode, kind, blob = metadata.split()
    assert kind == "blob"
    tree_entries[name] = (mode, blob)
inputs = [{"path": path, "bytes": len(data), "sha256": sha(data), "gitBlobSHA1": tree_entries[path][1], "mode": tree_entries[path][0]} for path, data in sorted(blobs.items())]

def methods(files):
    result = []
    for path in files:
        text = blobs[path].decode()
        names = re.findall(r"\bfunc\s+(test\w*)\s*\(", text)
        if not names:
            continue
        classes = re.findall(r"\bclass\s+(\w+)\s*:\s*XCTestCase\b", text)
        assert len(classes) == 1 and len(set(names)) == len(names), path
        result.extend({"class": classes[0], "file": path, "method": name} for name in names)
    assert len({(m["class"], m["method"]) for m in result}) == len(result)
    return result

package = blobs["Package.swift"].decode()
test_target = package.split('.testTarget(name: "StudioCompositionTests"', 1)[1]
sources = re.search(r"sources:\s*\[([^]]*)\]", test_target, re.S).group(1)
composition_files = ["NativeTests/" + p for p in re.findall(r'"([^"]+\.swift)"', sources)]
core_files = sorted(p for p in paths if p.startswith("Tests/LightingCoreTests/") and p.endswith(".swift"))
inventory = {name: {"files": files, "count": len(methods(files)), "methods": methods(files)} for name, files in {"composition": composition_files, "core": core_files}.items()}
assert inventory["composition"]["count"] == 89 and inventory["core"]["count"] == 502
native = methods(sorted(p for p in paths if p.startswith("NativeTests/") and p.endswith(".swift")))
ui = methods(sorted(p for p in paths if p.startswith("UITests/") and p.endswith(".swift")))
mapping = {}
for node in ast.parse(blobs["scripts/native_test_shards.py"]).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in {"SHARDS", "DIAGNOSTIC_SHARDS"}:
                mapping[target.id] = ast.literal_eval(node.value)
assert set(mapping) == {"SHARDS", "DIAGNOSTIC_SHARDS"}
assert len(mapping["SHARDS"]) == 6
classes = [c for groups in mapping.values() for names in groups.values() for c in names]
assert len(classes) == len(set(classes)) and set(classes) == {m["class"] for m in ui}
shards = {name: {"diagnostic": name in mapping["DIAGNOSTIC_SHARDS"], "classes": cls, "methods": sorted(m["class"] + "." + m["method"] for m in ui if m["class"] in cls)} for name, cls in {**mapping["SHARDS"], **mapping["DIAGNOSTIC_SHARDS"]}.items()}
required_ui = sum(len(s["methods"]) for s in shards.values() if not s["diagnostic"])
diagnostic_ui = sum(len(s["methods"]) for s in shards.values() if s["diagnostic"])
assert len(native) == 327 and required_ui == 44 and diagnostic_ui == 2
write("source-inventory.json", {
    "sourceRevision": REV, "tree": git("rev-parse", REV + "^{tree}").decode().strip(),
    "inputs": inputs, "methodInventory": inventory,
    "nativeInventory": {"count": len(native), "methods": native},
    "uiInventory": {"requiredCount": required_ui, "diagnosticCount": diagnostic_ui, "shards": shards},
    "note": "Static source inventory only, not native/UI runtime execution. All source bytes read independently from exact pinned git objects."
})
print(json.dumps({"artifactSHA256": archive_hash, "originalFiles": len(originals), "sourceInputs": len(inputs), "portableCompositionIncludingDarwin": inventory["composition"]["count"], "domain": inventory["core"]["count"], "nativeInventory": len(native), "requiredUIInventory": required_ui, "diagnosticUIInventory": diagnostic_ui}, indent=2))
