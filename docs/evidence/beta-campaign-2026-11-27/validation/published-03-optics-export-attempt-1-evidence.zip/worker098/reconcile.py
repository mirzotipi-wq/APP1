"""Independently reconcile exact current UI originals; never executes the app."""
from pathlib import Path, PurePosixPath
import collections, hashlib, io, json, plistlib, re, stat, zipfile

P=Path(__file__).resolve().parent
SHA='f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
RUN=46004241191
JOBS={'room-precision':140527589944,'studio-optics':140527589971,'studio-export':140527590003}

def digest(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((P/name).read_text())
def write(name,data):(P/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def audited_zip(path,metadata,extract_to=None):
    data=path.read_bytes()
    assert len(data)==metadata['size_in_bytes']
    assert 'sha256:'+digest(data)==metadata['digest']
    assert metadata['workflow_run']['id']==RUN and metadata['workflow_run']['head_sha']==SHA
    files=[]
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        items=z.infolist();seen=set()
        assert len(items)<=10000 and sum(i.file_size for i in items)<=1_000_000_000
        for info in items:
            n=info.filename;p=PurePosixPath(n)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in n
            assert n not in seen and str(p)==n.rstrip('/')
            seen.add(n)
            mode=info.external_attr>>16
            assert not stat.S_ISLNK(mode) and not info.flag_bits&1
            assert stat.S_IFMT(mode) in [0,stat.S_IFREG,stat.S_IFDIR]
            if info.is_dir():continue
            raw=z.read(info)
            files.append({'path':n,'bytes':len(raw),'sha256':digest(raw)})
            if extract_to:
                target=extract_to/n;target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists():assert target.read_bytes()==raw
                else:target.write_bytes(raw)
        assert z.testzip() is None
    return {'archive':str(path.relative_to(P)),'artifactID':metadata['id'],'bytes':len(data),'sha256':digest(data),'files':files,'providerDigestVerified':True,'crcAndPathChecksPassed':True}

def events(log,expected):
    observed=collections.defaultdict(list);unknown=[];malformed=[]
    for i,line in enumerate(log.splitlines(),1):
        if "Test Case '-[" not in line:continue
        m=re.search(r"Test Case '-\[(\w+)\.(\w+) (\w+)\]' (\w+)(?: \(\d+(?:\.\d+)? seconds\))?\.?\s*$",line)
        if not m:
            malformed.append({'line':i,'text':line});continue
        target,cl,method,event=m.groups();name=cl+'.'+method
        record={'line':i,'event':event,'text':line}
        if target!='KeyAndFillUITests' or name not in expected:unknown.append({'method':name,'target':target,**record})
        else:observed[name].append(record)
    passed=[];failed=[];incomplete=[];unstarted=[];skipped=[];invalid=[]
    for method in expected:
        seq=[r['event'] for r in observed[method]]
        if seq==['started','passed']:passed.append(method)
        elif seq==['started','failed']:failed.append(method)
        elif seq==['started','skipped']:skipped.append(method)
        elif seq==['started']:incomplete.append(method)
        elif not seq:unstarted.append(method)
        else:invalid.append({'method':method,'sequence':seq})
    return {'expected':expected,'events':dict(observed),'passed':passed,'failed':failed,'incomplete':incomplete,'unstarted':unstarted,'skipped':skipped,'invalid':invalid,'unknown':unknown,'malformed':malformed,'counts':{'expected':len(expected),'started':sum(any(r['event']=='started' for r in observed[k]) for k in expected),'passed':len(passed),'failed':len(failed),'incomplete':len(incomplete),'unstarted':len(unstarted),'skipped':len(skipped)},'allRequiredMethodsPassed':len(passed)==len(expected) and not unknown and not malformed and not invalid}

def attachment_records(directory):
    manifests=list(directory.rglob('manifest.json'))
    if not manifests:return {'manifest':None,'attachments':[],'supplemental':[]}
    assert len(manifests)==1 and manifests[0].stat().st_size<1_000_000
    manifest=json.loads(manifests[0].read_text());records=[]
    assert isinstance(manifest,list)
    for test in manifest:
        for item in test.get('attachments',[]):
            filename=item.get('exportedFileName','');human=item.get('suggestedHumanReadableName','')
            if not filename.endswith(('.png','.txt','.ips','.pdf')):continue
            assert re.fullmatch(r'[A-Fa-f0-9-]+\.(png|txt|ips|pdf)',filename),filename
            paths=list(directory.rglob(filename));assert len(paths)==1
            path=paths[0];data=path.read_bytes()
            record={'humanName':human,'file':str(path.relative_to(P)),'bytes':len(data),'sha256':digest(data),'method':test.get('testIdentifier'),'attachmentMetadata':item}
            if path.suffix=='.png':
                from PIL import Image
                assert data.startswith(b'\x89PNG\r\n\x1a\n')
                with Image.open(io.BytesIO(data)) as im:im.load();record['dimensions']=list(im.size)
            records.append(record)
    supplemental=[r for r in records if r['humanName'].startswith('Supplemental-AXXXL-Beta-') and r['file'].endswith('.png')]
    return {'manifest':str(manifests[0].relative_to(P)),'attachments':records,'supplemental':supplemental}

inventory=read('source-inventory.json');assert inventory['source']==SHA and inventory['run']==RUN
snapshot_path=next(n for n in ['jobs-terminal.json','jobs-optics-followup.json','jobs-current.json','jobs-initial.json'] if (P/n).exists())
snapshot=read(snapshot_path)
jobs={j['id']:j for j in snapshot['jobs']}
run=read('run-current.json') if (P/'run-current.json').exists() else read('run-initial.json')
assert run['id']==RUN and run['head_sha']==SHA
report={'source':SHA,'run':RUN,'runAttempt':run['run_attempt'],'jobSnapshot':snapshot_path,'shards':{},'limitation':'Exact-source UI software execution; no physical-device, signed-distribution or platform audit claim.'}
for name,job_id in JOBS.items():
    job=jobs[job_id];assert job['name']=='ui ('+name+')'
    path=P/name;logpath=path/'job.log'
    if not logpath.exists() and (path/'full/native-tests.log').exists():logpath=path/'full/native-tests.log'
    record={'jobID':job_id,'status':job['status'],'conclusion':job.get('conclusion'),'expected':len(inventory['shards'][name]['methods']),'jobSteps':job.get('steps'),'execution':None,'captures':None}
    if logpath.exists():
        log=logpath.read_text();record['eventLog']=str(logpath.relative_to(P));record['consoleSHA256']=digest(logpath.read_bytes())
        record['execution']=events(log,inventory['shards'][name]['methods'])
        record['xcodeSuccessMarker']='** TEST EXECUTE SUCCEEDED **' in log or '** TEST SUCCEEDED **' in log
        record['xcodeFailureMarker']='** TEST EXECUTE FAILED **' in log or '** TEST FAILED **' in log
        record['failureLines']=[l for l in log.splitlines() if re.search(r'error: -\[|error: .*UITests|##\[error\]|Simulator startup.*failed',l)]
        record['processExitCodes']=re.findall(r'Process completed with exit code (\d+)',log)
        record['commandTimeoutLines']=[l for l in log.splitlines() if '##[error]' in l and 'timed out after' in l]
        record['finalizedExportFailureLines']=[l for l in log.splitlines() if '##[error]' in l and 'No finalized XCTest result bundle' in l]
        record['captureEmissions']=re.findall(r"Added attachment named '([^']+)'",log)
        record['warmupDiagnosticLines']=[l for l in log.splitlines() if 'Simulator warm-up outcome:' in l or 'Simulator startup failed:' in l]
    for kind in ['compact','full']:
        metafile=path/(kind+'-metadata.json');archive=path/(kind+'-original.zip')
        if metafile.exists() and archive.exists():
            receipt=audited_zip(archive,json.loads(metafile.read_text()),path/kind)
            write(str(Path(name)/(kind+'-receipt.json')),receipt)
            record[kind+'Archive']=receipt
            if kind=='compact':record['captures']=attachment_records(path/kind)
            else:
                result=path/'full/artifacts/native-results.zip'
                if result.exists():
                    with zipfile.ZipFile(result) as z:
                        seen=set()
                        for item in z.infolist():
                            n=item.filename;p=PurePosixPath(n);mode=item.external_attr>>16
                            assert not p.is_absolute() and '..' not in p.parts and '\\' not in n
                            assert n not in seen and str(p)==n.rstrip('/');seen.add(n)
                            assert not stat.S_ISLNK(mode) and not item.flag_bits&1
                            assert stat.S_IFMT(mode) in [0,stat.S_IFREG,stat.S_IFDIR]
                        assert z.testzip() is None
                        infos=[i for i in z.namelist() if i.endswith('.xcresult/Info.plist')]
                        if len(infos)==1:
                            data=z.read(infos[0]);info=plistlib.loads(data)
                            record['finalizedXCResult']={'path':infos[0],'infoSHA256':digest(data),'rootID':info.get('rootId'),'version':info.get('version')}
                        else:record['finalizedXCResult']={'present':False,'matchingInfoPlists':infos,'originalMembers':len(z.namelist())}
    trace=path/'full/artifacts/studio-slider-trace-status.txt'
    if trace.exists():
        record['traceStatus']={}
        for line in trace.read_text().splitlines():
            if '=' in line:
                key,value=line.split('=',1);record['traceStatus'][key]=value
        record['traceStatusLimit']='An observed shell EXIT trap status is distinct from xcodebuild status and GitHub timeout/outcome; zero here does not establish a native test pass.'
    source_accounting=path/'full/native-method-accounting.json'
    if source_accounting.exists() and record['execution']:
        producer=json.loads(source_accounting.read_text())
        for key in ['expected','passed','failed','skipped','unstarted']:
            assert sorted(producer[key])==sorted(record['execution'][key]),(name,key)
        record['originalAccountingAgrees']=True
    native_log=path/'full/native-tests.log'
    if native_log.exists() and record['execution']:
        native=events(native_log.read_text(),inventory['shards'][name]['methods'])
        for key in ['expected','passed','failed','incomplete','unstarted','skipped','counts']:
            assert native[key]==record['execution'][key],(name,key,'native and job console differ')
        record['originalNativeLogSHA256']=digest(native_log.read_bytes())
        record['nativeAndConsoleAccountingAgree']=True
    recovered=path/'recovered-attachment-reconciliation.json'
    if recovered.exists():
        details=json.loads(recovered.read_text())
        assert details['source']==SHA and details['run']==RUN and details['runAttempt']==1
        for method in details['methods']:
            name_for_events=method['method'].removesuffix('()').replace('/','.')
            expected_status='passed' if method['status']=='Success' else 'failed'
            assert name_for_events in record['execution'][expected_status]
        record['recoveredOriginalData']={'receipt':str(recovered.relative_to(P)),'receiptSHA256':digest(recovered.read_bytes()),'completedSummaries':len(details['methods']),'originalPNGs':len(details['originalPNGs']),'supplementalPNGs':details['recoveredSupplementalPNGs'],'supplementalDisposition':details['supplementalDisposition']}
    report['shards'][name]=record
write('reconciliation.json',report)
print(json.dumps({name:{'status':r['status'],'conclusion':r['conclusion'],'execution':r['execution']['counts'] if r['execution'] else None,'recoveredSupplemental':len(r['captures']['supplemental']) if r['captures'] else None} for name,r in report['shards'].items()},sort_keys=True))
