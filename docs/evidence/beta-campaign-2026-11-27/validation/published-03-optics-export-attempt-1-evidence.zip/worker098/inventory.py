"""Pinned source obligations for the three current remaining UI shards."""
from pathlib import Path
import ast, hashlib, json, re, subprocess

P=Path(__file__).resolve().parent
R=P.parents[2]/'APP1'
SHA='f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
paths=git('ls-tree','-r','--name-only',SHA,'UITests','scripts/native_test_shards.py','.github/workflows/ios-prototype.yml','project.yml').decode().splitlines()
blobs={p:git('show',f'{SHA}:{p}') for p in paths}
mapping={}
for node in ast.parse(blobs['scripts/native_test_shards.py']).body:
    if isinstance(node,ast.Assign):
        for t in node.targets:
            if isinstance(t,ast.Name) and t.id=='SHARDS':mapping=ast.literal_eval(node.value)
classes={}
for path,raw in blobs.items():
    if not path.startswith('UITests/') or not path.endswith('.swift'):continue
    text=raw.decode();methods=re.findall(r'\bfunc\s+(test\w*)\s*\(',text)
    if not methods:continue
    names=re.findall(r'\bclass\s+(\w+)\s*:\s*XCTestCase\b',text)
    assert len(names)==1 and len(methods)==len(set(methods)) and names[0] not in classes,path
    classes[names[0]]={'source':path,'methods':sorted(methods)}
counts={'room-precision':5,'studio-optics':10,'studio-export':19}
shards={name:{'classes':mapping[name],'methods':sorted(f'{cl}.{method}' for cl in mapping[name] for method in classes[cl]['methods'])} for name in counts}
for name,count in counts.items():assert len(shards[name]['methods'])==count
capture_source=blobs['UITests/BetaAccessibilityUITests.swift'].decode()
suffixes=re.findall(r'capture\("([A-Za-z0-9-]+)"',capture_source)
assert len(suffixes)==len(set(suffixes))==8
report={'source':SHA,'run':46004241191,'tree':git('rev-parse',f'{SHA}^{{tree}}').decode().strip(),'shards':shards,'expectedSupplementalCaptureSuffixes':suffixes,'sourceFiles':{p:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in blobs.items()},'limitation':'Source obligations only; no method, attachment or visual acceptance follows from inventory.'}
(P/'source-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'source':SHA,'sourceFiles':len(blobs),'methods':counts,'supplementalCaptureSuffixes':suffixes}))
