"""Verify selected original data and method/attachment references in unfinished xcresult."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, stat, zipfile
import zstandard
from PIL import Image

P=Path(__file__).resolve().parent
def sha(data): return hashlib.sha256(data).hexdigest()
def scalar(text,key,start=0):
    pattern=r'K'+str(len(key))+':'+re.escape(key)+r'\[(?:S\d+:\w+|T\[K2:_nV\d+:\w+\])K2:_vV(\d+):'
    match=re.search(pattern,text[start:])
    assert match,(key,start)
    begin=start+match.end(); end=begin+int(match.group(1))
    assert text[end]==']'
    return text[begin:end]

records=json.loads((P/'recovered-data-receipt.json').read_text())
by_member={r['member']:r for r in records}
with zipfile.ZipFile(P/'full/artifacts/native-results.zip') as z:
    infos=z.infolist(); seen=set()
    assert len(infos)==128 and sum(i.file_size for i in infos)<110_000_000
    for info in infos:
        name=info.filename; path=PurePosixPath(name); mode=info.external_attr>>16
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
        assert name not in seen and str(path)==name.rstrip('/'); seen.add(name)
        assert not stat.S_ISLNK(mode) and not info.flag_bits&1
        assert stat.S_IFMT(mode) in [0,stat.S_IFREG,stat.S_IFDIR]
    assert z.testzip() is None
    for record in records:
        raw=z.read(record['member'])
        assert len(raw)==record['rawBytes'] and sha(raw)==record['rawSHA256']
        if raw.startswith(b'\x28\xb5\x2f\xfd'):
            assert (P/'recovered-data'/Path(record['originalCompressedFile']).name).read_bytes()==raw
            with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw)) as reader: data=reader.read(2_000_001)
            assert len(data)<=2_000_000
        else: data=raw
        assert data==(P/'recovered-data'/Path(record['decodedFile']).name).read_bytes()
        assert len(data)==record['decodedBytes'] and sha(data)==record['decodedSHA256']
        if record['kind']=='png':
            with Image.open(io.BytesIO(data)) as im: im.load(); record['dimensions']=list(im.size)

methods=[]; attachments=[]
for record in records:
    if record['kind']!='txt': continue
    text=(P/'recovered-data'/Path(record['decodedFile']).name).read_text()
    if not text.startswith('[T[K2:_nV17:ActionTestSummary'): continue
    method=scalar(text,'identifier')
    status=scalar(text,'testStatus')
    methods.append({'method':method,'status':status,'metadata':record['decodedFile'],'metadataSHA256':record['decodedSHA256']})
    for match in re.finditer(r'K8:filename\[',text):
        start=match.start(); end=text.find('K8:filename[',start+1)
        section=text[start:end if end>=0 else len(text)]
        name=scalar(section,'name'); filename=scalar(section,'filename')
        refstart=section.index('K10:payloadRef')
        ref=scalar(section,'id',refstart)
        size=int(scalar(section,'payloadSize'))
        uti=scalar(section,'uniformTypeIdentifier')
        item={'method':method,'name':name,'originalFilename':filename,'payloadRef':ref,'payloadBytes':size,'type':uti,'metadata':record['decodedFile']}
        member='NativeTests.xcresult/Data/data.'+ref
        recovered=by_member.get(member)
        if recovered:
            assert recovered['decodedBytes']==size,(name,size,recovered['decodedBytes'])
            item.update({'file':recovered['decodedFile'],'sha256':recovered['decodedSHA256']})
            if uti=='public.png':
                assert recovered['kind']=='png'; item['dimensions']=recovered['dimensions']
        attachments.append(item)

assert len(methods)==13 and len({m['method'] for m in methods})==13
assert sum(m['status']=='Success' for m in methods)==9
assert sum(m['status']=='Failure' for m in methods)==4
pngs=[a for a in attachments if a['type']=='public.png']
assert len(pngs)==4 and all('file' in a for a in pngs)
assert not any(a['name'].startswith('Supplemental-AXXXL-Beta-') for a in pngs)
assert any(a['name']=='Supplemental-AXXXL-Beta-observed-controls' for a in attachments)
receipt={'providerArtifact':15205707883,'source':'f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5','run':46004241191,'runAttempt':1,
         'originalNestedSha256':sha((P/'full/artifacts/native-results.zip').read_bytes()),'nestedCRCAndPathChecks':True,
         'limitation':'Unfinalized xcresult; individual recovered original payloads and completed method summaries do not establish a finalized or passing shard.',
         'methods':methods,'attachments':attachments,'originalPNGs':pngs,'requiredSupplementalPNGs':8,'recoveredSupplementalPNGs':0,
         'supplementalDisposition':'All eight named captures were unreached because BetaAccessibilityUITests failed its title assertion before the first capture. Observed-controls is a text payload, not a PNG.'}
(P/'recovered-attachment-reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'completedMethodSummaries':len(methods),'passed':9,'failed':4,'originalPNGs':len(pngs),'supplementalPNGs':0,'attachments':len(attachments)},sort_keys=True))
