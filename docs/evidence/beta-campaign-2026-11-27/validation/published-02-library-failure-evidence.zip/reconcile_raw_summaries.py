#!/usr/bin/env python3
"""Read retained XCTest objects; never execute their contents.

This derives reviewable JSON from the observed length-prefixed serialization.
Original ZIPs, payloads, and decompressed bytes remain authoritative.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "library-raw/NativeTests.xcresult/Data"
DECODED = ROOT / "decoded-objects"


class Reader:
    def __init__(self, data):
        self.data, self.offset = data, 0

    def read(self, depth=0):
        assert depth < 256
        ch = chr(self.data[self.offset])
        self.offset += 1
        if ch == "[":
            result = []
            while self.data[self.offset] != ord("]"):
                result.append(self.read(depth + 1))
            self.offset += 1
            return result
        if ch == "T":
            return (ch, self.read(depth + 1))
        assert ch in "KVS", (self.offset, ch)
        end = self.data.index(b":", self.offset)
        length = int(self.data[self.offset:end])
        self.offset = end + 1
        value = self.data[self.offset:self.offset + length]
        assert len(value) == length
        self.offset += length
        return ch, value.decode("utf-8")


def simplify(node):
    if isinstance(node, tuple):
        assert node[0] == "V", node[0]
        return node[1]
    assert isinstance(node, list)
    index, kind = 0, None
    if node and isinstance(node[0], tuple) and node[0][0] in ("T", "S"):
        token, descriptor = node[0]
        kind = simplify(descriptor).get("_n") if token == "T" else descriptor
        index = 1
    fields, values = {}, []
    while index < len(node):
        item = node[index]
        if isinstance(item, tuple) and item[0] == "K":
            assert item[1] not in fields
            fields[item[1]] = simplify(node[index + 1])
            index += 2
        else:
            values.append(simplify(item))
            index += 1
    if kind == "Array":
        assert not fields
        return values
    assert not values
    if set(fields) == {"_v"}:
        return fields["_v"]
    return fields


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def main():
    summaries_dir = ROOT / "derived-summaries"
    attachments_dir = ROOT / "mapped-attachments"
    summaries_dir.mkdir(exist_ok=True)
    attachments_dir.mkdir(exist_ok=True)
    manifest, summaries = [], []
    for path in sorted(DECODED.glob("*.bin")):
        raw = path.read_bytes()
        if not raw.startswith(b"[T"):
            continue
        reader = Reader(raw)
        parsed = reader.read()
        assert reader.offset == len(raw), "Unconsumed input"
        summary = simplify(parsed)
        name = summary["name"].removesuffix("()")
        assert name.isidentifier()
        output = summaries_dir / (name + ".json")
        output.write_text(json.dumps(summary, indent=2) + "\n")
        summaries.append({"source_decoded_object": path.name,
                          "source_sha256": hashlib.sha256(raw).hexdigest(),
                          "derived_json": str(output.relative_to(ROOT)),
                          "method": summary["identifier"],
                          "status": summary["testStatus"],
                          "failures": summary.get("failureSummaries", [])})
        for attachment in walk(summary):
            if "payloadRef" not in attachment:
                continue
            object_name = "data." + attachment["payloadRef"]["id"]
            source = DATA / object_name
            assert source.parent == DATA and source.exists()
            payload = source.read_bytes()
            decoded = DECODED / (object_name + ".bin")
            if payload.startswith(b"\x28\xb5\x2f\xfd"):
                payload = decoded.read_bytes()
            assert len(payload) == int(attachment["payloadSize"])
            filename = attachment["filename"]
            assert Path(filename).name == filename and "\\" not in filename
            target = attachments_dir / filename
            if target.exists():
                assert target.read_bytes() == payload
            else:
                target.open("xb").write(payload)
            manifest.append({"method": summary["identifier"],
                             "source_object": object_name,
                             "attachment": attachment,
                             "sha256": hashlib.sha256(payload).hexdigest(),
                             "local_file": str(target.relative_to(ROOT))})
    (ROOT / "derived-summary-receipt.json").write_text(json.dumps(summaries, indent=2) + "\n")
    (ROOT / "mapped-attachments-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    for item in summaries:
        print(item["method"], item["status"])
        for failure in item["failures"]:
            print("  failure:", failure["message"], "caller", failure["lineNumber"])
            for frame in failure["sourceCodeContext"]["callStack"]:
                if "symbolInfo" in frame:
                    print("  symbol:", json.dumps(frame["symbolInfo"]))
    print("Validated and mapped", len(manifest), "attachment payloads")


if __name__ == "__main__":
    main()
