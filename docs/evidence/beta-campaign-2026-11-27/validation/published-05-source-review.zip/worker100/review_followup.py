#!/usr/bin/env python3
"""Read existing evidence only; never executes builds, tests, CI or mutations."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/4633a14a0d5b')
REPO = ROOT / 'APP1'
OUT = ROOT / 'campaign/evidence/100'
SOURCE = 'f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'

def read_json(path):
    return json.loads((ROOT / path).read_text())

def digest(path):
    p = ROOT / path
    return {'path': path, 'bytes': p.stat().st_size,
            'sha256': sha256(p.read_bytes()).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

initial = read_json('campaign/evidence/100/readiness-review.json')
paths = initial['verifiedSourcePaths']
changed_inputs = [p for p in paths
                  if (REPO / p).read_bytes() != git('show', f'{SOURCE}:{p}')]
assert not changed_inputs, changed_inputs
head = git('rev-parse', 'HEAD').decode().strip()
changed_since_source = git('diff', '--name-only', SOURCE, head).decode().splitlines()

inventory = read_json('campaign/evidence/098/source-inventory.json')
assert inventory['source'] == SOURCE
expected = inventory['shards']['studio-export']['methods']
log_path = 'campaign/evidence/098/studio-export/full/native-tests.log'
raw_log = (ROOT / log_path).read_bytes()
events = {method: [] for method in expected}
pattern = re.compile(r"^Test Case '-\[KeyAndFillUITests\.(\w+) (\w+)\]' (started|passed|failed|skipped)(?:\.| \()")
for lineno, line in enumerate(raw_log.decode().splitlines(), 1):
    found = pattern.match(line)
    if found:
        method = f'{found[1]}.{found[2]}'
        assert method in events, method
        events[method].append({'event': found[3], 'line': lineno, 'text': line})

outcomes = {}
for method, method_events in events.items():
    sequence = [event['event'] for event in method_events]
    if not sequence:
        outcomes[method] = 'unstarted'
    elif sequence == ['started']:
        outcomes[method] = 'incomplete'
    elif len(sequence) == 2 and sequence[0] == 'started' and sequence[1] in ('passed', 'failed', 'skipped'):
        outcomes[method] = sequence[1]
    else:
        raise AssertionError((method, sequence))
counts = dict(Counter(outcomes.values()))
assert counts == {'passed': 9, 'failed': 4, 'incomplete': 1, 'unstarted': 5}, counts
smoke = 'StudioSmokeTests.testCorruptProjectBlocksSavingAcrossRelaunch'
assert outcomes[smoke] == 'passed'

metadata_path = 'campaign/evidence/098/studio-export/full-metadata.json'
metadata = read_json(metadata_path)
archive_path = 'campaign/evidence/098/studio-export/full-original.zip'
archive = digest(archive_path)
assert metadata['workflow_run']['head_sha'] == SOURCE
assert metadata['workflow_run']['id'] == 46004241191
assert metadata['size_in_bytes'] == archive['bytes']
assert metadata['digest'] == 'sha256:' + archive['sha256']
with zipfile.ZipFile(ROOT / archive_path) as original:
    log_members = [name for name in original.namelist() if name.endswith('native-tests.log')]
    assert len(log_members) == 1, log_members
    assert original.read(log_members[0]) == raw_log

receipt_paths = [
    'campaign/evidence/089/receipt.json',
    'campaign/evidence/089/native-reconciliation.json',
    'campaign/evidence/089/device-reconciliation.json',
    'campaign/evidence/095/reconciliation.json',
    'campaign/evidence/097/reconciliation.json',
    'campaign/evidence/098/source-inventory.json',
    'campaign/evidence/098/reconciliation.json',
    metadata_path,
]
result = {
    'worker': '/root/a100_independent_beta_readiness',
    'checkpointUTC': datetime.now(timezone.utc).isoformat(),
    'status': 'interim addendum complete; final runtime and root-summary delta outstanding',
    'scope': 'Independent existing-evidence review only; no tests, builds, reruns, source changes or artifact deletion.',
    'sourceRevision': SOURCE,
    'documentationHead': head,
    'unchangedSourceInputsVerified': len(paths),
    'changedSourceInputs': changed_inputs,
    'changedPathsSinceSource': changed_since_source,
    'reviewedReceiptHashes': [digest(path) for path in receipt_paths],
    'documentationHashes': [digest('APP1/docs/PRIVACY.md'), digest('APP1/docs/BETA_TESTER_GUIDE.md')],
    'exportPartialEvidence': {
        'run': 46004241191, 'attempt': 1, 'job': 140527590003,
        'artifact': {**archive, 'id': metadata['id'], 'providerMetadata': metadata_path,
                     'providerDigestVerified': True, 'sourceMetadataVerified': True},
        'rawLog': {**digest(log_path), 'matchesOriginalArchiveMember': log_members[0]},
        'expected': len(expected), 'started': sum(bool(v) for v in events.values()),
        'counts': counts, 'outcomes': outcomes, 'events': events,
        'corruptSmoke': {'method': smoke, 'status': 'passed', 'events': events[smoke],
                         'meaning': 'Protected status and disabled Save verified before and after relaunch without regenerating the corrupt fixture.'},
        'limit': 'The complete xcodebuild command timed out and its xcresult did not finalize. Individual terminal passes are real; they are not a successful full UI run.'
    },
    'gateInterpretation': {
        'M01': 'Narrow revalidation supported by current core/native, finalized library save/relaunch, and byte/provenance-verified corrupt-file smoke pass. QUALITY persistence_smoke does not require all 19 M03 studio-export methods or a finalized studio-export suite. Do not invent those as additional M01 conditions.',
        'M02': 'After M01 dependency is recorded, current photometry/rendering/performance evidence supports revalidation. Native089 final normal-exit/result/device receipts are now complete; the initial report qualifier awaiting them is superseded.',
        'M03': 'No-go: explicit v2 selected-command, required-method and finalized-result requirements remain unsatisfied. Required app accessibility and room checks failed; optics started zero of ten; export has four failures, one incomplete and five unstarted; original capture coverage is incomplete.',
        'M04-M07': 'Unchanged external, physical, commercial, customer, privacy, release-review and owner-approval obligations remain pending.',
        'release': 'No accepted or distributed beta is established.'
    },
    'retryInterpretation': {
        'boundedRetry': 'One unchanged retry can provide another observation when a host-failure hypothesis is supported. Preserve attempt1 with exact source, run attempt, method outcomes, job/artifact IDs and hashes; a later pass does not establish a code repair or host-only cause.',
        'newEvidenceChangesNextAction': 'Root reports feedback text entry remained empty on a third runner; BetaAX measurement observer and recovery identifier findings now justify targeted diagnosis/repair before deciding to retry. Do not blindly repeat the old hypothesis or relax assertions/deadlines.',
        'artifactBehavior': 'Actual upload-artifact v4.6.2 source deletes an existing artifact only when overwrite is requested. Current official toolkit documentation explicitly recognizes same-name artifacts on reruns; current getArtifact source chooses newest ID among duplicate matches. This supports expected coexistence, but does not prove this service run will preserve every old artifact or that its pinned toolkit version has identical handling.',
        'minimalHandling': 'Preserve all attempt1 originals and IDs. Use standard authorized rerun only after root chooses it; inspect actual new upload IDs/digests and conflicts. Do not delete or overwrite originals. Name-only download is insufficient proof of attempt identity.',
        'officialSources': [
            'https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs',
            'https://github.com/actions/upload-artifact/blob/ea165f8d65b6e75b540449e92b4886f43607fa02/src/upload/upload-artifact.ts',
            'https://github.com/actions/upload-artifact/blob/ea165f8d65b6e75b540449e92b4886f43607fa02/package.json',
            'https://github.com/actions/toolkit/blob/main/packages/artifact/src/internal/client.ts',
            'https://github.com/actions/toolkit/blob/main/packages/artifact/src/internal/find/get-artifact.ts'
        ]
    },
    'distribution': {
        'current': 'Unsigned simulator artifacts and arm64 device cross-build only; no signed archive, actual device execution, TestFlight or owner distribution approval.',
        'availableAuthorizedWork': 'Complete software verification, preserve failures, make evidence-driven repairs, and prepare accurate tester/privacy/release materials.',
        'missingConcreteOwnerInputs': 'Selected bundle identity and Apple team/app record/access, tester scope, feedback/privacy contacts, required release decisions and distribution approval. Existing account status is unknown; no absent-account assumption.',
        'notAuthorizedByThisReview': 'No account probing, enrollment/payment, invented team or identifier, product/pricing activation, tester invitations or distribution.'
    },
    'documentationReview': 'Current privacy disclosure matches 093 source findings; tester guide correctly says Required UI acceptance remains pending and describes an engineering candidate. No false native/device/beta-distribution acceptance claim identified. Earlier 19-link check retained in initial receipt.',
    'pending': 'Review justified patch/new source and final CI evidence, then independently review root final summary. This same worker identity remains available; no additional worker is implied.'
}
(OUT / 'followup-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT / 'followup-review.json'),
                  'sha256': sha256((OUT / 'followup-review.json').read_bytes()).hexdigest(),
                  'head': head, 'verifiedInputs': len(paths), 'exportCounts': counts,
                  'providerArchiveVerified': True}, indent=2))
