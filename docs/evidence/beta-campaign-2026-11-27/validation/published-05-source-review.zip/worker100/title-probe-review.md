# Worker 100 — independent candidate 061 addendum

**Candidate:** `84ade7af5f8563d43d31b1e83931f58af4644821`, directly atop `f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5`. **Decision:** no source-level blocker; approve integration as a measurement correction, with actual Apple execution still required. No source edits, tests, builds, reruns or descendants.

The exact diff changes only `App/StudioWelcomeView.swift` and `UITests/BetaAccessibilityUITests.swift`. The existing helper is `App/StudioTextLayoutDiagnostics.swift`, unchanged by this candidate. The new probe attaches after the title's actual font and `fixedSize`, before its expanding frame and ancestor padding. Its background GeometryReader records that Text's global rectangle; it does not measure a padded card or duplicate the label. Release builds and launches without both explicit test switches return the original view. Font, spacing, production layout and visible content are unchanged.

The test obtains the identified static Text, checks its exact label, and reads the tagged geometry from that same snapshot's value. The decoder requires the exact protocol kind and probe identity, bounded input, and finite nonempty geometry; pending/malformed data cannot pass. Both semantic and recorded rectangles must lie inside the target's observed viewport. The expected largest-category `.title3` semibold font and pixel-normalized measurement width remain. The acceptance equation is still **rounded observed physical height ≥ ceiling of required physical height**, with no tolerance or threshold reduction.

All eight original supplemental capture names occur once and remain unchanged. Moving `Welcome-heading` before the assertion preserves reached output on failure; emitting an image is not a layout pass. These supplemental names do not replace the mandatory 28 app-layout originals. Logging now retains both AX and actual Text observations.

I verified the retained metric, original recording and derivative hashes and viewed the derivative: the complete three-line title is visible. This supports investigating the AX-versus-intrinsic-layout distinction but does not establish the intrinsic frame or erase the original **587 < 591** failure. The viewed PNG is video-derived, not an original XCTest attachment.

Required next evidence: compile and run the candidate on the actual Apple environment; receive the tagged current title geometry, retain both measurements, satisfy the unchanged pixel assertion, finish required workflows normally, and retain finalized results and genuine original captures. Existing helper tests are relevant prior evidence, not execution of this new title wiring.

Machine-readable details: `title-probe-review.json`. Final readiness/runtime and root-summary review remain outstanding on the same worker 100 identity.
