import Foundation

@main
struct RecorderWitness {
    @MainActor
    static func main() throws {
        let state = StudioTextInputTrace.State(
            configured: true, enabled: true, firstResponder: false, inWindow: false,
            markedText: false, applyingConfiguration: false, replacingText: false,
            synchronizingFocus: false, nativeUTF16: 257, modelUTF16: 3,
            bindingUTF16: 3, replacementUTF16: 257, bindingMatchesNative: false,
            requestedFocus: nil, rangeLocation: 0, rangeLength: 0)
        let lifecycle = UUID()
        let prefix = "KEYFILL_INPUT_TRACE_V1 "
        func decode(_ lines: [String]) throws -> [[String: Any]] {
            try lines.map { line in
                precondition(line.hasPrefix(prefix))
                return try JSONSerialization.jsonObject(with: Data(line.dropFirst(prefix.count).utf8)) as! [String: Any]
            }
        }
        var lines: [String] = []
        var collected = 0
        let recorder = StudioTextInputTrace(isEnabled: true, sink: { lines.append($0) })
        let first = recorder.makeControlID(), second = recorder.makeControlID(), third = recorder.makeControlID()
        for control in [first, second, third] {
            for _ in 0..<600 {
                recorder.record(control: control, lifecycle: lifecycle, identifier: "PRIVATE-001-CANARY-e\u{0301}-\u{1F511}",
                                event: .editingChanged) { collected += 1; return state }
            }
        }
        let records = try decode(lines)
        precondition(records.count == 512)
        precondition(collected == 510)
        precondition(!recorder.canRecord(control: first))
        precondition(!recorder.canRecord(control: third))
        precondition(records.filter { $0["control"] as? Int == first }.count == 256)
        precondition(records.filter { $0["control"] as? Int == second }.count == 256)
        precondition(records.filter { $0["control"] as? Int == third }.isEmpty)
        precondition(records.compactMap { $0["sequence"] as? Int } == Array(1...512))
        precondition(records.filter { $0["event"] as? String == "controlLimit" }.count == 1)
        precondition(records.filter { $0["event"] as? String == "processLimit" }.count == 1)
        precondition(records.last?["event"] as? String == "processLimit")
        precondition(records.last?["state"] == nil)
        precondition(records.allSatisfy { $0["field"] as? String == "other" })
        precondition(!lines.joined().contains("PRIVATE-001-CANARY"))
        let allowed = Set(["version", "sequence", "control", "lifecycle", "uptime", "epochSeconds", "field", "event", "state"])
        precondition(records.allSatisfy { Set($0.keys).isSubset(of: allowed) })

        var disabledLines: [String] = []
        var disabledCollected = 0
        let disabled = StudioTextInputTrace(isEnabled: false, sink: { disabledLines.append($0) })
        for _ in 0..<1000 {
            disabled.record(control: 1, lifecycle: lifecycle, identifier: "precisionValue", event: .delegateEdit) { disabledCollected += 1; return state }
        }
        precondition(disabledLines.isEmpty)
        precondition(disabledCollected == 0)

        var spreadLines: [String] = []
        var spreadCollected = 0
        let spread = StudioTextInputTrace(isEnabled: true, sink: { spreadLines.append($0) })
        for _ in 0..<600 {
            let control = spread.makeControlID()
            spread.record(control: control, lifecycle: lifecycle, identifier: "precisionValue", event: .delegateEdit) { spreadCollected += 1; return state }
        }
        let spreadRecords = try decode(spreadLines)
        precondition(spreadRecords.count == 512)
        precondition(spreadCollected == 511)
        precondition(spreadRecords.last?["event"] as? String == "processLimit")
        precondition(spreadRecords.filter { $0["event"] as? String == "controlLimit" }.isEmpty)
        print("PASS: exact recorder compiled; process/control marker caps, distributed-control cap, disabled output, unknown-identifier redaction schema, and lazy-provider witness")
    }
}
