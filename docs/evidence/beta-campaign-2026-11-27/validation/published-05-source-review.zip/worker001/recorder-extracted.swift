import Foundation

#if DEBUG
/// Opt-in process diagnostics for real input-delivery failures. The full
/// xcresult retains app stdout; compact screenshot attachments alone do not.
/// No raw draft, replacement, label, hint, name or device identifier is stored.
@MainActor
final class StudioTextInputTrace {
    static let environmentKey = "KEYFILL_UI_TEXT_INPUT_TRACE"
    static let shared = StudioTextInputTrace(
        isEnabled: ProcessInfo.processInfo.environment[environmentKey] == "1")
    static let maximumProcessRecords = 512
    static let maximumControlRecords = 256
    let isEnabled: Bool

    enum Event: String, Encodable {
        case identityChange, configureInitialValue, configureExternalReset, keyboardConfigurationChanged, enabledChanged
        case invalidate, windowChanged, delegateEdit, delegateEditIgnored, delegateEditAccepted
        case focusBegan, focusBeganIgnored, focusBindingTrue, focusEnded, focusEndedIgnored
        case focusEndWriteIgnored, focusBindingFalse, submit, submitIgnored, submitLifecycleChanged
        case editingChanged, publishIgnored, publishBegin, publishExternalReset, publishUnchanged
        case bindingWrite, bindingReadback, publishLifecycleChanged, replaceNativeText
        case focusLifecycleChanged, focusRequestUnconfigured, focusRequest, focusMissingWindow, focusResult
        case controlLimit, processLimit
    }

    struct State: Encodable {
        let configured, enabled, firstResponder, inWindow, markedText: Bool
        let applyingConfiguration, replacingText, synchronizingFocus: Bool
        let nativeUTF16, modelUTF16, bindingUTF16, replacementUTF16: Int?
        let bindingMatchesNative, requestedFocus: Bool?
        let rangeLocation, rangeLength: Int?
    }

    private struct Record: Encodable {
        let version = 1
        let sequence, control: Int
        let lifecycle: UUID
        let uptime, epochSeconds: TimeInterval
        let field: String
        let event: Event
        let state: State?
    }

    private var nextControl = 0
    private var processCount = 0
    private var controlCounts: [Int: Int] = [:]
    private let sink: (String) -> Void

    init(isEnabled: Bool, sink: @escaping (String) -> Void = { print($0) }) {
        self.isEnabled = isEnabled
        self.sink = sink
    }

    func makeControlID() -> Int {
        nextControl += 1
        return nextControl
    }

    func canRecord(control: Int) -> Bool {
        isEnabled && processCount < Self.maximumProcessRecords &&
            controlCounts[control, default: 0] < Self.maximumControlRecords
    }

    func record(control: Int, lifecycle: UUID, identifier: String?, event: Event, state: () -> State) {
        guard canRecord(control: control) else { return }
        let count = controlCounts[control, default: 0]
        // Limits include their one terminal marker. After either marker, no
        // additional record for that budget is encoded or emitted.
        let emitted: Event
        if processCount == Self.maximumProcessRecords - 1 { emitted = .processLimit }
        else if count == Self.maximumControlRecords - 1 { emitted = .controlLimit }
        else { emitted = event }
        processCount += 1
        controlCounts[control] = count + 1
        let record = Record(sequence: processCount, control: control, lifecycle: lifecycle,
                            uptime: ProcessInfo.processInfo.systemUptime,
                            epochSeconds: Date().timeIntervalSince1970,
                            field: Self.fieldName(identifier), event: emitted,
                            state: emitted == .processLimit || emitted == .controlLimit ? nil : state())
        guard let data = try? JSONEncoder().encode(record), let line = String(data: data, encoding: .utf8) else { return }
        sink("KEYFILL_INPUT_TRACE_V1 " + line)
    }

    private static func fieldName(_ identifier: String?) -> String {
        // A private canary in an unexpected identifier must not become output.
        switch identifier {
        case "precisionValue", "projectNameInput", "roomWidth", "roomDepth", "roomHeight",
             "roomSubjectX", "roomSubjectZ", "targetLuxInput": return identifier!
        default: return "other"
        }
    }
}
#endif
