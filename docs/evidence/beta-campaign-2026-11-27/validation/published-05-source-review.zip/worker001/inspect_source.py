from pathlib import Path
import subprocess, re, json, hashlib
root = Path('/workspace/scratch/4633a14a0d5b/worktrees/096')
out = Path('/workspace/scratch/4633a14a0d5b/campaign/evidence/001/followup')
source = (root/'App/StudioTextField.swift').read_text()
start = source.index('#if DEBUG\n/// Opt-in process diagnostics')
(out/'recorder-extracted.swift').write_text('import Foundation\n\n' + source[start:])
base = subprocess.check_output(['git','show','f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5:App/StudioTextField.swift'], cwd=root, text=True)
def release(s):
    result=[]; depth=0
    for line in s.splitlines():
        if line.strip() == '#if DEBUG': depth += 1; continue
        if depth and line.strip() == '#endif': depth -= 1; continue
        assert not depth or not line.lstrip().startswith(('#if ', '#else', '#elseif')), 'Unsupported nested directive'
        if not depth: result.append(line)
    assert depth == 0
    return '\n'.join(result)
stripped=release(source)
(out/'release-stripped.swift').write_text(stripped)
assert all(x not in stripped for x in ['StudioTextInputTrace','KEYFILL_INPUT_TRACE','inputTrace','trace(.'])
def tokens(s):
    s = re.sub(r'//[^\n]*','',s)
    s = re.sub(r'/\*.*?\*/','',s, flags=re.S)
    # Equivalent guard split permits a diagnostic event only in the second failure branch.
    s=s.replace('guard let self, token == self.lifecycle else { return }', 'guard let self else { return }\nguard token == self.lifecycle else { return }')
    return [x for x in re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_]\w*|\d+|[^\s]',s) if x != ';']
comparison = tokens(base)==tokens(stripped)
if not comparison:
    import difflib
    (out/'release-token-diff.txt').write_text('\n'.join(difflib.unified_diff(tokens(base),tokens(stripped))))
files=['App/StudioTextField.swift','NativeTests/StudioTextFieldTests.swift','UITests/BetaWorkflowUITests.swift','UITests/ManualRoomPlacementUITests.swift','UITests/StudioAppAccessibilityUITests.swift']
result={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'status':subprocess.check_output(['git','status','--short'],cwd=root,text=True).strip(),
        'release_trace_tokens_absent':True,
        'release_semantic_tokens_identical_after_equivalent_guard_split':comparison,
        'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}}
(out/'source-inspection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
