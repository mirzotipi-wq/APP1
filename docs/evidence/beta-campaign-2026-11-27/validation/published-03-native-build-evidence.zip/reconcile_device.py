#!/usr/bin/env python3
"""Verify the retained device compiler/lipo outputs and actual copied plist."""
import hashlib,json,plistlib,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
D=OUT/'device'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
info=plistlib.loads((D/'Info.plist').read_bytes())
check=json.loads((D/'bundle-check.log').read_text())
expected={'CFBundleExecutable':'KeyAndFill','CFBundlePackageType':'APPL','CFBundleSupportedPlatforms':['iPhoneOS'],'DTPlatformName':'iphoneos','DTSDKName':'iphoneos26.5'}
for key,value in expected.items():assert info.get(key)==value and check['bundle'][key]==value,(key,info.get(key))
assert check['architectures']==['arm64'] and check['configuration']=='Release' and check['deviceExecution'] is False
text=(D/'build.log').read_text(errors='replace');lines=text.splitlines()
command=next(s for s in lines if re.search(r'^\s*/Applications/.*/xcodebuild ',s))
for required in ('-configuration Release','-sdk iphoneos','-destination generic/platform=iOS','ARCHS=arm64','ONLY_ACTIVE_ARCH=NO','CODE_SIGNING_ALLOWED=NO'):assert required in command,required
assert '** BUILD SUCCEEDED **' in lines
assert not any(' error:' in s or s.startswith('error:') for s in lines)
targets=sorted(set(re.findall(r'-target (\w+-apple-\S+)',text)))
assert 'arm64-apple-ios17.0' in targets and not any('simulator' in x for x in targets)
compile_hits=[{'line':i,'text':s} for i,s in enumerate(lines,1) if s.startswith('SwiftCompile normal arm64')]
assert compile_hits
for name in ('RealityStudioPreview.swift','ARPlacementController.swift'):
    assert any(name in hit['text'] for hit in compile_hits),name
link_hits=[{'line':i,'text':s,'actual_link_command':lines[i+1]} for i,s in enumerate(lines,1) if s.startswith('Ld ') and 'Release-iphoneos/KeyAndFill.app/KeyAndFill' in s]
assert len(link_hits)==1
assert '-target arm64-apple-ios17.0' in link_hits[0]['actual_link_command']
assert '/iPhoneOS26.5.sdk' in link_hits[0]['actual_link_command']
assert (D/'plist.log').read_text().rstrip().endswith(': OK')
assert "['iPhoneOS']; iOS 17.0" in (D/'icon.log').read_text()
assert 'Verified app bundle privacy manifest:' in (D/'privacy.log').read_text()
env=(D/'environment.log').read_text();assert env.splitlines()[0]=='f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
result={'schema':1,'source_revision':env.splitlines()[0],'artifact_id':15203886241,'status':'passed','build_command':command.strip(),'build_success_line':lines.index('** BUILD SUCCEEDED **')+1,'observed_compiler_targets':targets,'observed_sdk_path':'/Applications/Xcode_26.6.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk','arm64_compile_operations':len(compile_hits),'required_device_branch_sources_observed':['RealityStudioPreview.swift','ARPlacementController.swift'],'link_operations':link_hits,'actual_copied_info':info,'actual_bundle_check_output':check,'plist_lint_passed':True,'icon_check_passed':True,'privacy_check_passed':True,'logs':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in D.iterdir() if p.is_file()},'architecture_evidence':'Actual runner lipo result plus arm64-apple-ios17.0 compile and link output; executable itself is not included in this workflow artifact.','physical_device_execution':False}
(OUT/'device-reconciliation.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ['status','build_command','observed_compiler_targets','arm64_compile_operations','required_device_branch_sources_observed','actual_bundle_check_output']},indent=2))
