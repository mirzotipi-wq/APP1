#!/usr/bin/env python3
"""Independent bounded archive checks; never executes artifact contents."""
import argparse, hashlib, json, os, plistlib, stat, struct, zipfile
from pathlib import Path, PurePosixPath

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def safe_unpack(path, destination, max_bytes=2*1024**3):
    destination.mkdir(parents=True, exist_ok=True)
    destination = destination.resolve()
    entries=[]
    with zipfile.ZipFile(path) as z:
        infos=z.infolist()
        if len(infos)>100000 or sum(i.file_size for i in infos)>max_bytes:
            raise ValueError('archive exceeds inspection bounds')
        seen=set()
        for i in infos:
            name=PurePosixPath(i.filename)
            mode=(i.external_attr>>16)&0xffff
            if name.is_absolute() or '..' in name.parts or '\\' in i.filename or stat.S_ISLNK(mode):
                raise ValueError('unsafe archive member: '+i.filename)
            if i.filename in seen:
                raise ValueError('duplicate archive member: '+i.filename)
            seen.add(i.filename)
            target=(destination / str(name)).resolve()
            if not target.is_relative_to(destination):
                raise ValueError('archive escape: '+i.filename)
            if i.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            h=hashlib.sha256()
            with z.open(i) as src, target.open('wb') as dst:
                for data in iter(lambda:src.read(1024*1024),b''):
                    dst.write(data); h.update(data)
            entries.append({'path':str(name),'bytes':i.file_size,'sha256':h.hexdigest()})
        corrupt=z.testzip()
        if corrupt:
            raise ValueError('CRC mismatch: '+corrupt)
    return {'archive':str(path),'sha256':digest(path),'bytes':path.stat().st_size,
            'safe_paths':True,'symlinks':False,'crc_valid':True,'files':entries}

def version(value):
    return f'{value>>16}.{(value>>8)&255}.{value&255}'

def macho(path):
    return macho_data(path.read_bytes())

def macho_data(data):
    if data[:4] in (b'\xca\xfe\xba\xbe',b'\xca\xfe\xba\xbf'):
        wide=data[:4]==b'\xca\xfe\xba\xbf'
        count=struct.unpack_from('>I',data,4)[0]
        if not 0<count<100:raise ValueError('invalid universal Mach-O slice count')
        slices=[]
        for index in range(count):
            if wide:
                cpu,subtype,offset,size,alignment,reserved=struct.unpack_from('>IIQQII',data,8+index*32)
            else:
                cpu,subtype,offset,size,alignment=struct.unpack_from('>5I',data,8+index*20)
            if offset+size>len(data):raise ValueError('universal Mach-O slice exceeds file')
            parsed=macho_data(data[offset:offset+size])
            if parsed.get('cpu_type')!=cpu:raise ValueError('universal header CPU mismatches slice')
            slices.append({'offset':offset,'size':size,'alignment':alignment,'binary':parsed})
        return {'format':'universal Mach-O','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                'architectures':[s['binary']['architecture'] for s in slices],'slices':slices}
    if data[:4] not in (b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe'):
        return {'format':'unhandled','magic':data[:4].hex(),'sha256':hashlib.sha256(data).hexdigest()}
    is64=data[:4]==b'\xcf\xfa\xed\xfe'
    cpu, subtype, filetype,ncmds,sizeofcmds,flags=struct.unpack_from('<6I',data,4)
    cursor=32 if is64 else 28
    if cursor+sizeofcmds>len(data): raise ValueError('truncated Mach-O load commands')
    build_versions=[]; signatures=[]
    for _ in range(ncmds):
        cmd,size=struct.unpack_from('<2I',data,cursor)
        if size<8 or cursor+size>len(data): raise ValueError('bad Mach-O load command size')
        if cmd==0x32:
            platform, minos,sdk,ntools=struct.unpack_from('<4I',data,cursor+8)
            build_versions.append({'platform':platform,'minimum_os':version(minos),'sdk':version(sdk)})
        if cmd==0x1d: signatures.append(struct.unpack_from('<2I',data,cursor+8))
        cursor+=size
    return {'format':'Mach-O 64' if is64 else 'Mach-O 32','cpu_type':cpu,
            'architecture':{0x1000007:'x86_64',0x100000c:'arm64',7:'i386',12:'arm'}.get(cpu,str(cpu)),
            'cpu_subtype':subtype,'file_type':filetype,'build_versions':build_versions,
            'code_signature_load_commands':signatures,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def inspect_bundle(bundle):
    info=plistlib.loads((bundle/'Info.plist').read_bytes())
    selected={k:info.get(k) for k in ('CFBundleExecutable','CFBundleIdentifier','CFBundlePackageType',
        'CFBundleSupportedPlatforms','DTPlatformName','DTPlatformVersion','DTSDKName','DTSDKBuild',
        'DTXcode','DTXcodeBuild','MinimumOSVersion','CFBundleIcons','CFBundleIcons~ipad')}
    binaries={}
    for path in [bundle/info['CFBundleExecutable'],*bundle.glob('*.dylib')]:
        binaries[path.name]=macho(path)
    privacy=bundle/'PrivacyInfo.xcprivacy'
    return {'bundle':str(bundle),'info':selected,'binaries':binaries,
            'privacy':plistlib.loads(privacy.read_bytes()) if privacy.exists() else None,
            'code_resources_present':(bundle/'_CodeSignature'/'CodeResources').exists()}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('destination',type=Path)
    p.add_argument('--expected-sha256');p.add_argument('--receipt',type=Path);args=p.parse_args()
    if args.expected_sha256 and digest(args.archive)!=args.expected_sha256.removeprefix('sha256:'):
        raise SystemExit('Provider SHA-256 mismatch')
    receipt=safe_unpack(args.archive,args.destination)
    receipt['provider_digest_verified']=bool(args.expected_sha256)
    receipt['nested_archives']=[]
    for nested in sorted(args.destination.rglob('*.zip')):
        receipt['nested_archives'].append(safe_unpack(nested,nested.parent/(nested.stem+'-contents')))
    receipt['bundles']=[inspect_bundle(b) for b in sorted(args.destination.rglob('KeyAndFill.app')) if b.is_dir()]
    if args.receipt:args.receipt.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archive':str(args.archive),'safe_paths':receipt['safe_paths'],
                     'provider_digest_verified':receipt['provider_digest_verified'],
                     'bundles':receipt['bundles'],'files':len(receipt['files'])},indent=2))
