#!/usr/bin/env python3
"""Inventory exact Git inputs; counts here are requirements, not test outcomes."""
import datetime, hashlib, json, re, subprocess
from pathlib import Path

REPO=Path('/workspace/scratch/4633a14a0d5b/APP1')
OUT=REPO.parent/'campaign/evidence/089'
SHA='f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
assert git('rev-parse',SHA).decode().strip()==SHA
entries=git('ls-tree','-r',SHA).decode().splitlines()
manifest=[];native=[];domain=[];copies=[]
prefixes=('App/','Sources/','NativeTests/','UITests/','Tests/','Resources/','scripts/','.github/workflows/')
copy_exact={'Package.swift','project.yml','.github/workflows/ios-prototype.yml','scripts/native_test_shards.py','scripts/ensure-metal-toolchain.sh','scripts/verify_app_icon.py','scripts/verify_privacy_manifest.py','Resources/PrivacyInfo.xcprivacy'}
package=git('show',SHA+':Package.swift').decode()
composition_part=package.split('.testTarget(name: "StudioCompositionTests"',1)[1]
composition_files=re.findall(r'"([^"\n]+\.swift)"',composition_part.split('sources: [',1)[1])
for entry in entries:
    meta,name=entry.split('\t',1)
    mode,kind,obj=meta.split()
    if kind!='blob' or not (name.startswith(prefixes) or name in {'Package.swift','Package.resolved','project.yml'}):continue
    data=git('show',SHA+':'+name)
    manifest.append({'path':name,'git_blob':obj,'git_mode':mode,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    if name.startswith('NativeTests/') or name in copy_exact:
        p=OUT/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);copies.append(name)
    if name.endswith('.swift') and name.startswith(('NativeTests/','Tests/')):
        text=data.decode();classes=re.findall(r'\bclass\s+(\w+)\s*:\s*XCTestCase\b',text)
        methods=re.findall(r'\bfunc\s+(test\w*)\s*\(',text)
        if not methods:continue
        if len(classes)!=1 or len(methods)!=len(set(methods)):raise SystemExit('ambiguous: '+name)
        group=native if name.startswith('NativeTests/') else domain
        group.append({'path':name,'class':classes[0],'methods':sorted(methods),'count':len(methods)})
composition=[c for c in native if Path(c['path']).name in composition_files]
assert len(composition)==len(composition_files)
portable=domain+composition
required=['StudyRendererTests.testMetalMatchesCPUOnAvailableDevice','StudyRendererTests.testNearFieldRoutingDoesNotPermanentlyDowngradeValidatedMetal','StudyRendererTests.testCancelledInitialParityValidationCanRetryMetalOnSameEngine']
all_native=sorted(c['class']+'.'+m for c in native for m in c['methods'])
assert len(all_native)==len(set(all_native))==323
assert set(required)<=set(all_native)
assert sum(c['count'] for c in domain)==502
assert sum(c['count'] for c in composition)==89
assert sum(c['count'] for c in portable)==591
darwin_only=next(c for c in composition if c['class']=='StudioObservationTests')
assert darwin_only['count']==3
assert (OUT/'source/NativeTests/StudioObservationTests.swift').read_text().startswith('#if canImport(Darwin)\n')
receipt={'schema':1,'agent':'/root/a089_current_native_gate','source_revision':SHA,'run_id':46004241191,'simulator_job_id':140527589857,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_tree':git('rev-parse',SHA+'^{tree}').decode().strip(),'manifest':manifest,'copied_source_files':copies,'native':{'count':len(all_native),'classes':native,'methods':all_native,'required_metal_methods':required},'portable':{'source_declared_count':591,'macos_expected_count':591,'linux_expected_count':588,'domain_count':502,'macos_composition_count':89,'linux_composition_count':86,'darwin_only_class':darwin_only,'classes':portable},'observations':{'source_inventory_is_execution_evidence':False,'local_builds_run':False}}
(OUT/'source-inventory.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'source_revision':SHA,'source_files':len(manifest),'native_classes':len(native),'native_methods':len(all_native),'portable_methods':sum(c['count'] for c in portable),'inventory_sha256':hashlib.sha256((OUT/'source-inventory.json').read_bytes()).hexdigest()},indent=2))
