#!/usr/bin/env python3
"""Independently reconcile retained actual XCTest logs with pinned source."""
import argparse, collections, hashlib, importlib.util, json, plistlib, re
from pathlib import Path

HERE=Path(__file__).resolve().parent
EVENT=re.compile(r"Test Case '-\[(?P<target>\w+)\.(?P<class>\w+) (?P<method>test\w+)\]' (?P<event>\w+)(?: \((?P<seconds>\d+(?:\.\d+)?) seconds\))?\.?\s*$")

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def reconcile(path, expected):
    text=path.read_text(errors='replace')
    events={key:[] for key in expected};foreign=[];malformed=[]
    for line_no,line in enumerate(text.splitlines(),1):
        if 'Test Case' not in line:continue
        match=EVENT.search(line)
        if match is None:
            malformed.append({'line':line_no,'text':line});continue
        key=match['target']+'.'+match['class']+'.'+match['method']
        event={'event':match['event'],'line':line_no,'seconds':float(match['seconds']) if match['seconds'] else None}
        if key not in events:foreign.append({'method':key,**event})
        else:events[key].append(event)
    counts={'expected':len(expected),'started':0,'passed':0,'failed':0,'skipped':0,'unstarted':0,'incomplete':0,'invalid_sequences':0}
    methods={}
    for key,sequence in events.items():
        names=[x['event'] for x in sequence]
        for label in ('started','failed','skipped'):
            counts[label]+=label in names
        passed=names==['started','passed']
        counts['passed']+=passed
        counts['unstarted']+='started' not in names
        incomplete='started' in names and not any(x in names for x in ('passed','failed','skipped'))
        counts['incomplete']+=incomplete
        counts['invalid_sequences']+=not passed
        status='passed' if passed else 'failed' if 'failed' in names else 'skipped' if 'skipped' in names else 'incomplete' if incomplete else 'unstarted' if not names else 'invalid'
        methods[key]={'status':status,'events':sequence}
    summaries=[{'line':i,'text':s} for i,s in enumerate(text.splitlines(),1) if re.search(r'Executed \d+ tests?, with \d+ failures?',s)]
    return {'log':str(path),'log_sha256':sha(path),'counts':counts,'methods':methods,'unexpected_events':foreign,'malformed_events':malformed,'suite_summaries':summaries,'all_expected_once':counts['passed']==len(expected) and not foreign and not malformed}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('evidence',type=Path);parser.add_argument('--job-log',type=Path);parser.add_argument('--receipt',type=Path,required=True)
    args=parser.parse_args();source=json.loads((HERE/'source-inventory.json').read_text())
    native_paths=list(args.evidence.rglob('native-tests.log'))
    portable_paths=list(args.evidence.rglob('macos-core-tests.log'))
    if len(native_paths)!=1 or len(portable_paths)!=1:raise SystemExit('Expected one actual native log and one actual macOS package log')
    native_expected={'KeyAndFillTests.'+name for name in source['native']['methods']}
    portable_expected=set()
    for c in source['portable']['classes']:
        target='LightingCoreTests' if c['path'].startswith('Tests/') else 'StudioCompositionTests'
        portable_expected.update(target+'.'+c['class']+'.'+m for m in c['methods'])
    receipt={'schema':1,'agent':'/root/a089_current_native_gate','source_revision':source['source_revision'],'source_inventory_sha256':sha(HERE/'source-inventory.json'),'run_id':source['run_id'],'simulator_job_id':source['simulator_job_id'],'native':reconcile(native_paths[0],native_expected),'portable_macos':reconcile(portable_paths[0],portable_expected),'physical_device_execution':False}
    receipt['required_metal']={name:receipt['native']['methods']['KeyAndFillTests.'+name] for name in source['native']['required_metal_methods']}
    native_text=native_paths[0].read_text(errors='replace')
    receipt['metal_metric_lines']=[{'line':i,'text':s} for i,s in enumerate(native_text.splitlines(),1) if re.search(r'Metal \S+: mean ',s)]
    receipt['native_test_succeeded_banner']='** TEST EXECUTE SUCCEEDED **' in native_text
    result_plists=list(args.evidence.rglob('NativeTests.xcresult/Info.plist'))
    receipt['xcresult_finalized_metadata']=[]
    for p in result_plists:
        parsed=plistlib.loads(p.read_bytes())
        receipt['xcresult_finalized_metadata'].append({'path':str(p),'sha256':sha(p),'info':parsed})
    provided=list(args.evidence.rglob('native-method-accounting.json'))
    receipt['provided_method_accounting']=None
    if len(provided)==1:
        remote=json.loads(provided[0].read_text())
        receipt['provided_method_accounting']={'path':str(provided[0]),'sha256':sha(provided[0]),'status':remote.get('status'),'expected_matches_source':set(remote.get('expected',[]))==set(source['native']['methods']),'counts':{k:len(remote.get(k,[])) for k in ('expected','started','passed','failed','skipped','unstarted','invalid')}}
    spec=importlib.util.spec_from_file_location('pinned_accounting',HERE/'source/scripts/native_test_shards.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    try:
        module.verify_log('unit',native_paths[0],HERE/'pinned-source-recomputed-accounting.json')
        receipt['pinned_source_accounting_recheck']='passed'
    except (ValueError,OSError) as error:
        receipt['pinned_source_accounting_recheck']='failed'
        receipt['pinned_source_accounting_error']=str(error)
    receipt['command_exit_events']=[]
    if args.job_log:
        job=args.job_log.read_text(errors='replace')
        receipt['job_log_sha256']=sha(args.job_log)
        for i,line in enumerate(job.splitlines(),1):
            if re.search(r'Native (command (?:start|exit)|shell exit): utc=\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ',line):
                receipt['command_exit_events'].append({'line':i,'text':line})
        receipt['required_metal_check_message']='Required Metal methods executed and passed; no native methods skipped.' in job
    args.receipt.write_text(json.dumps(receipt,indent=2,sort_keys=True,default=str)+'\n')
    print(json.dumps({'native':receipt['native']['counts'],'macos':receipt['portable_macos']['counts'],'required_metal':{k:v['status'] for k,v in receipt['required_metal'].items()},'metal_metrics':receipt['metal_metric_lines'],'finalized_bundles':len(result_plists),'command_exit_events':receipt['command_exit_events'],'pinned_source_accounting_recheck':receipt['pinned_source_accounting_recheck']},indent=2))
