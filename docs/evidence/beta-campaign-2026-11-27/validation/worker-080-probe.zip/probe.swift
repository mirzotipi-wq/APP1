// Pinned source: Sources/LightingCore/Scene.swift
import Foundation

public struct Position: Codable, Equatable, Sendable {
    public static let coordinateRange: ClosedRange<Double> = -100...100
    public var x: Double
    public var y: Double
    public var z: Double
    public init(x: Double, y: Double, z: Double) {
        self.x = x; self.y = y; self.z = z
    }
    public var isValid: Bool {
        [x, y, z].allSatisfy { $0.isFinite && Self.coordinateRange.contains($0) }
    }
    public func distance(to other: Position) -> Double {
        let dx = x - other.x, dy = y - other.y, dz = z - other.z
        return (dx * dx + dy * dy + dz * dz).squareRoot()
    }
}

public struct StudioLight: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var name: String
    public var position: Position
    /// On-axis luminous intensity, not electrical watts.
    public var candela: Double
    public var kelvin: Double
    /// Nil preserves the legacy isotropic point source.
    public var optics: LightOptics?
    public init(id: UUID = UUID(), name: String, position: Position, candela: Double, kelvin: Double, optics: LightOptics? = nil) {
        self.id = id; self.name = name; self.position = position
        self.candela = candela; self.kelvin = kelvin; self.optics = optics
    }
    public var isValid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && name.count <= 80 &&
        position.isValid && candela.isFinite && (0...100_000).contains(candela) &&
        kelvin.isFinite && (1_000...20_000).contains(kelvin) && (optics?.isValid ?? true)
    }
}

public enum SceneError: Error, Equatable {
    case unsupportedVersion, invalidScene, invalidLight, duplicateLight
}

public struct LightingScene: Codable, Equatable, Sendable {
    public static let currentSchemaVersion = 5
    public var schemaVersion: Int = currentSchemaVersion
    public var subject: Position
    public var camera: Position
    /// Nil uses the default 50 mm full-frame perspective.
    public var cameraLens: CameraLens?
    public var lights: [StudioLight]
    /// Nil retains the default diagnostic card balance and exposure.
    public var previewSettings: PreviewSettings?
    /// Nil means no measured room has been saved with this scene.
    public var placementRoom: ManualRoom?

    public init(subject: Position, camera: Position, lights: [StudioLight], cameraLens: CameraLens? = nil, previewSettings: PreviewSettings? = nil, placementRoom: ManualRoom? = nil) {
        self.subject = subject; self.camera = camera; self.lights = lights; self.cameraLens = cameraLens; self.previewSettings = previewSettings
        self.placementRoom = placementRoom
    }

    public func validated() throws -> Self {
        guard (1...Self.currentSchemaVersion).contains(schemaVersion) else { throw SceneError.unsupportedVersion }
        guard lights.count <= 12 else { throw SceneError.invalidScene }
        // Version 1 never contained optics; reject ambiguous mislabeled files.
        guard schemaVersion != 1 || lights.allSatisfy({ $0.optics == nil }) else { throw SceneError.invalidScene }
        // Version 2 adds light optics, version 3 adds a camera lens.
        guard schemaVersion >= 3 || cameraLens == nil else { throw SceneError.invalidScene }
        guard schemaVersion >= 4 || previewSettings == nil else { throw SceneError.invalidScene }
        // Version 5 adds measured rooms and rectangular-emitter roll.
        guard schemaVersion >= 5 || (placementRoom == nil && lights.allSatisfy({ $0.optics?.rollDegrees == nil })) else {
            throw SceneError.invalidScene
        }
        guard subject.isValid, camera.isValid, (cameraLens?.isValid ?? true), (previewSettings?.isValid ?? true),
              (placementRoom?.isValid ?? true) else { throw SceneError.invalidScene }
        guard lights.allSatisfy({ $0.isValid }) else { throw SceneError.invalidLight }
        guard Set(lights.map(\.id)).count == lights.count else { throw SceneError.duplicateLight }
        var migrated = self
        migrated.schemaVersion = Self.currentSchemaVersion
        return migrated
    }

    public static func portrait() -> Self {
        .init(subject: .init(x: 0, y: 1.5, z: 0),
              camera: .init(x: 0, y: 1.5, z: 3),
              lights: [
                .init(name: "Key", position: .init(x: -1.5, y: 2.1, z: 1.2), candela: 900, kelvin: 5600),
                .init(name: "Fill", position: .init(x: 1.5, y: 1.7, z: 1.5), candela: 300, kelvin: 5600),
                .init(name: "Rim", position: .init(x: 0.8, y: 2.2, z: -1.2), candela: 450, kelvin: 3200)
              ])
    }
}

public enum Photometry {
    /// Ideal point source, normal incidence. No occlusion, falloff pattern, modifier or near-field model.
    public static func normalIlluminance(candela: Double, distanceMeters: Double) -> Double? {
        guard candela.isFinite, (0...100_000).contains(candela),
              distanceMeters.isFinite, distanceMeters >= 0.05 else { return nil }
        return candela / (distanceMeters * distanceMeters)
    }
}

// Pinned source: Sources/LightingCore/StudioOptics.swift
import Foundation

public enum EmitterKind: String, Codable, CaseIterable, Sendable {
    case point, directional, rectangle

    public var title: String {
        switch self {
        case .point: return "Bare point"
        case .directional: return "Directional"
        case .rectangle: return "Rectangular softbox"
        }
    }
    public var isAimed: Bool { self != .point }
}

/// Ideal emitter geometry, not a measured modifier or equipment profile.
/// Nil aimTarget follows the subject. A manual target is an absolute world position in meters.
public struct LightOptics: Codable, Equatable, Sendable {
    public static let dimensionRange: ClosedRange<Double> = 0.05...4
    public static let rollRange: ClosedRange<Double> = -180...180
    public var kind: EmitterKind
    public var aimTarget: Position?
    public var widthMeters: Double
    public var heightMeters: Double
    /// Rotation about the emitting normal. Nil preserves the legacy world-up orientation.
    public var rollDegrees: Double?

    public init(kind: EmitterKind = .point, aimTarget: Position? = nil,
                widthMeters: Double = 0.6, heightMeters: Double = 0.9,
                rollDegrees: Double? = nil) {
        self.kind = kind; self.aimTarget = aimTarget
        self.widthMeters = widthMeters; self.heightMeters = heightMeters
        self.rollDegrees = rollDegrees
    }

    public var effectiveRollDegrees: Double { rollDegrees ?? 0 }

    public var isValid: Bool {
        (aimTarget?.isValid ?? true) && widthMeters.isFinite && heightMeters.isFinite &&
        Self.dimensionRange.contains(widthMeters) && Self.dimensionRange.contains(heightMeters) &&
        effectiveRollDegrees.isFinite && Self.rollRange.contains(effectiveRollDegrees)
    }
}

extension StudioLight {
    public var effectiveOptics: LightOptics { optics ?? .init() }
    public func target(subject: Position) -> Position { effectiveOptics.aimTarget ?? subject }
}


// Pinned source: Sources/LightingCore/CameraFraming.swift
import Foundation

/// An ideal rectilinear full-frame camera. Focal length is actual millimeters,
/// not a zoom factor; distortion, focus breathing and depth of field are excluded.
public struct CameraLens: Codable, Equatable, Sendable {
    public static let sensorWidthMillimeters = 36.0
    public static let sensorHeightMillimeters = 24.0
    public static let focalLengthRange: ClosedRange<Double> = 14...200
    public var focalLengthMillimeters: Double

    public init(focalLengthMillimeters: Double = 50) {
        self.focalLengthMillimeters = focalLengthMillimeters
    }

    public var isValid: Bool {
        focalLengthMillimeters.isFinite && Self.focalLengthRange.contains(focalLengthMillimeters)
    }
}

extension LightingScene {
    public var effectiveCameraLens: CameraLens { cameraLens ?? .init() }
}


// Pinned source: Sources/LightingCore/Colorimetry.swift
import Foundation

/// Preview settings are relative controls, not camera ISO/aperture/shutter calibration.
public struct PreviewSettings: Codable, Equatable, Sendable {
    public static let whiteBalanceRange: ClosedRange<Double> = 2000...10000
    public static let exposureRange: ClosedRange<Double> = -6...6
    public var whiteBalanceKelvin: Double
    public var exposureStops: Double

    public init(whiteBalanceKelvin: Double = 5600, exposureStops: Double = 0) {
        self.whiteBalanceKelvin = whiteBalanceKelvin; self.exposureStops = exposureStops
    }
    public var isValid: Bool {
        whiteBalanceKelvin.isFinite && Self.whiteBalanceRange.contains(whiteBalanceKelvin) &&
        exposureStops.isFinite && Self.exposureRange.contains(exposureStops)
    }
}

extension LightingScene {
    public var effectivePreviewSettings: PreviewSettings { previewSettings ?? .init() }
}


// Pinned source: Sources/LightingCore/RoomPlacement.swift
import Foundation

public enum RoomPlacementError: Error, Equatable {
    case invalidRoom
}

/// User-measured rectangular room stored with a scene. X increases from the left
/// wall and Z from the near wall. Y is height above the studio floor.
/// Positive yaw rotates scene +Z toward room +X; scale is always 1:1.
public struct ManualRoom: Codable, Equatable, Sendable {
    public static let dimensionRange: ClosedRange<Double> = 1...30
    public var widthMeters: Double
    public var depthMeters: Double
    /// Nil means the ceiling height has not been measured.
    public var ceilingHeightMeters: Double?
    public var subjectX: Double
    public var subjectZ: Double
    public var yawDegrees: Double

    public init(widthMeters: Double = 6, depthMeters: Double = 7,
                subjectX: Double = 3, subjectZ: Double = 2, yawDegrees: Double = 0,
                ceilingHeightMeters: Double? = nil) {
        self.widthMeters = widthMeters; self.depthMeters = depthMeters
        self.ceilingHeightMeters = ceilingHeightMeters
        self.subjectX = subjectX; self.subjectZ = subjectZ; self.yawDegrees = yawDegrees
    }

    /// Resizing is independent of the subject's location. The editor must
    /// require an explicit subject move before accepting a smaller room.
    public var widthEditRange: ClosedRange<Double> { dimensionRangePreserving(subjectX) }
    public var depthEditRange: ClosedRange<Double> { dimensionRangePreserving(subjectZ) }

    private func dimensionRangePreserving(_ offset: Double) -> ClosedRange<Double> {
        guard offset.isFinite, offset >= 0, offset <= Self.dimensionRange.upperBound else {
            return Self.dimensionRange
        }
        return max(Self.dimensionRange.lowerBound, offset)...Self.dimensionRange.upperBound
    }

    /// Rotate relative to the current placement, preserving dimensions and
    /// subject offsets. Canonical output is in (-180, 180], matching the UI's
    /// slider range. Invalid input leaves the entire room unchanged.
    @discardableResult
    public mutating func rotate(byDegrees degrees: Double) -> Bool {
        guard isValid, degrees.isFinite else { return false }
        // Reduce the delta before addition so even a very large finite input
        // cannot overflow or lose the bounded starting orientation.
        var angle = (yawDegrees + degrees.truncatingRemainder(dividingBy: 360))
            .truncatingRemainder(dividingBy: 360)
        if angle > 180 { angle -= 360 }
        if angle <= -180 { angle += 360 }
        yawDegrees = angle == 0 ? 0 : angle
        return true
    }

    public var isValid: Bool {
        widthMeters.isFinite && depthMeters.isFinite &&
        Self.dimensionRange.contains(widthMeters) && Self.dimensionRange.contains(depthMeters) &&
        (ceilingHeightMeters.map { $0.isFinite && Self.dimensionRange.contains($0) } ?? true) &&
        subjectX.isFinite && subjectZ.isFinite && subjectX >= 0 && subjectX <= widthMeters &&
        subjectZ >= 0 && subjectZ <= depthMeters &&
        yawDegrees.isFinite && (-360...360).contains(yawDegrees)
    }
}


// Pinned source: Sources/LightingCore/SceneLightCreation.swift
import Foundation

public enum SceneLightCreationError: Error, Equatable, LocalizedError {
    case capacityReached, outsideSupportedScene

    public var errorDescription: String? {
        switch self {
        case .capacityReached:
            return "A setup can contain up to 12 lights."
        case .outsideSupportedScene:
            return "There is no room for the new light beside this subject within the supported scene. Move the subject away from the scene boundary and try again."
        }
    }
}

/// Creates one light beside the current subject, relative to the camera's
/// horizontal direction. The complete result is validated before adoption.
public enum SceneLightCreation {
    public static func addingLight(to source: LightingScene, id: UUID = UUID()) throws -> LightingScene {
        var next = try source.validated()
        guard next.lights.count < 12 else { throw SceneLightCreationError.capacityReached }
        let dx = next.camera.x - next.subject.x
        let dz = next.camera.z - next.subject.z
        let distance = hypot(dx, dz)
        // A vertical or coincident camera has no horizontal viewing direction.
        // Use the same world-facing convention as the default portrait rig.
        let forwardX = distance > 1e-9 ? dx / distance : 0
        let forwardZ = distance > 1e-9 ? dz / distance : 1
        let position = Position(x: next.subject.x + forwardZ + forwardX,
                                y: next.subject.y + 0.5,
                                z: next.subject.z - forwardX + forwardZ)
        guard position.isValid else { throw SceneLightCreationError.outsideSupportedScene }
        var number = 1
        while next.lights.contains(where: { $0.name == "Light \(number)" }) { number += 1 }
        next.lights.append(StudioLight(id: id, name: "Light \(number)", position: position,
                                      candela: 500, kelvin: 5600))
        return try next.validated()
    }
}

// Pinned source: Sources/LightingCore/StudioDisplayName.swift
import Foundation

/// Limits text passed to native layout without changing names in saved projects.
/// A Character count alone does not bound a long sequence of combining marks.
public enum StudioDisplayName {
    public static let maximumCharacters = 80
    public static let maximumScalars = 320
    public static let maximumUTF8Bytes = 1280

    public enum NameError: Error, Equatable, LocalizedError {
        case empty, tooLong, unsupportedCharacter

        public var errorDescription: String? {
            switch self {
            case .empty: return "Enter a name."
            case .tooLong: return "Use a shorter name of up to 80 characters."
            case .unsupportedCharacter: return "Names cannot contain line breaks, control characters or directional formatting codes."
            }
        }
    }

    /// Entry validation only. Do not apply this stricter policy while decoding
    /// a legacy library: retain its original name and use display(_:) in labels.
    public static func newInput(_ input: String) throws -> String {
        var scalars = String.UnicodeScalarView()
        var bytes = 0
        for scalar in input.unicodeScalars {
            let nextBytes = bytes + utf8Length(scalar)
            guard scalars.count < maximumScalars, nextBytes <= maximumUTF8Bytes else {
                throw NameError.tooLong
            }
            scalars.append(scalar)
            bytes = nextBytes
        }
        let name = String(scalars).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { throw NameError.empty }
        guard name.count <= maximumCharacters else { throw NameError.tooLong }
        guard !name.unicodeScalars.contains(where: isUnsafe) else { throw NameError.unsupportedCharacter }
        guard hasDisplayContent(name) else { throw NameError.empty }
        return name
    }

    /// A bounded label, not a renamed stored value. This inspects at most 321
    /// source scalars, even when one grapheme contains megabytes of marks.
    /// Ordinary accented/RTL text, joining controls and emoji remain intact.
    public static func display(_ input: String, maximumCharacters requested: Int = maximumCharacters) -> String {
        let characterLimit = min(Self.maximumCharacters, max(0, requested))
        guard characterLimit > 0 else { return "" }
        var scalars = String.UnicodeScalarView()
        var bytes = 0
        var truncated = false
        for source in input.unicodeScalars {
            let scalar: Unicode.Scalar = isUnsafe(source) ? " " : source
            let nextBytes = bytes + utf8Length(scalar)
            guard scalars.count < maximumScalars, nextBytes <= maximumUTF8Bytes else {
                truncated = true
                break
            }
            scalars.append(scalar)
            bytes = nextBytes
        }
        let bounded = String(scalars)
        // If the scalar budget stopped inside a grapheme, its final Character
        // only looks complete because the unseen suffix is absent. Discard
        // that boundary Character before trimming can free space for it.
        // The remaining prefix contains only complete source graphemes while
        // still inspecting at most one scalar beyond the fixed budget.
        let completePrefix = truncated ? String(bounded.dropLast()) : bounded
        let cleaned = completePrefix.trimmingCharacters(in: .whitespacesAndNewlines)
        // Preserve stored legacy names, but let callers display their visible
        // fallback and identity for a name consisting only of invisible marks.
        // A truncated prefix cannot establish what is in the unseen suffix.
        guard hasDisplayContent(cleaned) else { return truncated ? "…" : "" }
        guard truncated || cleaned.count > characterLimit else { return cleaned }

        // Reserve space for the truncation mark in every limit. Stop at a whole
        // grapheme instead of cutting a normal joined emoji or accented letter.
        var result = ""
        var resultCharacters = 0
        var resultScalars = 0
        var resultBytes = 0
        for character in cleaned {
            let part = String(character)
            let scalarCount = part.unicodeScalars.count
            let byteCount = part.utf8.count
            guard resultCharacters < characterLimit - 1,
                  resultScalars + scalarCount <= maximumScalars - 1,
                  resultBytes + byteCount <= maximumUTF8Bytes - 3 else { break }
            result.append(character)
            resultCharacters += 1
            resultScalars += scalarCount
            resultBytes += byteCount
        }
        return result.trimmingCharacters(in: .whitespacesAndNewlines) + "…"
    }

    /// A contextual UI label for retained names that have no visible content.
    /// The caller supplies a visible fallback; both paths retain layout bounds.
    /// This does not change the source value or the editable project document.
    public static func label(_ input: String, fallback: String) -> String {
        let bounded = display(input)
        return bounded.isEmpty ? display(fallback) : bounded
    }

    private static func hasDisplayContent(_ name: String) -> Bool {
        // Joining controls and variation selectors remain valid within a
        // visible script or emoji sequence; alone they do not supply a label.
        // Braille blank is meaningful spacing within visible text, but its
        // Unicode properties do not classify it as whitespace or ignorable.
        name.unicodeScalars.contains {
            !$0.properties.isWhitespace && !$0.properties.isDefaultIgnorableCodePoint &&
                $0.value != 0x2800
        }
    }

    private static func isUnsafe(_ scalar: Unicode.Scalar) -> Bool {
        switch scalar.properties.generalCategory {
        case .control, .lineSeparator, .paragraphSeparator: return true
        default: break
        }
        // Explicit bidi embedding/override/isolate controls can make labels
        // misleading. Natural right-to-left scripts do not require these codes.
        switch scalar.value {
        case 0x061C, 0x200E, 0x200F, 0x202A...0x202E, 0x2066...0x2069: return true
        default: return false
        }
    }

    private static func utf8Length(_ scalar: Unicode.Scalar) -> Int {
        switch scalar.value {
        case 0..<0x80: return 1
        case 0..<0x800: return 2
        case 0..<0x10000: return 3
        default: return 4
        }
    }
}

// Pinned source: Sources/LightingCore/SceneEditHistory.swift
import Foundation

/// Bounded, session-only history for an editor whose scene lives outside this
/// value. Call `record(previous:)` immediately before a discrete change, or
/// bracket continuous changes with a stable control owner. Unqualified
/// `end(scene:)` explicitly closes the current edit for lifecycle boundaries.
/// Scene validation remains the editor's responsibility.
public struct SceneEditHistory: Equatable, Sendable {
    public static let maximumEntries = 60
    private let limit: Int
    private var past: [LightingScene] = []
    private var future: [LightingScene] = []
    private var transactionStart: LightingScene?
    private var transactionOwner: String?

    /// Custom limits are useful for constrained editors; history is always
    /// bounded to between one and sixty entries in each direction.
    public init(limit: Int = maximumEntries) {
        self.limit = min(Self.maximumEntries, max(1, limit))
    }

    /// An active edit can be undone even before its final callback arrives.
    /// If that edit made no change, Undo falls through to the previous command.
    public var canUndo: Bool { !past.isEmpty || transactionStart != nil }
    public var canRedo: Bool { !future.isEmpty }
    public var isEditing: Bool { transactionStart != nil }

    /// Optional settings retain their original stored representation when a
    /// continuous edit returns to the same effective value. This keeps an
    /// out-and-back slider gesture exactly unchanged, including nil defaults,
    /// so it cannot create an undo entry or discard redo. With no active
    /// transaction, the scene is returned unchanged.
    public func preservingOptionalRepresentations(in scene: LightingScene) -> LightingScene {
        guard let start = transactionStart else { return scene }
        var result = scene
        if result.effectivePreviewSettings == start.effectivePreviewSettings {
            result.previewSettings = start.previewSettings
        }
        if result.effectiveCameraLens == start.effectiveCameraLens {
            result.cameraLens = start.cameraLens
        }
        for index in result.lights.indices {
            guard let original = start.lights.first(where: { $0.id == result.lights[index].id }) else { continue }
            let initialOptics = original.effectiveOptics
            var optics = result.lights[index].effectiveOptics
            if optics.effectiveRollDegrees == initialOptics.effectiveRollDegrees {
                optics.rollDegrees = initialOptics.rollDegrees
            }
            // Aim-to-subject and a manual target at the subject's current
            // position remain distinct settings, even if their rays coincide.
            if optics == initialOptics {
                result.lights[index].optics = original.optics
            } else if result.lights[index].optics != nil {
                result.lights[index].optics = optics
            }
        }
        return result
    }

    /// Record only actual discrete changes. If a gesture is still open,
    /// `previous` is its current result: commit that gesture before recording
    /// the new command so both operations remain independently reversible.
    public mutating func record(previous: LightingScene) {
        end(scene: previous)
        pushPast(previous)
        future.removeAll()
    }

    /// Repeated callbacks from the same control preserve its original scene.
    /// Starting a different control commits the previous edit at the supplied
    /// current scene before starting the new one. Nil retains the legacy owner.
    public mutating func begin(scene: LightingScene, owner: String? = nil) {
        if transactionStart != nil {
            guard transactionOwner != owner else { return }
            end(scene: scene)
        }
        transactionStart = scene
        transactionOwner = owner
    }

    /// A delayed end from another control cannot close a newer edit. Owners
    /// identify controls, not event generations: overlapping gestures from the
    /// same control still require ordered begin/end callbacks from the caller.
    public mutating func end(scene: LightingScene, owner: String) {
        guard transactionStart != nil, transactionOwner == owner else { return }
        end(scene: scene)
    }

    /// A gesture that returns to its initial value does not create history or
    /// discard redo. This unqualified form deliberately closes any owner for
    /// save, selection, lifecycle and history commands; slider callbacks should
    /// use the owner-qualified form.
    public mutating func end(scene: LightingScene) {
        guard let start = transactionStart else { return }
        transactionStart = nil
        transactionOwner = nil
        guard start != scene else { return }
        pushPast(start)
        future.removeAll()
    }

    /// Explicit rollback: the caller must restore the returned scene. Existing
    /// history and redo are retained because the gesture was not committed.
    @discardableResult
    public mutating func cancel() -> LightingScene? {
        let start = transactionStart
        transactionStart = nil
        transactionOwner = nil
        return start
    }

    public mutating func undo(current: LightingScene) -> LightingScene? {
        end(scene: current)
        guard let previous = past.popLast() else { return nil }
        if future.last != current { future.append(current) }
        if future.count > limit { future.removeFirst(future.count - limit) }
        return previous
    }

    public mutating func redo(current: LightingScene) -> LightingScene? {
        end(scene: current)
        guard let next = future.popLast() else { return nil }
        pushPast(current)
        return next
    }

    /// Project switching and successful recovery must not retain another
    /// project's snapshots or an unfinished gesture.
    public mutating func reset() {
        past.removeAll()
        future.removeAll()
        transactionStart = nil
        transactionOwner = nil
    }

    private mutating func pushPast(_ scene: LightingScene) {
        if past.last != scene { past.append(scene) }
        if past.count > limit { past.removeFirst(past.count - limit) }
    }
}

// Pinned source: Sources/LightingCore/StudioFieldCommand.swift
import Foundation

/// Scalar light controls in scene units: meters, candela and kelvin.
public enum StudioLightField: CaseIterable, Equatable, Sendable {
    case x, y, z, candela, kelvin

    public var domain: ClosedRange<Double> {
        switch self {
        case .x, .y, .z: return Position.coordinateRange
        case .candela: return 0...100_000
        case .kelvin: return 1_000...20_000
        }
    }

    public func value(in light: StudioLight) -> Double {
        switch self {
        case .x: return light.position.x
        case .y: return light.position.y
        case .z: return light.position.z
        case .candela: return light.candela
        case .kelvin: return light.kelvin
        }
    }
}

/// Closed field edits for an already validated editor scene. Light commands
/// resolve a live UUID; they cannot change names, identity, schema or light count.
public enum StudioFieldCommand: Equatable, Sendable {
    case lightValue(id: UUID, field: StudioLightField, value: Double)
    case lightPosition(id: UUID, position: Position)
    case lightOptics(id: UUID, optics: LightOptics)
    case cameraPosition(Position)
    case subjectPosition(Position)
    case cameraLens(CameraLens)
    case previewSettings(PreviewSettings)
    case room(ManualRoom?)
}

// Pinned source: Sources/LightingCore/StudioEditorState.swift
import Foundation

/// One editor's validated scene, selection and bounded undo history. Presentation
/// and disk state live outside this value. Revisions are identity tokens, not
/// counters: undoing back to equal content never revives an obsolete result.
public struct StudioEditorState: Equatable, Sendable {
    public enum AdoptionError: Error, Equatable {
        case changesSceneWithoutReset
    }
    public private(set) var scene: LightingScene
    public private(set) var selection: UUID?
    public private(set) var history = SceneEditHistory()
    public private(set) var revision = UUID()

    public init() {
        let scene = LightingScene.portrait()
        self.scene = scene
        selection = scene.lights.first?.id
    }

    public init(scene: LightingScene, selection: UUID? = nil) throws {
        self.scene = try scene.validated()
        self.selection = selection
        repairSelection()
    }

    /// Selection is always an existing UUID, or nil for an empty rig. Selecting
    /// another control commits the previous gesture without changing geometry.
    @discardableResult
    public mutating func select(_ id: UUID?) -> Bool {
        guard id != selection else { return false }
        guard let id, scene.lights.contains(where: { $0.id == id }) else { return false }
        endEditing()
        selection = id
        return true
    }

    /// A discrete command commits an open continuous edit first, giving each
    /// its own undo entry. Validation happens before changing any editor state.
    @discardableResult
    public mutating func replace(with candidate: LightingScene) throws -> Bool {
        let validated = try candidate.validated()
        guard validated != scene else { return false }
        history.record(previous: scene)
        scene = validated
        revision = UUID()
        repairSelection()
        return true
    }

    /// A control update belongs to the current continuous transaction, if any;
    /// otherwise it is one discrete change. Only the editor owns history writes.
    @discardableResult
    public mutating func update(with candidate: LightingScene) throws -> Bool {
        commitValidatedUpdate(try candidate.validated())
    }

    /// Like `update(with:)`, joins the current continuous edit or records one
    /// discrete change. The private scene is already validated, so these closed
    /// edits validate only their payload and live light UUID before any mutation.
    @discardableResult
    public mutating func apply(_ command: StudioFieldCommand) throws -> Bool {
        var candidate = scene
        switch command {
        case let .lightValue(id, field, value):
            guard value.isFinite, field.domain.contains(value),
                  let index = scene.lights.firstIndex(where: { $0.id == id }) else {
                throw SceneError.invalidLight
            }
            guard field.value(in: scene.lights[index]) != value else { return false }
            switch field {
            case .x: candidate.lights[index].position.x = value
            case .y: candidate.lights[index].position.y = value
            case .z: candidate.lights[index].position.z = value
            case .candela: candidate.lights[index].candela = value
            case .kelvin: candidate.lights[index].kelvin = value
            }
        case let .lightPosition(id, position):
            guard position.isValid,
                  let index = scene.lights.firstIndex(where: { $0.id == id }) else {
                throw SceneError.invalidLight
            }
            guard scene.lights[index].position != position else { return false }
            candidate.lights[index].position = position
        case let .lightOptics(id, optics):
            guard optics.isValid,
                  let index = scene.lights.firstIndex(where: { $0.id == id }) else {
                throw SceneError.invalidLight
            }
            let current = scene.lights[index].effectiveOptics
            var normalized = optics
            if normalized.effectiveRollDegrees == current.effectiveRollDegrees {
                normalized.rollDegrees = current.rollDegrees
            }
            // An implicit subject target remains distinct from a manual target,
            // even when their current positions happen to be equal.
            guard normalized != current else { return false }
            candidate.lights[index].optics = normalized
        case let .cameraPosition(position):
            guard position.isValid else { throw SceneError.invalidScene }
            guard scene.camera != position else { return false }
            candidate.camera = position
        case let .subjectPosition(position):
            guard position.isValid else { throw SceneError.invalidScene }
            guard scene.subject != position else { return false }
            candidate.subject = position
        case let .cameraLens(lens):
            guard lens.isValid else { throw SceneError.invalidScene }
            guard scene.effectiveCameraLens != lens else { return false }
            candidate.cameraLens = lens
        case let .previewSettings(settings):
            guard settings.isValid else { throw SceneError.invalidScene }
            guard scene.effectivePreviewSettings != settings else { return false }
            candidate.previewSettings = settings
        case let .room(room):
            guard room?.isValid ?? true else { throw SceneError.invalidScene }
            guard scene.placementRoom != room else { return false }
            candidate.placementRoom = room
        }
        return commitValidatedUpdate(candidate)
    }

    public mutating func beginEditing(owner: String) {
        history.begin(scene: scene, owner: owner)
    }

    public mutating func endEditing(owner: String? = nil) {
        if let owner { history.end(scene: scene, owner: owner) }
        else { history.end(scene: scene) }
    }

    /// A lifecycle rollback must restore the original scene as well as history.
    @discardableResult
    public mutating func cancelEditing() -> Bool {
        guard let original = history.cancel() else { return false }
        if original != scene { scene = original; revision = UUID() }
        repairSelection()
        return true
    }

    @discardableResult
    public mutating func undo() -> Bool {
        guard !history.isEditing, let previous = history.undo(current: scene) else { return false }
        scene = previous
        revision = UUID()
        repairSelection()
        return true
    }

    @discardableResult
    public mutating func redo() -> Bool {
        guard !history.isEditing, let next = history.redo(current: scene) else { return false }
        scene = next
        revision = UUID()
        repairSelection()
        return true
    }

    /// A storage receipt is not an editing command. The caller passes the
    /// adoption policy, rather than inferring history reset from an ID change:
    /// first save establishes project identity but must retain undo/selection.
    public mutating func adopt(_ candidate: LightingScene, resettingHistory: Bool) throws {
        let validated = try candidate.validated()
        // Save and metadata receipts retain the live scene. Replacing it while
        // keeping another scene's redo or open transaction would rebase history.
        guard resettingHistory || validated == scene else {
            throw AdoptionError.changesSceneWithoutReset
        }
        if resettingHistory {
            history.reset()
            scene = validated
            selection = scene.lights.first?.id
            revision = UUID()
        }
    }

    /// Only fully validated candidates or closed, payload-validated commands
    /// enter here. Keep normalization and history/revision changes in one place.
    private mutating func commitValidatedUpdate(_ candidate: LightingScene) -> Bool {
        let normalized = history.preservingOptionalRepresentations(in: candidate)
        guard normalized != scene else { return false }
        if !history.isEditing { history.record(previous: scene) }
        scene = normalized
        revision = UUID()
        repairSelection()
        return true
    }

    private mutating func repairSelection() {
        if !scene.lights.contains(where: { $0.id == selection }) {
            selection = scene.lights.first?.id
        }
    }
}

// This wrapper exercises verbatim Foundation-compatible StudioView method bodies.
// It is not SwiftUI/native execution or a test of StudioSession's async gates.
final class CommandHarness {
    var editor: StudioEditorState
    var message: String?
    struct Operation { var isBusy = false }
    var libraryOperation = Operation()
    var scene: LightingScene { editor.scene }
    var selected: UUID? {
        get { editor.selection }
        set { editor.select(newValue) }
    }
    init(_ scene: LightingScene) throws { editor = try StudioEditorState(scene: scene) }
    private func replace(_ next: LightingScene) { do { try editor.replace(with: next) } catch { message = "invalid" } }
    func add() { addLight() }
    func duplicate(_ id: UUID) { duplicateLight(id) }
    private func addLight() {
        guard !libraryOperation.isBusy, scene.lights.count < 12 else { return }
        do {
            let next = try SceneLightCreation.addingLight(to: scene)
            replace(next)
            selected = next.lights.last?.id
        } catch {
            message = error.localizedDescription
        }
    }
    private func duplicateLight(_ id: UUID) {
        guard scene.lights.count < 12, let original = scene.lights.first(where: { $0.id == id }) else { return }
        var copy = original
        copy.id = UUID()
        var stem = StudioDisplayName.display(lightDisplayName(original), maximumCharacters: 65)
        var number = 1
        repeat {
            let suffix = number == 1 ? " copy" : " copy \(number)"
            // Leave room for the suffix under the scalar and byte limits too;
            // one imported grapheme can contain hundreds of combining marks.
            while !stem.isEmpty && (try? StudioDisplayName.newInput(stem + suffix)) == nil {
                stem.removeLast()
            }
            copy.name = (stem.isEmpty ? "Light" : stem) + suffix
            number += 1
        } while scene.lights.contains(where: { $0.name == copy.name })
        // Preserve exact equipment geometry; duplicating never silently moves a rig.
        var next = scene
        next.lights.append(copy)
        replace(next)
        selected = copy.id
    }
    private func lightDisplayName(_ light: StudioLight) -> String {
        let fallback = scene.lights.firstIndex(where: { $0.id == light.id })
            .map { "Light \($0 + 1)" } ?? "Light \(light.id.uuidString.prefix(8))"
        return StudioDisplayName.label(light.name, fallback: fallback)
    }
}

var assertions = 0
func expect(_ predicate: @autoclosure () -> Bool, _ message: String) {
    assertions += 1
    if !predicate() { fatalError(message) }
}
func rejects(_ body: () throws -> Void, _ message: String) {
    assertions += 1
    do { try body(); fatalError(message) } catch { }
}
func bytes(_ scene: LightingScene) throws -> Data {
    let e = JSONEncoder(); e.outputFormatting = [.sortedKeys]
    return try e.encode(scene)
}
var base = LightingScene.portrait()
base.lights = [base.lights[0]]
base.lights[0].name = "Light"
base.lights[0].candela = 100_000
base.lights[0].kelvin = 20_000
base.lights[0].optics = LightOptics(kind: .rectangle, aimTarget: Position(x: 0.2, y: 1.4, z: -0.3), widthMeters: 4, heightMeters: 0.05, rollDegrees: -180)
base.cameraLens = CameraLens(focalLengthMillimeters: 200)
base.previewSettings = PreviewSettings(whiteBalanceKelvin: 10_000, exposureStops: 6)
base.placementRoom = ManualRoom(widthMeters: 30, depthMeters: 30, ceilingHeightMeters: 30)
let originalID = base.lights[0].id
let h = try CommandHarness(base)
for n in 1...11 {
    let before = h.scene
    h.duplicate(originalID)
    expect(h.scene.lights.count == n+1, "Duplicate must add exactly one")
    let copy = h.scene.lights.last!
    expect(copy.name == (n == 1 ? "Light copy" : "Light copy \(n)"), "Deterministic duplicate suffix")
    expect(!before.lights.contains { $0.id == copy.id }, "New UUID")
    var expected = base.lights[0]; expected.id = copy.id; expected.name = copy.name
    expect(expected == copy, "Duplicate preserves every equipment field")
    expect(h.selected == copy.id, "Duplicate selected")
}
let twelve = h.editor
h.add(); expect(h.editor == twelve, "UI add guard at twelve")
h.duplicate(originalID); expect(h.editor == twelve, "UI duplicate guard at twelve")
rejects({ _ = try SceneLightCreation.addingLight(to: h.scene) }, "Domain capacity")
let fullBytes = try bytes(h.scene)
expect(h.editor.undo(), "Undo duplicate")
expect(h.scene.lights.count == 11, "Undo twelfth")
expect(h.selected == originalID, "Removed selection falls back to first")
expect(h.editor.redo(), "Redo duplicate")
let redoneBytes = try bytes(h.scene)
expect(redoneBytes == fullBytes, "Redo restores full scene and exact identity")
expect(h.selected == originalID, "Redo retains live selection")
var removed = h.scene
removed.lights.removeAll { $0.id == originalID }
try h.editor.replace(with: removed)
let fallback = removed.lights.first!.id
expect(h.selected == fallback, "Remove selected fallback")
expect(h.editor.undo(), "Undo removal")
expect(h.selected == fallback, "Undo must not steal valid selection")
let restoredBytes = try bytes(h.scene)
expect(restoredBytes == fullBytes, "Undo restores complete prior scene")
expect(h.editor.redo(), "Redo removal")
expect(h.scene == removed, "Redo complete removal")
var empty = h.scene; empty.lights = []
try h.editor.replace(with: empty)
expect(h.selected == nil, "No dangling selection in empty rig")
expect(h.editor.undo(), "Undo empty rig")
expect(h.selected == removed.lights.first!.id, "Undo empty picks first")
print("PASS: duplicate saturation, max intensity, 12 cap, identity and full scene undo/redo")

let names = [String(repeating: "A", count: 80), String(repeating: "👨‍👩‍👧‍👦", count: 80), "A"+String(repeating: "\u{301}", count: 4096), "\u{200D}", "Light 1"]
for name in names {
    var named = base; named.lights[0].name = name
    let bounded = try CommandHarness(named)
    for _ in 0..<11 { bounded.duplicate(originalID) }
    expect(bounded.scene.lights.count == 12, "Saturated names terminate at twelve")
    expect(Set(bounded.scene.lights.map(\.name)).count == 12, "Names unique")
    expect(Set(bounded.scene.lights.map(\.id)).count == 12, "UUIDs unique")
    for copy in bounded.scene.lights.dropFirst() {
        expect((try? StudioDisplayName.newInput(copy.name)) == copy.name, "New duplicate name within all limits")
        expect(copy.candela == 100_000, "Intensity preserved")
    }
    expect(bounded.scene.lights[0].name == name, "Imported source name preserved")
}
var named = base
named.lights = (1...11).map { n in StudioLight(name: "Light \(n)", position: base.lights[0].position, candela: 100_000, kelvin: 20_000) }
let newID = UUID()
let created = try SceneLightCreation.addingLight(to: named, id: newID)
expect(created.lights.last!.name == "Light 12", "Deterministic add name at limit")
expect(created.lights.last!.id == newID, "Injected add UUID retained")
expect(Array(created.lights.dropLast()) == named.lights, "Existing lights unchanged")
print("PASS: saturated Unicode/imported names, suffix collisions and Light 12")

var editor = try StudioEditorState(scene: created, selection: newID)
var changed = editor.scene; changed.lights[0].candela = 0
try editor.replace(with: changed)
expect(editor.undo(), "Create redo branch")
let pristine = editor
var invalids: [LightingScene] = []
var duplicate = created; duplicate.lights[1].id = duplicate.lights[0].id; invalids.append(duplicate)
var thirteen = created; var extra = created.lights[0]; extra.id = UUID(); thirteen.lights.append(extra); invalids.append(thirteen)
for value in [(100_000.0).nextUp, -.leastNonzeroMagnitude, .nan, .infinity] {
    var invalid = created; invalid.lights[0].candela = value; invalids.append(invalid)
}
for invalid in invalids {
    rejects({ try editor.replace(with: invalid) }, "Invalid replacement must fail")
    expect(editor == pristine, "Reject preserves selection, scene, history, revision")
    rejects({ _ = try StudioEditorState(scene: invalid) }, "Invalid editor initializer")
}
var eleven = created; eleven.lights.removeLast()
rejects({ _ = try SceneLightCreation.addingLight(to: eleven, id: eleven.lights[0].id) }, "Duplicate UUID add")
var duplicateInput = eleven; duplicateInput.lights[1].id = duplicateInput.lights[0].id
rejects({ _ = try SceneLightCreation.addingLight(to: duplicateInput) }, "Duplicate UUID source")
var boundary = eleven; boundary.subject.y = 100
rejects({ _ = try SceneLightCreation.addingLight(to: boundary) }, "Boundary add rejection")
expect(editor == pristine, "Unrelated failed operations preserve editor")
expect(editor.redo(), "Preserved redo still usable")
expect(editor.scene == changed, "Preserved redo exact")
print("PASS: duplicate UUID, thirteen lights, invalid intensity, add bounds, atomic failure and redo")
print("TOTAL: \(assertions) assertions; source 700486b83740f6fa1d4c470ed9befa805268c00c; Foundation-only extracted-source probe")
