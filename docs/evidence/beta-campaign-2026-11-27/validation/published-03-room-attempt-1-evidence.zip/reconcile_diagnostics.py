"""Verify and decode the two selected original xcresult diagnostic objects."""
from pathlib import Path
import hashlib, io, json, re, subprocess, zipfile
import zstandard

P=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
sources=json.loads((P/'diagnostics/candidate-receipt.json').read_text())
labels=['app-stdout','xctest-session']
records=[]
for item,label in zip(sources,labels):
    raw=(P/'diagnostics'/item['decoded'].replace('.log','.zstd')).read_bytes()
    assert len(raw)==item['compressedBytes'] and sha(raw)==item['compressedSHA256']
    with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw)) as reader:data=reader.read(40_000_001)
    assert len(data)<=40_000_000 and len(data)==item['decodedBytes'] and sha(data)==item['decodedSHA256']
    assert data==(P/'diagnostics'/item['decoded']).read_bytes()
    record={k:v for k,v in item.items() if k!='head'}
    record['label']=label;record['compressedFile']='diagnostics/'+item['decoded'].replace('.log','.zstd')
    records.append(record)
with zipfile.ZipFile(P/'full/artifacts/native-results.zip') as z:
    for item in records:assert sha(z.read(item['source']))==item['compressedSHA256']
app=(P/'diagnostics'/sources[0]['decoded']).read_text().splitlines()
session=(P/'diagnostics'/sources[1]['decoded']).read_text().splitlines()
selected=[]
for filename,lines,predicate in [
    ('app-stdout',app,lambda l:'Keyboard queue task timeout detected' in l or ('18192:' in l and '13:38:23.' in l and 'MT responded in time' in l)),
    ('xctest-session',session,lambda l:"doesn't have keyboard focus" in l or ('13:38:23.' in l and ('Requesting local synthesis' in l or 'Got event completion callback' in l or 'Synthesize event (0.' in l)))
]:
    for number,line in enumerate(lines,1):
        if predicate(line):selected.append({'log':filename,'line':number,'text':line})
assert sum('Keyboard queue task timeout detected' in x['text'] for x in selected)==1
(P/'diagnostics-receipt.json').write_text(json.dumps(records,indent=2)+'\n')
(P/'input-timeline-excerpts.json').write_text(json.dumps(selected,indent=2)+'\n')
source_paths=['App/ManualRoomPlacementView.swift','App/StudioTextField.swift','UITests/ManualRoomPlacementUITests.swift','UITests/PrecisionEditingUITests.swift','UITests/StudioContentReachability.swift']
R=P.parents[3]/'APP1';revision='f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
hashes={}
for path in source_paths:
    data=subprocess.check_output(['git','-C',str(R),'show',revision+':'+path]);hashes[path]={'bytes':len(data),'sha256':sha(data)}
(P/'source-review.json').write_text(json.dumps({'source':revision,'files':hashes,'findings':[
    'Width was cleared and remained empty after one typeText(2); original PNG and AX agree focused empty text.',
    'Keyboard key readiness predicate passed; actual event synthesis callback completed at13:38:23.900.',
    'The room app keyboard queue timeout at13:39:22.627 is later than typing and the value wait, so it is not evidence of a pre-typing cause.',
    'The same internal descendant-focus diagnostic appears during successful focal-length, intensity, modifier-width and roomSubjectX entries.',
    'Room binding accepts bounded raw text and parses only on explicit Set. No Set occurred in the failed call; actual delegate/editingChanged callbacks were not recorded.'
], 'causalConclusion':None,'recommendation':'Preserve failure; a fresh unchanged-job observation may distinguish intermittent execution, but only native input/binding trace can distinguish nondelivery from rejection/reset if repeated.'},indent=2)+'\n')
print('Verified2 selected compressed originals; preserved',len(selected),'exact diagnostic lines and5 pinned sources. No app execution or causal repair.')
