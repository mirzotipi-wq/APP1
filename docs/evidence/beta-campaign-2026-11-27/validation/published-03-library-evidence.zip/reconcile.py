#!/usr/bin/env python3
"""Independently reconcile the original f94 library/reference shard."""
from pathlib import Path, PurePosixPath
import hashlib, json, plistlib, re, stat, subprocess, zipfile
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
REPO = ROOT / 'APP1'
REV = 'f94c0e6cb9cd072286d6e4414eb2c1f8974d4ce5'
OLD = '134f9adabe0203b1d6d8ed21abb6aaeb4e19d256'

def digest(data): return hashlib.sha256(data).hexdigest()
def write(name, data): (OUT/name).write_text(json.dumps(data, indent=2, sort_keys=True, default=str)+'\n')
def src(rev, path): return subprocess.check_output(['git','show',f'{rev}:{path}'], cwd=REPO)

def extract(archive, destination, maximum=512*1024*1024):
    records=[]
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist()
        assert len(infos) < 5000 and sum(i.file_size for i in infos) <= maximum
        names=[i.filename for i in infos]
        assert len(names)==len(set(names))
        for i in infos:
            p=PurePosixPath(i.filename)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
            assert str(p)==i.filename.rstrip('/') and not (i.flag_bits & 1)
            assert stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG,stat.S_IFDIR]
            assert i.file_size <= 128*1024*1024
        assert z.testzip() is None
        for i in infos:
            if i.is_dir(): continue
            p=destination/i.filename
            assert not p.is_symlink()
            p.parent.mkdir(parents=True, exist_ok=True)
            data=z.read(i)
            if p.exists(): assert p.read_bytes()==data
            else: p.write_bytes(data)
            records.append({'path':i.filename,'bytes':len(data),'sha256':digest(data)})
    return {'archive':str(archive.relative_to(OUT)),'bytes':archive.stat().st_size,
            'sha256':digest(archive.read_bytes()),'files':records,'fileCount':len(records),
            'pathSpecialTypeEncryptionDuplicateCrcAndExpansionChecks':'passed'}

job=json.loads((OUT/'job.json').read_text())
run=json.loads((OUT/'run.json').read_text())
arts=json.loads((OUT/'artifacts.json').read_text())
assert run['id']==46004241191 and run['head_sha']==REV and run['run_attempt']==1
assert job['id']==140527589901 and job['run_id']==run['id']
assert job['name']=='ui (library-reference)' and job['status']=='completed' and job['conclusion']=='success'
steps={s['name']:s for s in job['steps']}
for name in ['Build native UI test bundle','Run selected native UI shard','Verify required UI method accounting',
             'Export finalized XCTest result bundle and genuine attachments','Upload native result and test evidence',
             'Upload compact native attachments']:
    assert steps[name]['conclusion']=='success'

archives=[]
for aid,filename,directory in [(15202911162,'library-full-original.zip','full'),(15203095915,'library-compact-original.zip','compact')]:
    a=next(a for a in arts if a['id']==aid)
    p=OUT/filename
    assert a['workflow_run']['head_sha']==REV and a['workflow_run']['id']==run['id']
    assert p.stat().st_size==a['size_in_bytes'] and 'sha256:'+digest(p.read_bytes())==a['digest']
    rec=extract(p,OUT/directory)
    rec['providerArtifact']=a
    archives.append(rec)
raw=extract(OUT/'full/artifacts/native-results.zip',OUT/'raw')
infos=list((OUT/'raw').rglob('Info.plist'))
assert len(infos)==1 and infos[0].parent.name=='NativeTests.xcresult'
plist=plistlib.loads(infos[0].read_bytes())
write('result-info.json',plist)
root_object=infos[0].parent/'Data'/('data.'+plist['rootId']['hash'])
assert root_object.is_file() and root_object.stat().st_size > 0
write('result-root-object.json', {'path':str(root_object.relative_to(OUT)),
      'bytes':root_object.stat().st_size,'sha256':digest(root_object.read_bytes())})

paths=['UITests/ProjectLibraryUITests.swift','UITests/ReferenceComparisonUITests.swift',
       'UITests/StudioContentReachability.swift','UITests/StudioViewportGeometry.swift',
       'UITests/StudioViewportObservation.swift','App/ProjectLibraryView.swift','App/StudioView.swift',
       'App/StudioTextLayoutDiagnostics.swift','App/StudioTextField.swift','App/StudioSession.swift',
       'scripts/native_test_shards.py','.github/workflows/ios-prototype.yml','project.yml']
sources=[];expected=[]
for path in paths:
    data=src(REV,path)
    assert (REPO/path).read_bytes()==data
    p=OUT/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    sources.append({'path':path,'bytes':len(data),'sha256':digest(data)})
    if path in paths[:2]:
        content=data.decode();classes=re.findall(r'\bclass\s+(\w+)\s*:\s*XCTestCase\b',content)
        methods=re.findall(r'\bfunc\s+(test\w+)\s*\(',content)
        assert len(classes)==1 and len(methods)==len(set(methods))
        expected += [classes[0]+'.'+m for m in methods]
assert len(expected)==9 and len(set(expected))==9
expected=sorted(expected)

testlog=(OUT/'full/native-tests.log').read_text()
console=(OUT/'job-console.log').read_text()
pattern=re.compile(r"Test Case '-\[KeyAndFillUITests\.(\w+) (test\w+)\]' (started|passed|failed|skipped)(?: \(([\d.]+) seconds\))?\.")
events=[]
for line,text in enumerate(testlog.splitlines(),1):
    if 'Test Case ' not in text:continue
    m=pattern.fullmatch(text)
    assert m, (line,text)
    events.append({'method':m[1]+'.'+m[2], 'event':m[3], 'line':line, 'seconds':float(m[4]) if m[4] else None})
assert len(events)==18 and set(e['method'] for e in events)==set(expected)
for method in expected:
    assert [e['event'] for e in events if e['method']==method]==['started','passed']
assert '** TEST EXECUTE SUCCEEDED **' in testlog
assert 'Executed 9 tests, with 0 failures (0 unexpected)' in testlog
assert 'Verified 9 library-reference methods: one start and one pass each; no failures, skips, duplicates or omissions.' in console
native_accounting=json.loads((OUT/'full/native-method-accounting.json').read_text())
assert native_accounting['expected']==native_accounting['started']==native_accounting['passed']==expected
for key in ['failed','skipped','unstarted','invalid']:assert native_accounting[key]==[]
assert native_accounting['status']=='passed'
env=(OUT/'full/macos-environment.log').read_text()
assert REV in env and 'Xcode 26.6' in env and '17F113' in env and 'iphonesimulator26.5' in env

warm=json.loads((OUT/'full/simulator-startup/report.json').read_text())
assert warm['status']=='failed'
assert 'Simulator warm-up outcome: failure (diagnostic only)' in console
assert 'Simulator startup: attempt-1-postflight: timed_out' in console

manifest_path=OUT/'compact/native-attachments/manifest.json'
assert manifest_path.read_bytes()==(OUT/'full/artifacts/native-attachments/manifest.json').read_bytes()
manifest=json.loads(manifest_path.read_text());attachments=[]
for group in manifest:
    method=group['testIdentifier'].replace('/','.').removesuffix('()')
    assert method in expected
    for item in group['attachments']:
        name=item['exportedFileName'];p=manifest_path.parent/name
        assert p.read_bytes()==(OUT/'full/artifacts/native-attachments'/name).read_bytes()
        assert item['isAssociatedWithFailure'] is False
        r={'method':method,'humanName':item['suggestedHumanReadableName'],'path':str(p.relative_to(OUT)),
           'timestamp':item['timestamp'],'deviceName':item['deviceName'],'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}
        if p.suffix=='.png':
            with Image.open(p) as im:
                im.verify()
            with Image.open(p) as im:r['dimensions']=list(im.size)
        attachments.append(r)
assert len(attachments)==7 and sum('dimensions' in a for a in attachments)==4

comparisons=[]
for path in ['App/ProjectLibraryView.swift','App/StudioView.swift','App/StudioTextLayoutDiagnostics.swift',
             'UITests/ReferenceComparisonUITests.swift','scripts/native_test_shards.py','.github/workflows/ios-prototype.yml']:
    old,new=src(OLD,path),src(REV,path);assert old==new
    comparisons.append({'path':path,'sha256':digest(new),'wholeFileIdentical':True})
old,new=src(OLD,paths[0]),src(REV,paths[0])
old,new=b'\n'.join(old.splitlines()[:405]),b'\n'.join(new.splitlines()[:405])
assert old==new
comparisons.append({'path':paths[0],'first405LinesIdentical':True,'prefixSha256':digest(new)})
previous=[]
for method in ['testArchivedDeleteRequiresConfirmationAndPersistsOnlyThatRemoval','testCreateDuplicateRenameSwitchAndRelaunch']:
    p=ROOT/'campaign/evidence/086/derived-summaries'/f'{method}.json'
    old=json.loads(p.read_text());assert old['testStatus']=='Failure'
    previous.append({'method':'ProjectLibraryUITests.'+method,'oldStatus':'Failure','oldRevision':OLD,
                     'oldReceiptSha256':digest(p.read_bytes()),'currentStatus':'passed',
                     'sourceFixEstablished':False})

pngs=[r for r in attachments if 'dimensions' in r]
sheet=Image.new('RGB',(820,970),'#202020');draw=ImageDraw.Draw(sheet)
for i,r in enumerate(pngs):
    x,y=(i%2)*410,(i//2)*485
    draw.text((x+6,y+6),r['humanName'].split('_0_')[0],fill='white')
    with Image.open(OUT/r['path']) as im:
        im.thumbnail((400,450));sheet.paste(im,(x+5,y+30))
sheet.save(OUT/'derived-contact-sheet.png')

write('archive-receipts.json',archives+[raw])
write('attachments.json',attachments)
write('source-inventory.json',sources)
record={'worker':'/root/a097_current_library_acceptance','revision':REV,'runId':run['id'],'attempt':run['run_attempt'],
        'jobId':job['id'],'jobConclusion':job['conclusion'],'expected':expected,'counts':{'expected':9,'started':9,'passed':9,'failed':0,'skipped':0,'incomplete':0,'unstarted':0},
        'events':events,'nativeAccountingMatches':True,'finalizedResult':{'path':str(infos[0].relative_to(OUT)),'sha256':digest(infos[0].read_bytes())},
        'normalCommandCompletion':{'testExecuteSucceededMarker':True,'stepConclusion':'success','exitCode':0,
             'exitCodeBasis':'Pinned workflow runs xcodebuild through tee under set -euo pipefail; GitHub marks the complete selected UI step success and proceeds normally. No standalone numeric-exit marker is printed for this shard.'},
        'warmup':{'actual':'failed','failure':'attempt-1-postflight timeout','continuedStep':'success','notAnAppAcceptancePass':True},
        'attachmentCount':7,'originalPngCount':4,'historicalFailures':previous,'sourceComparison':comparisons,
        'limits':['No whole-workflow or M03 accessibility acceptance.','No physical-device, provider, network or platform accessibility audit claimed.',
                  'Current passes are new observations; they do not establish a source repair or erase old failures.'],
        'rawEvidence':{'fullOriginal':'library-full-original.zip','compactOriginal':'library-compact-original.zip','jobConsole':'job-console.log','archiveReceipts':'archive-receipts.json'}}
write('reconciliation.json',record)
files=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and not any(part in ['raw','full','compact','source'] for part in p.relative_to(OUT).parts) and p.name!='retained-hashes.json':
        files.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())})
write('retained-hashes.json',files)
print(json.dumps({'passed':9,'failed':0,'finalized':True,'originalPNGs':4,'historicalFailuresPreserved':2,'warmup':'failed diagnostic','receiptSha256':digest((OUT/'reconciliation.json').read_bytes())}))
